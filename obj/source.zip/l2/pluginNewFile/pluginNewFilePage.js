/// <mls fileReference="_100555_/l2/pluginNewFile/pluginNewFilePage.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { convertFileNameToTag } from '/_102027_/l2/utils.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getMessageKey } from "/_102029_/l2/collabLitElement.js";
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { createNewFile, changeTagName, changeClassName, changeWidget, changeStateName, getTemplateImport } from "/_100555_/l2/pluginNewFile/pluginNewFileBase.js";
import '/_100555_/l2/pluginNewFile/widgetTextCode.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Criar um arquivo de pagina.',
    description: "Criar um arquivo do tipo pagina. Na pagina sera possivel manipular o globalState e dos eventos da página.",
    project: "Projeto",
    shortName: "Nome",
    header: "Criar uma pagina",
    btnCreate: 'Criar arquivo',
    loading: 'Criando arquivo...',
    error: 'Nome do arquivo em branco ou invalido',
    errorPageName: 'O nome do arquivo deve começar com "page"',
};
const message_en = {
    title: 'Create a page file.',
    description: "Create a page file. In the page, it will be possible to manipulate the globalState and the page events.",
    project: "Project",
    shortName: "ShortName",
    header: "Create a page",
    btnCreate: 'Create file',
    loading: 'Creating File...',
    error: 'Blank or invalid file name',
    errorPageName: 'File name must start with "page"',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
let msg = messages[lang];
export const details = {
    title: msg.title,
    description: msg.description,
    tags: ["lit", "html", "page"],
};
let PluginNewFilePage = class PluginNewFilePage extends StateLitElement {
    constructor() {
        super(...arguments);
        this.position = 'left';
        this.loading = false;
        this.service = this.closest('service-detail-100554');
        this.template = `
import { CollabPageElement } from '${getTemplateImport(102027, 'collabPageElement', '')}';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from '${getTemplateImport(102027, 'collabState', '')}';

@customElement('[tagName]')
export class [className] extends CollabPageElement {
    initPage() {

    }
}
`;
        this.enhancement = `_102027_/l2/enhancementLit.ts`;
        this.groupName = `other`;
    }
    getTemplateTS() {
        let newExample = this.template;
        if (this.shortName && this.project) {
            newExample = changeTagName(newExample, convertFileNameToTag({ project: this.project, shortName: this.shortName, folder: this.folder }));
            newExample = changeClassName(newExample, this.project, this.shortName);
            newExample = changeWidget(newExample, this.project, this.shortName);
            newExample = changeStateName(newExample, this.shortName);
        }
        const group = this.groupName && this.groupName != 'other' ? ` groupName="${this.groupName}"` : ` groupName="page"`;
        const enhancement = this.enhancement ? this.enhancement : '_blank';
        const folder = this.folder ? `${this.folder}/` : '';
        const name = `_${this.project}_/l2/${folder}${this.shortName}.ts`;
        return `/// <mls fileReference="${name}" enhancement="${enhancement}"/>\n${newExample}\n`;
    }
    getTemplateHTML() {
        if (!this.shortName || !this.project)
            return '';
        const tagName = convertFileNameToTag({ project: this.project, shortName: this.shortName, folder: this.folder });
        return `<${tagName}></${tagName}>`;
    }
    async handleAddFile() {
        if (!this.project || !this.shortName) {
            this.service.setError(msg.error);
            return;
        }
        ;
        this.loading = true;
        try {
            await createNewFile({
                folder: this.folder,
                project: this.project,
                position: this.position,
                shortName: this.shortName,
                enhancement: this.enhancement,
                sourceTS: this.getTemplateTS(),
                sourceHTML: this.getTemplateHTML(),
                openPreview: true
            });
        }
        catch (e) {
            this.loading = false;
        }
    }
    render() {
        return html `
            ${this.loading ?
            html `<div>${msg.loading}</div>`
            :
                html `   
                <div>
                    <h2>${msg.header} </h2>
                    <hr>
                    <div>
                        <span> <b>${msg.project}:</b> ${this.project}</span>
                        <span> <b>${msg.shortName}:</b> ${this.shortName}</span>    
                    </div>
                    <div style="margin-top:1rem;">
                        <button @click=${this.handleAddFile}>${msg.btnCreate}</button>
                    </div>

                    <plugin-new-file--widget-text-code-100555 language="typescript" text="${this.getTemplateTS()}"></plugin-new-file--widget-text-code-100555>
                    <plugin-new-file--widget-text-code-100555 language="html" text="${this.getTemplateHTML()}"></plugin-new-file--widget-text-code-100555>

                
                </div>`}
        `;
    }
};
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "shortName", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "project", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "folder", void 0);
__decorate([
    property()
], PluginNewFilePage.prototype, "position", void 0);
__decorate([
    property()
], PluginNewFilePage.prototype, "loading", void 0);
PluginNewFilePage = __decorate([
    customElement('plugin-new-file--plugin-new-file-page-100555')
], PluginNewFilePage);
export { PluginNewFilePage };
