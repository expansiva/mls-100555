/// <mls fileReference="_100555_/l2/pluginVerify/pluginVerifyError.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
import { initCompileMonaco } from '/_100554_/l2/collabInit.js';
/// **collab_i18n_start**
const message_pt = {
    fileVerification: 'Verificação de arquivos',
    checkFiles: 'Verificando arquivos',
    noErros: "Nenhum erro encontrado",
    cancel: 'Cancelar verificação'
};
const message_en = {
    fileVerification: 'File verification',
    checkFiles: 'Checking files',
    noErros: 'No errors found',
    cancel: 'Cancel verification',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginVerifyError = class PluginVerifyError extends PluginBaseModule {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.continueVerify = true;
        this.find = [];
        this.current = '0';
        this.tot = '0';
        this.error = '';
        this.autoPrepare = false;
        this.isLoad = false;
        this.listErrors = [];
    }
    //-----COMPONENT---------
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.error !== '') {
            return html `${this.renderHeader()}
                <h4 style="color:red">${this.error}</h4>
            `;
        }
        if (this.isLoad) {
            return html `
                ${this.renderHeader()}
                ${this.renderLoad()}
            `;
        }
        return this.renderErros();
    }
    renderLoad() {
        return html `
        <div class="contentloader">
            <div class="textLoader">
                ${this.msg.checkFiles}
                <span>${this.current}/${this.tot}</span>
            </div>
            <button @click=${this.cancelVerify}>${this.msg.cancel}</button>
            <ul>
                ${repeat(this.find, ((key) => key), ((k, index) => this.renderItem(k)))}
            </ul>
        </div>
        `;
    }
    renderHeader() {
        return html `
            <h3>${this.msg.fileVerification}</h3>
        `;
    }
    renderErros() {
        if (this.listErrors.length <= 0)
            this.listErrors.push(this.msg.noErros);
        return html `
            ${this.renderHeader()}
            <ul>

                ${repeat(this.listErrors, ((key) => key), ((k, index) => this.renderItem(k)))}
            
            </ul>
        `;
    }
    renderItem(i) {
        return html `
            <li>
                ${i}
            </li>
        `;
    }
    //------IMPLEMENTS--------
    async prepare() {
        try {
            this.isLoad = true;
            this.continueVerify = true;
            const prj = mls.actualProject;
            if (!prj)
                throw new Error('Not found project');
            await initCompileMonaco(prj);
            const ret = await mls.l2.typescript.compileAll(prj, this.progressCallback.bind(this));
            this.listErrors = ret;
            this.setFilesErros(this.listErrors);
            if (!this.continueVerify)
                this.fireEvent(true);
            else
                this.fireEvent(this.listErrors.length === 0);
            this.isLoad = false;
        }
        catch (e) {
            this.isLoad = false;
            this.error = e.message;
        }
    }
    setFilesErros(array) {
        const ret = [];
        const itens = array.map(str => str.replace(/^--- Error compiling\s+/, ''));
        itens.forEach((f) => {
            let pr = f.substring(1).split("_")[0];
            let prID = Number(pr);
            if (isNaN(prID))
                prID = 0; // error
            let path = f.substring(pr.length + 2);
            const key = mls.stor.getKeyToFiles(prID, 2, path, '', '.ts');
            if (mls.stor.files[key]) {
                mls.stor.files[key].hasError = true;
                ret.push(mls.stor.files[key]);
            }
        });
        return ret;
    }
    cancelVerify() {
        this.continueVerify = false;
    }
    ;
    progressCallback(current, total, results) {
        this.current = current.toString();
        this.tot = total.toString();
        this.find = results;
        return this.continueVerify;
    }
    fireEvent(free) {
        mls.events.fire(mls.actualLevel, 'ProjectCompilationComplete', JSON.stringify({ tsFree: free }), 0);
    }
};
__decorate([
    property()
], PluginVerifyError.prototype, "find", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "current", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "tot", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "error", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "isLoad", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "listErrors", void 0);
PluginVerifyError = __decorate([
    customElement('plugin-verify--plugin-verify-error-100555')
], PluginVerifyError);
export { PluginVerifyError };
