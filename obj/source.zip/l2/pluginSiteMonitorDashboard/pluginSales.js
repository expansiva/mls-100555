/// <mls fileReference="_100555_/l2/pluginSiteMonitorDashboard/pluginSales.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { query, property, customElement } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
export const pluginData = {
    title: "Sales",
    getSvg() {
        return svg `
     <svg svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M24 0C10.7 0 0 10.7 0 24S10.7 48 24 48l45.5 0c3.8 0 7.1 2.7 7.9 6.5l51.6 271c6.5 34 36.2 58.5 70.7 58.5L488 384c13.3 0 24-10.7 24-24s-10.7-24-24-24l-288.3 0c-11.5 0-21.4-8.2-23.6-19.5L170.7 288l288.5 0c32.6 0 61.1-21.8 69.5-53.3l41-152.3C576.6 57 557.4 32 531.1 32L360 32l0 102.1 23-23c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9l-64 64c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l23 23L312 32 120.1 32C111 12.8 91.6 0 69.5 0L24 0zM176 512a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm336-48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0z"/></svg>
    `;
    }
};
let PluginSales = class PluginSales extends PluginBaseModule {
    constructor() {
        super(...arguments);
        this.filter = "today";
        this.chartData = {};
        this.autoPrepare = false;
        this.mode = 'simplified';
    }
    async prepare() {
        await import('/_100554_/l2/widgetCollabChart.js');
        this.chartData = {
            "tooltip": {
                "trigger": "item",
                "formatter": "{a} <br/>{b}: {c} ({d}%)"
            },
            "series": [
                {
                    "name": "Sales",
                    "type": "pie",
                    "radius": "50%",
                    "data": [
                        { "value": 5000, "name": "Product A" },
                        { "value": 3000, "name": "Product B" },
                        { "value": 2000, "name": "Product C" },
                        { "value": 4000, "name": "Product D" },
                        { "value": 1000, "name": "Product E" }
                    ],
                    "emphasis": {
                        "itemStyle": {
                            "shadowBlur": 10,
                            "shadowOffsetX": 0,
                            "shadowColor": "rgba(0, 0, 0, 0.5)"
                        }
                    }
                }
            ],
        };
        if (this.mode === 'full') {
            this.chartData.title = {
                text: "Product Sales Distribution",
                subtext: "Total Sales: $15,000",
                left: "center"
            };
            this.chartData.legend = {
                orient: "vertical",
                left: "left",
                data: ["Product A", "Product B", "Product C", "Product D", "Product E"]
            };
        }
        await this.updateComplete;
        const data = JSON.stringify(this.chartData);
        function escapeHTML(str) {
            return str
                .replace(/&/g, "&amp;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");
        }
        if (this.body)
            this.body.innerHTML = `<widget-collab-chart-10055 renderer="svg" data="${escapeHTML(data)}"></widget-collab-chart-10055>`;
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
                <select @change=${this.handleChange}>
                    <option value="today">Today</option>
                    <option value="week">Week</option>
                    <option value="mounth">Last 30 days</option>
                    <option value="all">All Time</option>
                </select>
            </header>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body"></div>`;
    }
    handleChange(e) {
        const target = e.target;
        const value = target.value;
        this.filter = value;
        this.prepare();
    }
};
__decorate([
    property({ type: String })
], PluginSales.prototype, "filter", void 0);
__decorate([
    property()
], PluginSales.prototype, "chartData", void 0);
__decorate([
    property({ type: Boolean })
], PluginSales.prototype, "autoPrepare", void 0);
__decorate([
    property({ type: String })
], PluginSales.prototype, "mode", void 0);
__decorate([
    query('.plugin-body')
], PluginSales.prototype, "body", void 0);
PluginSales = __decorate([
    customElement('plugin-site-monitor-dashboard--plugin-sales-100555')
], PluginSales);
export { PluginSales };
