declare module "_100555_pageLogin" {
    class Login {
        constructor();
    }
    export const login: Login;
}
