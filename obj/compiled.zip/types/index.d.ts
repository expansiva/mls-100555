declare module "_100555_/l2/pageLogin" {
    class Login {
        constructor();
    }
    export const login: Login;
}
