declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_100555_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_100555_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102027_/l2/plugins/pluginTestUtils" {
    /**
     * Where a test case can run:
     * - 'browser': needs real DOM/customElements (mounts the component, dispatches events, etc.).
     * - 'vscode': pure logic, runs without DOM (e.g. an exported function that only transforms data).
     * When in doubt, use 'browser' — it's the environment with full fidelity; 'vscode' is opt-in
     * only for logic proven to be DOM-independent.
     */
    export type TestEnv = 'browser' | 'vscode';
    export interface IPluginTestParams {
        input?: any;
        expected: any;
        /** When true, `compare` checks that `expected` is a subset of `actual` (useful for large/dynamic outputs). */
        contains?: boolean;
    }
    /**
     * Shape-compatible with `ICANTest` (tsTestAST.ts): same functionName/params pair,
     * with `env` added so the runner can decide where to execute each function.
     */
    export interface IPluginTestCase {
        functionName: string;
        env: TestEnv;
        params: IPluginTestParams[];
    }
    /** Sorts tests so 'browser' comes before 'vscode' — use before running a batch. */
    export function sortByEnvironment(tests: IPluginTestCase[]): IPluginTestCase[];
    export function isBrowser(): boolean;
    /**
     * Creates the element, applies properties, appends it to the document and waits for the first render.
     * Every call is tracked so `cleanup()` can remove it later — never forget to call cleanup().
     */
    export function mount<T extends HTMLElement = HTMLElement>(tag: string, props?: Record<string, any>): Promise<T>;
    /** Looks inside the shadow DOM if it exists, otherwise falls back to the light DOM (plugins vary between the two). */
    export function query(el: Element, selector: string): Element | null;
    /**
     * Replaces `mls.*` keys with mocked values; returns a function that restores the original state.
     * `cleanup()` also restores any pending override, so using only overrideMls is already safe
     * even if the test throws before manually calling the restorer.
     *
     * Several `mls.*` namespaces (e.g. `mls.stor`, and even leaves inside it like `mls.stor.getKeyToFiles`)
     * are exposed as getter-only accessors with no setter — a plain `mls.stor.getKeyToFiles = fn` throws
     * `Cannot set property getKeyToFiles of [object Object] which has only a getter`. To work regardless of
     * depth, every write goes through `Object.defineProperty` (which replaces the property descriptor
     * outright, bypassing the missing setter) instead of plain assignment.
     *
     * When both the current value and the override are plain objects, only the override's own keys are
     * replaced on the *existing* object — one level deep — instead of swapping the whole reference. E.g.
     * `overrideMls({ stor: { getKeyToFiles: fn } })` replaces just `mls.stor.getKeyToFiles`, leaving every
     * other property of the real `mls.stor` (and its many loaded files) untouched.
     */
    export function overrideMls(overrides: Record<string, any>): () => void;
    /** Removes every mounted element and undoes any pending `mls.*` overrides. Call at the end of each test (try/finally). */
    export function cleanup(): void;
    /**
     * Universal contract check (layer 1 of the strategy): element registered and renders without throwing.
     * Works for any of the 88 plugins, regardless of type.
     */
    export function mountAndVerify(tag: string, props?: Record<string, any>): Promise<{
        registered: boolean;
        rendered: boolean;
    }>;
    /**
     * Compares the actual value against the expected one (deep-equal with normalization) and throws
     * a formatted error on mismatch — keeps the "threw = failed" semantics of the ICAN runner.
     */
    export function compare(actual: any, expected: any, opts?: {
        contains?: boolean;
    }): void;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102027_/l2/pluginBaseModule" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getFCMTokenForBackend?(): Promise<string | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getFCMTokenForBackend: () => Promise<string>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "custom" | "default";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102036_/l2/shared/api" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
    export function msgApplyIntents(args: Omit<msg.RequestApplyIntents, "action">): Promise<msg.ResponseApplyIntents>;
    export function msgAppendLongTermMemory(args: Omit<msg.RequestAppendLongTermMemory, "action">): Promise<msg.ResponseAppendLongTermMemory>;
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from "_102036_/l2/collabMessagesIndexedDB";
}
declare module "_102025_/l2/shared/api" {
    export * from "_102036_/l2/shared/api";
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from "_102036_/l2/shared/interfaces";
    export * from "_102036_/l2/shared/interfaces";
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module "_102036_/l2/shared/interfaces" {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<string>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<void>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<msg.Thread>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: string;
        agentId: string;
        connectorId: string;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_100555_/l2/pluginArchitecture/pluginQuestionArchitecture" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export class PluginQuestionArchitecture extends PluginBaseModule {
        private msg;
        private question;
        private loading;
        private result?;
        private error;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        private askAgent;
        private _callAgent;
        private findFlexibleNodes;
        private openFile;
        fireEvents(action: string, file: mls.stor.IFileInfo, timeout?: number): Promise<void>;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100555_/l2/pluginArchitecture/pluginQuestionArchitecture.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginArchitecture/pluginQuestionArchitecture";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testAskAgentEmptyQuestion(testCase: {
        expected: any;
    }): Promise<string>;
    export function testAskAgentSuccess(testCase: {
        input: {
            question: string;
        };
        expected: any;
    }): Promise<string>;
    export function testAskAgentEmptyJsonBug(testCase: {
        expected: any;
    }): Promise<string>;
    export function testAskAgentNotFoundFlexible(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginEditL3/pluginEditStyleAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginEditL3/pluginEditStyleAST" {
    type Block = {
        start: number;
        end: number;
    };
    export class LessAST {
        private model;
        selected: string | null;
        blocks: Map<string, Block>;
        rules: Record<string, string> | null | undefined;
        constructor(model: monaco.editor.ITextModel);
        select(selector: string): boolean;
        setRule(property: string, value: string): void;
        setRule_old(property: string, value: string): void;
        addSelector(selector: string, rules?: Record<string, string>): void;
        removeSelector(selector: string): void;
        getRules(selector: string): Record<string, string>;
        exportSelectorGroupStrict(baseSelector: string): string;
        private reparse;
        private ensureSelectorPath;
        private stripComments;
        private escape;
    }
}
declare module "_100555_/l2/pluginEditL3/pluginEditStyleAST.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginEditL3/pluginEditStyleAST";
    export const tests: IPluginTestCase[];
    export function testReparseBuildsNestedBlocks(testCase: {
        expected: any;
    }): Promise<string>;
    export function testSelectBehavior(testCase: {
        expected: any;
    }): Promise<string>;
    export function testSetRuleWithoutSelectionThrows(testCase: {
        expected: any;
    }): Promise<string>;
    export function testSetRuleAddsNewProperty(testCase: {
        expected: any;
    }): Promise<string>;
    export function testSetRuleReplacesExistingProperty(testCase: {
        expected: any;
    }): Promise<string>;
    export function testSetRuleEmptyValue(testCase: {
        input: {
            property: string;
        };
        expected: any;
    }): Promise<string>;
    export function testGetRulesIgnoresNestedDeclarations(testCase: {
        expected: any;
    }): Promise<string>;
    export function testAddSelectorCreatesNestedPathAndRules(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRemoveSelectorClearsSelectionWhenActive(testCase: {
        expected: any;
    }): Promise<string>;
    export function testExportSelectorGroupStrictSimpleSelector(testCase: {
        input: {
            baseSelector: string;
        };
        expected: any;
    }): Promise<string>;
    export function testExportSelectorGroupStrictGroupsMatchingChildren(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginEditL3/pluginEditStyleL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/collabMonacoEditor" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMonacoEditor extends StateLitElement {
        msize: string;
        mlsEditor: any;
        get isMls2(): boolean;
        render(): any;
        updated(changed: Map<PropertyKey, unknown>): void;
        private _onMsizeChange;
    }
}
declare module "_100555_/l2/pluginEditL3/pluginEditStyleL3" {
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { LessAST } from "_100555_/l2/pluginEditL3/pluginEditStyleAST";
    import "_102027_/l2/collabMonacoEditor";
    export class PluginEditStyleL3 extends PluginBaseModule {
        private editorEl;
        msize: string;
        error: string;
        private static inEdit;
        private static inSetValue;
        private _ed1;
        private _ed2;
        private initalSelectors;
        private msg;
        private model;
        private modelDest;
        modelBase: mls.editor.IModels | undefined;
        lessAst: LessAST | undefined;
        lessAstDest: LessAST | undefined;
        private keysResolve;
        get getKeyEditor(): string;
        get confE(): string;
        constructor();
        private setEvents;
        private onL3EditEvents;
        private onlevelChange;
        createRenderRoot(): this;
        firstUpdated(): void;
        updated(changedProperties: any): void;
        render(): any;
        forceUpdate(): Promise<void>;
        private init;
        private initMonaco_Editor;
        private openFile;
        private setContentDest;
        private setContent;
        private createModel;
        private _onModelChange;
        private timeOnChangeLessOrigin;
        private changeLessOrigin;
        private changeLessOrigin2;
        private mergeCssDeclarations;
        private getMatchingRulesForElement;
        private updatedMSizeEditor;
        private resolveSelector;
    }
}
declare module "_100555_/l2/pluginEditL3/pluginEditStyleL3.test" {
    import "_100555_/l2/pluginEditL3/pluginEditStyleL3";
}
declare module "_100555_/l2/pluginExplore/collabInputSearch" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabInputSearch extends CollabLitElement {
        private msg;
        placeholder: string;
        value: string;
        private focused;
        firstUpdated(): void;
        render(): any;
        private _onInput;
        private _onFocus;
        private _onBlur;
        private _clear;
        private _onKeyDown;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_100555_/l2/pluginExplore/mlsFileTree" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    interface FileInfo {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    interface TreeNode {
        name: string;
        fullPath: string;
        isFolder: boolean;
        children: TreeNode[];
        fileKey?: string;
        extension?: string;
        file: mls.stor.IFileInfo;
    }
    export class MlsFileTree extends CollabLitElement {
        position: string | undefined;
        project: string | undefined;
        filter: string;
        files: Record<string, FileInfo>;
        private expanded;
        private selected;
        private _loading;
        private _loadingMsg;
        firstUpdated(): void;
        render(): any;
        private _renderOverlay;
        private renderFiltered;
        private highlightText;
        private renderNode;
        renderItem(node: TreeNode, depth: number): any;
        private deleteFile;
        private undoFile;
        private getTitleInLocalStorage;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private buildTree;
        private toggleFolder;
        private selectFile;
        private clickGroupHidden;
        private collectFilesFromNode;
        private delAllByFolders;
        private undoAllByFolders;
        private getLevel;
        private clearPath;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
    }
}
declare module "_100555_/l2/pluginExplore/mlsFileTree2" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    interface FileInfo {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    export class MlsFileTree2 extends CollabLitElement {
        position: string | undefined;
        project: string | undefined;
        filter: string;
        files: Record<string, FileInfo>;
        private expanded;
        private selected;
        private _loading;
        private _loadingMsg;
        firstUpdated(): void;
        render(): any;
        private _renderOverlay;
        private renderFiltered;
        private highlightText;
        private renderIndent;
        private renderNode;
        private renderFile;
        private extClass;
        private deleteFile;
        private undoFile;
        private getTitleInLocalStorage;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private buildTree;
        private toggleExpand;
        private selectFile;
        private collectFilesFromNode;
        private delAllByFolders;
        private undoAllByFolders;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreList.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libHistoriesRecents" {
    export function addInHistory(file: mls.stor.IFileInfo): void;
    export function getHistory(): HistoryList;
    export function removeFromHistory(target: HistoryItem): void;
    export function renameHistoryItem(target: HistoryItem, newShortName: string): void;
    export function loadProjectHistory(): IHistoryProject[];
    export function saveProjectHistory(history: IHistoryProject[]): void;
    export function removeProjectFromHistory(projectId: number): void;
    export function renameProjectInHistory(projectId: number, newName: string): void;
    interface IHistoryProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    export interface HistoryItem {
        project: number;
        shortName: string;
        extension: string;
        folder: string;
    }
    type HistoryList = HistoryItem[];
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL1" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        service: ServiceBase | undefined;
        father: HTMLElement | undefined;
        level: number;
        error: string;
        position: string;
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        private handleInputInput;
        private clickCancel;
        private getNewNameAndValid;
        private showLoad;
        private createFile;
        private setHistory;
        private showError;
        private fireEvents;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBase" {
    export interface IDetails {
        title: string;
        description: string;
        tags: string[];
    }
    export function changeClassName(source: string, project: number, shortname: string): string;
    export function changeWidget(source: string, project: number, shortname: string): string;
    export function changeShortName(source: string, shortname: string): string;
    export function changeTagName(source: string, tagName: string): string;
    export function changeProject(source: string, project: number): string;
    export function changeFolder(source: string, folder: string): string;
    export function changeStateName(source: string, stateName: string): string;
    export function getTemplateImport(projectBase: number, shortName: string, folder: string): string;
    export interface IRequestNewFile {
        project: number;
        position: 'left' | 'right';
        shortName: string;
        folder?: string;
        enhancement: string;
        sourceTS: string;
        sourceHTML?: string;
        sourceLess?: string;
        sourceTest?: string;
        sourceDefs?: string;
        openPreview: boolean;
    }
    export function createNewFile(args: IRequestNewFile): Promise<void>;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL2" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        level: number;
        error: string;
        position: string;
        father?: ServiceBase | undefined;
        plugins: IPlugins[];
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        renderTemplates(): any;
        private goBack;
        private handleInputInput;
        private handleClickTemplate;
        private clickCancel;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private getPlugins;
        private getPluginsInfo;
    }
    interface IPlugins extends IDetails {
        widget: string;
        category: string | null;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL3" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL3 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptOrganism: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL4" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL4 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptPage: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private verifyModuleConfig;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreList" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import "_100555_/l2/pluginExplore/collabInputSearch";
    import "_100555_/l2/pluginExplore/mlsFileTree2";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExploreList extends PluginBaseModule {
        createModels(stor: mls.stor.IFileInfo): Promise<void>;
        private resizeObserver;
        private myDep;
        private msg;
        service: ServiceBase | undefined;
        private filterByLevel;
        autoPrepare: boolean;
        mode: TModeExploreList;
        refresh: string;
        position: string;
        levelFiles: number;
        project: number;
        projectLabel: string;
        filterProject: number;
        modeView: number;
        hiddenFiles: boolean;
        errorAux: string;
        files: mls.stor.IFileInfo[];
        history: mls.stor.IFileInfo[];
        modeFilter: string | undefined;
        lis: HTMLElement[] | undefined;
        constructor();
        private info;
        prepare(): Promise<void>;
        private showAdd;
        private filesInLocal;
        private setEvents;
        private onlevelChange;
        private onMLSEvents;
        connectedCallback(): void;
        disconnectedCallback(): void;
        createRenderRoot(): this;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        renderModeList(): any;
        renderHeader(): any;
        renderHistory(): any;
        renderList(): any;
        renderFolder(): any;
        renderFolder2(files: mls.stor.IFileInfo[]): any;
        getTitleInLocalStorage(ts: mls.stor.IFileInfo, html: mls.stor.IFileInfo, less: mls.stor.IFileInfo, test: mls.stor.IFileInfo, defs: mls.stor.IFileInfo): string;
        renderLiItem(file: mls.stor.IFileInfo, index: number, inHistory: boolean): any;
        renderAddL1(): any;
        renderAddL2(): any;
        renderAddL3(): any;
        renderAddL4(): any;
        private getAllName;
        private showLoading;
        private showError;
        private closeAllMenus;
        private clickOptUndo;
        private clickOptDel;
        private clickOptOpen;
        private clickOptOpenSecurity;
        private clickOptRename;
        private clickOptClone;
        private cloneFile;
        private renameFile;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
        private fireEventThisProject;
        private fireEventLoadProject;
        private changeListTimeout;
        changeList(time?: number): void;
        private extensionLevel;
        private levelByLevel;
        private init;
        private setLastFilter;
        private getMyFileInElement;
        private clickGroupHidden;
        private changeSelectProject;
        private changeHiddenFiles;
        private changeModeOrder;
        private inFilter;
        private timeFilterChange;
        private searchTerm;
        private filterLiChange;
        private getFiles;
        private filterArrayHistory;
        private validFileByLevel;
        private getFilesProject;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private getFileHistory;
        private isValidNewName;
        private initObserverResize;
        private saveLocalStorageLastOpen;
        private delAllByFolders;
        private loadLastPreference;
        private getLastModeFilter;
        private setLastPreference;
    }
    type TModeExploreList = 'list' | 'addL1' | 'addL2' | 'addL3' | 'addL4';
}
declare module "_100555_/l2/pluginExplore/pluginExploreList.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginExplore/pluginExploreList";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRenderByMode(testCase: {
        input: {
            mode: string;
            tag: string;
        };
        expected: any;
    }): Promise<string>;
    export function testIsValidNewName(testCase: {
        input: {
            project: string;
            name: string;
        };
        expected: any;
    }): Promise<string>;
    export function testFilterArrayHistory(testCase: {
        input: {
            alvo: any[];
            base: any[];
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL1.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginExplore/pluginExploreListAddL1";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetNewNameAndValid(testCase: {
        input: {
            prj: number;
            name: string;
        };
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL2.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginExplore/pluginExploreListAddL2";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetNewNameAndValid(testCase: {
        input: {
            prj: number;
            name: string;
        };
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL3.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginExplore/pluginExploreListAddL3";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetNewNameAndValid(testCase: {
        input: {
            prj: number;
            name: string;
            folder: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderShowsFormContainer(testCase: {
        expected: any;
    }): Promise<string>;
    export function testFirstUpdatedSkipsInitWhenAutoPrepareFalse(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL4.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginExplore/pluginExploreListAddL4";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetNewNameAndValid(testCase: {
        input: {
            prj: number;
            name: string;
            folder: string;
        };
        expected: any;
    }): Promise<string>;
    export function testVerifyModuleConfigThrowsWhenNoModule(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRenderShowsFormContainer(testCase: {
        expected: any;
    }): Promise<string>;
    export function testFirstUpdatedSkipsInitWhenAutoPrepareFalse(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginGit/pluginPullrequest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginGit/pluginPullrequest" {
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export class PluginPullrequest extends PluginBaseModule {
        private msg;
        private itens;
        private owner;
        private repo;
        private branch;
        error: string;
        autoPrepare: boolean;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        renderHeader(): any;
        renderNoItens(): any;
        renderListPull(): any;
        renderItemListPull(i: mls.stor.others.IPullRequest, index: number): any;
        prepare(): Promise<void>;
        loadListPullRequest(): Promise<void>;
        initInfoProject(): Promise<void>;
    }
}
declare module "_100555_/l2/pluginGit/pluginPullrequest.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginGit/pluginPullrequest";
    export const tests: IPluginTestCase[];
}
declare module "_100555_/l2/pluginLink/pluginConfigLinks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libProjectConfig" {
    export const projectConfig: IProjectConfigCache;
    export function clearLocalChanges(project: number): Promise<void>;
    export function getConfigProject(project: number, ignoreLocalChanges?: boolean): Promise<mls.l5_common.ProjectConfig | undefined>;
    export function updateConfigProject(project: number, newConfig: mls.l5_common.ProjectConfig): Promise<void>;
    export function updateConfigProjectPlugins(project: number, newPlugins: {
        [key: string]: mls.l5_common.IPlugin;
    }): Promise<void>;
    export function createConfigFile(project: number): Promise<mls.l5_common.ProjectConfig>;
    interface IProjectConfigCache {
        [key: number]: {
            versionRef: string;
            config: mls.l5_common.ProjectConfig;
        };
    }
}
declare module "_100555_/l2/pluginLink/pluginConfigLinks" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export class PluginConfigLinks extends PluginBaseModule {
        myLinks: ILinks[];
        autoPrepare: boolean;
        private myConfig;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderLink(l: ILinks, idx: number): TemplateResult;
        renderEdit(): TemplateResult;
        private init;
        private addLink;
        private updateConfig;
        private clickDel;
        private removeModeEdit;
        private setModeEdit;
        private test;
    }
    interface ILinks {
        title: string;
        url: string;
        color: string;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100555_/l2/pluginLink/pluginConfigLinks.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginLink/pluginConfigLinks";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testAddLink(testCase: {
        input: {
            title: string;
            url: string;
            color: string;
        };
        expected: any;
    }): Promise<string>;
    export function testAddLinkMissingFieldsAlert(testCase: {
        input: {
            title: string;
            url: string;
        };
        expected: any;
    }): Promise<string>;
    export function testAddLinkDefaultColor(testCase: {
        input: {
            title: string;
            url: string;
            color: string;
        };
        expected: any;
    }): Promise<string>;
    export function testClickDel(testCase: {
        expected: any;
    }): Promise<string>;
    export function testModeEditToggle(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginModule/pluginDeleteModule.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/projectAST" {
    export function addModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message?: undefined;
    } | {
        ok: boolean;
        message: string;
    }>;
    export function configureMasterFrontEnd(project: number, start: string, build: string, liveView: string): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
    export function removeModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
}
declare module "_100555_/l2/pluginModule/pluginDeleteModule" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class PluginDeleteModule extends CollabLitElement {
        private msg;
        moduleName: string;
        project: string;
        filesToDelete: mls.stor.IFileInfo[];
        confirmInput: string;
        isDeleting: boolean;
        isDeleted: boolean;
        feedbackMsg: string;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): TemplateResult;
        private getFilesModule;
        private getFileKey;
        private handleDelete;
        private deleteAllFiles;
        private removeTokensIfNeeded;
    }
}
declare module "_100555_/l2/pluginModule/pluginDeleteModule.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginModule/pluginDeleteModule";
    export const tests: IPluginTestCase[];
    export function testGetFileKey(testCase: {
        input: {
            folder: string;
            project: number;
            shortName: string;
            extension: string;
        };
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginNewFile/widgetTextCode" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class WidgetTextCode extends CollabLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        setCode(): void;
        firstUpdated(): void;
        render(): any;
        private onChangeText;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileAgent" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import "_100555_/l2/pluginNewFile/widgetTextCode";
    export const details: IDetails;
    export class PluginNewFileBlank extends StateLitElement {
        shortName: string | undefined;
        folder: string | undefined;
        project: number | undefined;
        position: 'left' | 'right';
        loading: boolean;
        templateType: AgentTemplateType;
        private service;
        private enhancement;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
    type AgentTemplateType = 'agent' | 'agentParallel' | 'agentWithClarification';
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileAgent.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginNewFile/pluginNewFileAgent";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetTemplateDefaultAgent(testCase: {
        input: {
            project: number;
            shortName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testGetTemplateTemplateTypeSwitch(testCase: {
        input: {
            templateType: 'agent' | 'agentParallel' | 'agentWithClarification';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleAddFileGuardThrows(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBase.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBase.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginNewFile/pluginNewFileBase";
    export const tests: IPluginTestCase[];
    export function testChangeClassName(testCase: {
        input: {
            source: string;
            project: number;
            shortName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testChangeWidget(testCase: {
        input: {
            source: string;
            project: number;
            shortName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testChangeShortName(testCase: {
        input: {
            source: string;
            shortName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testChangeTagName(testCase: {
        input: {
            source: string;
            tagName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testChangeProject(testCase: {
        input: {
            source: string;
            project: number;
        };
        expected: any;
    }): Promise<string>;
    export function testChangeFolder(testCase: {
        input: {
            source: string;
            folder: string;
        };
        expected: any;
    }): Promise<string>;
    export function testChangeStateName(testCase: {
        input: {
            source: string;
            stateName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testGetTemplateImport(testCase: {
        input: {
            project: number;
            shortName: string;
            folder: string;
        };
        expected: any;
    }): Promise<string>;
    export function testCreateNewFileInvalidName(testCase: {
        input: {
            shortName: string;
        };
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBlank.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBlank" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import "_100555_/l2/pluginNewFile/widgetTextCode";
    export const details: IDetails;
    export class PluginNewFileBlank extends StateLitElement {
        shortName: string | undefined;
        folder: string | undefined;
        project: number | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBlank.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginNewFile/pluginNewFileBlank";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetTemplateBodyAlwaysEmpty(testCase: {
        input: {
            project: number;
            shortName: string;
            folder?: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleAddFileGuardThrows(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileMd" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import "_100555_/l2/pluginNewFile/widgetTextCode";
    export const details: IDetails;
    export class PluginNewFileMd extends StateLitElement {
        shortName: string | undefined;
        folder: string | undefined;
        project: number | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileMd.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginNewFile/pluginNewFileMd";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetTemplateBodyAlwaysEmpty(testCase: {
        input: {
            project: number;
            shortName: string;
            folder?: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleAddFileGuardThrows(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFilePage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFilePage" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import "_100555_/l2/pluginNewFile/widgetTextCode";
    export const details: IDetails;
    export class PluginNewFilePage extends StateLitElement {
        shortName: string | undefined;
        project: number | undefined;
        folder: string | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplateTS;
        private getTemplateHTML;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFilePage.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginNewFile/pluginNewFilePage";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetTemplateTS(testCase: {
        input: {
            project: number;
            shortName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testGetTemplateHTML(testCase: {
        input: {
            project?: number;
            shortName?: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleAddFileGuardThrows(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileService.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileService" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import "_100555_/l2/pluginNewFile/widgetTextCode";
    export const details: IDetails;
    export class PluginNewFileService extends StateLitElement {
        shortName: string | undefined;
        project: number | undefined;
        folder: string | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileService.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginNewFile/pluginNewFileService";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetTemplate(testCase: {
        input: {
            shortName: string;
            folder?: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleAddFileGuardThrows(testCase: {
        input: {
            project?: number;
            shortName?: string;
        };
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileWebComponent.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileWebComponent" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import "_100555_/l2/pluginNewFile/widgetTextCode";
    export const details: IDetails;
    export class PluginNewFileWebComponent extends StateLitElement {
        shortName: string | undefined;
        project: number | undefined;
        folder: string | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileWebComponent.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginNewFile/pluginNewFileWebComponent";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGetTemplate(testCase: {
        input: {
            project: number;
            shortName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleAddFileGuardThrows(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginNewFile/widgetTextCode.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginPreview/pluginPreviewResultJs.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_100555_/l2/pluginPreview/pluginPreviewResultJs" {
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import "_102027_/l2/collabMonacoEditor";
    export class PluginPreviewResultJs extends PluginBaseModule {
        private msg;
        private _ed1;
        private hasError;
        private results;
        get confE(): string;
        msize: string;
        editor: IHTMLEditorElement | undefined;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        private createEditor;
        private getCompileResults;
        private setInitialModelProdJS;
        private getUri;
        private createOrGetModel;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100555_/l2/pluginPreview/pluginPreviewResultJs.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginPreview/pluginPreviewResultJs";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testMsizePropagatesToEditor(testCase: {
        input: {
            msize?: string;
        };
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginPreview/pluginPreviewResultTestJs.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginPreview/pluginPreviewResultTestJs" {
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import "_102027_/l2/collabMonacoEditor";
    export class PluginPreviewResultJs extends PluginBaseModule {
        private msg;
        private _ed1;
        private hasError;
        private results;
        get confE(): string;
        msize: string;
        editor: IHTMLEditorElement | undefined;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        private createEditor;
        private getCompileResults;
        private setInitialModelProdTestJS;
        private getUri;
        private createOrGetModel;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100555_/l2/pluginPreview/pluginPreviewResultTestJs.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginPreview/pluginPreviewResultTestJs";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testMsizePropagatesToEditor(testCase: {
        input: {
            msize?: string;
        };
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginGenerateDist" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export class PluginGenerateDist extends PluginBaseModule {
        private msg;
        error: string;
        tag: string;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderTag(): any;
        renderDefault(): TemplateResult;
        renderHeader(): TemplateResult;
        private init;
        private hasExtension;
        private getBuildByProject;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100555_/l2/pluginProject/pluginGenerateDist.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginGenerateDist";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRendersRegardlessOfScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHasExtension(testCase: {
        input: {
            path: string;
        };
        expected: any;
    }): Promise<string>;
    export function testInitSetsTagOrError(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginPresenterRecorder.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginPresenterRecorder" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginPresenterRecorder extends PluginBaseModule {
        private screenStream;
        private cameraStream;
        private mediaRecorder;
        private chunks;
        private downloadUrl;
        avatarShape: 'square' | 'round';
        avatarZoom: number;
        isRecording: boolean;
        isCountdown: boolean;
        countdownValue: number;
        private countdownTimer?;
        render(): TemplateResult;
        handleZoomChange(e: Event): void;
        updated(): void;
        startRecording(): Promise<void>;
        private _doStartRecording;
        stopRecording(): void;
        saveRecording(): void;
        showPipPreview(): void;
        hidePipPreview(): void;
    }
}
declare module "_100555_/l2/pluginProject/pluginPresenterRecorder.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginPresenterRecorder";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testHandleZoomChange(testCase: {
        input: {
            value: string;
        };
        expected: any;
    }): Promise<string>;
    export function testAvatarShapeRadioReflection(testCase: {
        input: {
            avatarShape: 'square' | 'round';
        };
        expected: any;
    }): Promise<string>;
    export function testButtonDisabledStates(testCase: {
        input: {
            isRecording: boolean;
            isCountdown: boolean;
        };
        expected: any;
    }): Promise<string>;
    export function testStopRecordingDoesNotResetIsRecording(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginProjectConfig.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginProjectConfig" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectConfig extends PluginBaseModule {
        static modelCount: number;
        private msg;
        autoPrepare: boolean;
        msize: string;
        c2: HTMLElement | undefined;
        body: HTMLDivElement | undefined;
        private _ed1;
        private model;
        private lastProject;
        private template;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        setEvents(): Promise<void>;
        private _clearChanges;
        private refreshIfNeeded;
        private createEditor;
        private loadProjectConfigs;
        private setInitialConfig;
        private createOrGetModel;
        private timeoutChangesEditorStyle;
        private setEventsModel;
        private onEditorChange;
        private getUri;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectConfig.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginProjectConfig";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testAutoPrepareGuard(testCase: {
        input: {
            autoPrepare: boolean;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginProjectDeleteFiles.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginProjectDeleteFiles" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export class PluginProjectDeleteFiles extends PluginBaseModule {
        private msg;
        groupName: string;
        filesToDelete: mls.stor.IFileInfo[];
        selectedFiles: Map<string, mls.stor.IFileInfo>;
        logs: string[];
        render(): TemplateResult;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private getFileKey;
        private clear;
        onSearch(): Promise<void>;
        onDelete(): Promise<void>;
        private removeThemeFromDesignSystem;
        private removeModuleFromProjectFile;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100555_/l2/pluginProject/pluginProjectDeleteFiles.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginProjectDeleteFiles";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testGetFileKey(testCase: {
        input: {
            project: number;
            folder: string;
            shortName: string;
            extension: string;
        };
        expected: any;
    }): Promise<string>;
    export function testDeleteButtonVisibility(testCase: {
        input: {
            fileCount: number;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginProjectDetail.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/collabIcons" {
    export const collab_terminal: any;
    export const collab_home: any;
    export const collab_bars: any;
    export const collab_magnifying_glass: any;
    export const collab_file_half_dashed: any;
    export const collab_book_skull: any;
    export const collab_rectangle_list: any;
    export const collab_lightbulb: any;
    export const collab_translate: any;
    export const collab_file_fragment: any;
    export const collab_file_code: any;
    export const collab_dot: any;
    export const collab_minus: any;
    export const collab_user_plus: any;
    export const collab_bell: any;
    export const collab_bell_slash: any;
    export const collab_message: any;
    export const collab_money: any;
    export const collab_clock: any;
    export const collab_clock_static: any;
    export const collab_test: any;
    export const collab_html: any;
    export const collab_typescript: any;
    export const collab_less: any;
    export const collab_fileTest: any;
    export const collab_record: any;
    export const collab_stop: any;
    export const collab_copy: any;
    export const collab_check: any;
    export const collab_double_check: any;
    export const collab_file: any;
    export const collab_location_dot: any;
    export const collab_rotate_left: any;
    export const collab_bug: any;
    export const collab_bug_x12: any;
    export const collab_unbalanced: any;
    export const collab_info: any;
    export const collab_info_circle: any;
    export const collab_question: any;
    export const collab_heart: any;
    export const collab_heart_o: any;
    export const collab_angles_right: any;
    export const collab_chevron_right: any;
    export const collab_chevron_left: any;
    export const collab_chevron_down: any;
    export const collab_undo: any;
    export const collab_clone: any;
    export const collab_file_pen: any;
    export const collab_trash: any;
    export const collab_ellipsis_vertical: any;
    export const collab_ban: any;
    export const collab_file_signature: any;
    export const collab_calendar_days: any;
    export const collab_user: any;
    export const collab_users: any;
    export const collab_book: any;
    export const collab_list_check: any;
    export const collab_folder_tree: any;
    export const collab_cube: any;
    export const collab_pen_nib: any;
    export const collab_plus: any;
    export const collab_bolt: any;
    export const collab_pencil: any;
    export const collab_cubes: any;
    export const collab_floppy_disk: any;
    export const collab_xmark: any;
    export const collab_arrow_up_long: any;
    export const collab_arrow_down_long: any;
    export const collab_arrows_up_down_left_right: any;
    export const collab_caret_righttv: any;
    export const collab_repeat: any;
    export const collab_thumbs_down_solid: any;
    export const collab_thumbs_down: any;
    export const collab_thumbs_up_solid: any;
    export const collab_thumbs_up: any;
    export const collab_edit_style: any;
    export const collab_play: any;
    export const collab_pause: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
    export const collab_commit: any;
    export const collab_branch: any;
    export const collab_pull_request: any;
    export const collab_arrows_rotate: any;
    export const collab_circle_notch: any;
    export const collab_triangle_exclamation: any;
    export const collab_circle_exclamation: any;
    export const collab_gear: any;
    export const collab_spinner_clock: any;
    export const collab_lock: any;
    export const collab_lock_open: any;
    export const collab_image: any;
    export const collab_unsplash: any;
    export const collab_video: any;
    export const collab_code: any;
    export const collab_ellipsis: any;
    export const collab_link: any;
    export const collab_border_top: any;
    export const collab_border_left: any;
    export const collab_border_bottom: any;
    export const collab_border_right: any;
    export const collab_border_topLeft: any;
    export const collab_border_bottomLeft: any;
    export const collab_border_bottomRight: any;
    export const collab_border_topRight: any;
    export const collab_margin_top: any;
    export const collab_margin_left: any;
    export const collab_margin_bottom: any;
    export const collab_margin_right: any;
    export const collab_padding_top: any;
    export const collab_padding_left: any;
    export const collab_padding_bottom: any;
    export const collab_padding_right: any;
}
declare module "_100555_/l2/pluginProject/pluginProjectInfo" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectInfo extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        project: number | undefined;
        projectName: string | undefined;
        projectDriver: "local" | "mls" | "GitHub" | "GitLab";
        projectOrg: string | undefined;
        projectOwner: string | undefined;
        projectCreatedAt: string | undefined;
        projectURL: string | undefined;
        projectDescription: string | undefined;
        forks: mls.stor.others.IFork[] | undefined;
        branches: mls.stor.others.IBranch[] | undefined;
        deps: IDependenciesInfo[];
        isSavingDeps: boolean;
        labelOk: string;
        labelError: string;
        labelErrorDeps: string;
        isAddingDep: boolean;
        newDepId: number | null;
        isEditingDeps: boolean;
        originalDeps: IDependenciesInfo[];
        isEditingInfo: boolean;
        isSavingInfo: boolean;
        labelOkInfo: string;
        labelErrorInfo: string;
        editName: string;
        editProjectURL: string;
        editProjectDriver: string;
        editProjectDescription: string;
        body: HTMLDivElement | undefined;
        private projectDetails;
        private projectSettings;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderBody(): TemplateResult;
        renderInfo(): TemplateResult;
        renderInfoViewMode(): TemplateResult;
        renderInfoEditMode(): TemplateResult;
        renderDependencies(): TemplateResult;
        renderDepsViewMode(): TemplateResult;
        renderDepsEditMode(): TemplateResult;
        private startEditingDeps;
        private cancelEditingDeps;
        private startEditingInfo;
        private cancelEditingInfo;
        private handleSaveInfo;
        private saveInfo;
        private getActiveDeps;
        private isDepAdded;
        private isDepMoved;
        private get hasDepsChanges();
        private get hasInfoChanges();
        private moveDepUp;
        private moveDepDown;
        private toggleRemoveDependency;
        toggleAddDep(): void;
        private addDependency;
        private handleSaveDeps;
        private saveDeps;
        private updateFilesDeps;
        private getStor;
        private updateFilePck;
        private updateFileTsConfig;
        private updateFileConfig;
        private init;
        private getDependencies;
        private setInfos;
    }
    interface IDependenciesInfo {
        id: number;
        name: string;
        auth: string;
        unknown?: boolean;
        removed?: boolean;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectDetail" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import "_100555_/l2/pluginProject/pluginProjectInfo";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectDetail extends PluginBaseModule {
        contentproject: HTMLElement | undefined;
        contentprojectinfo: HTMLElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        private loadProject;
        static styles: any;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectDetail.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginProjectDetail";
    import "_100555_/l2/pluginProject/pluginProjectInfo";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRendersRegardlessOfScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testLoadProjectNoServiceDetail(testCase: {
        expected: any;
    }): Promise<string>;
    export function testLoadProjectFromServiceDetail(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginProjectFindFiles.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginProjectFindFiles" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { MindMapData } from "_102027_/l2/libMindMap";
    import '/_100554_/l2/widgetMindMapL4.js';
    export class PluginProjectFindFiles extends PluginBaseModule {
        private msg;
        private matchedFiles;
        private usingRegex;
        private progressValue;
        mode: 'list' | 'map';
        dataJson: MindMapData | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        renderList(): any;
        renderMap(): any;
        onSearch(): Promise<void>;
        searchFiles(files: string[], searchText: string): Promise<void>;
        changeMode(e: MouseEvent): void;
        configMode(): void;
        openFile(e: MouseEvent): void;
        fireEvents(action: string, file: mls.stor.IFileInfo, timeout?: number): Promise<void>;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100555_/l2/pluginProject/pluginProjectFindFiles.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginProjectFindFiles";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderModeSwitch(testCase: {
        input: {
            mode: 'list' | 'map';
        };
        expected: any;
    }): Promise<string>;
    export function testConfigModeDropsMissingFiles(testCase: {
        input: {
            matchedFiles: string[];
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginProjectInfo.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginProjectInfo.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginProjectInfo";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testAddDependencyGuards(testCase: {
        input: {
            project: number;
            newDepId: number | null;
            existingDeps: {
                id: number;
                name: string;
                auth: string;
            }[];
        };
        expected: any;
    }): Promise<string>;
    export function testMoveDep(testCase: {
        input: {
            method: 'up' | 'down';
            index: number;
            ids: number[];
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginProjectReadMe.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/collabEditMd" {
    import { LitElement } from 'lit';
    export function initEditorQuillMD(): boolean;
    export class CollabEditMd extends LitElement {
        private value;
        private opened;
        containerEditor: HTMLElement | undefined;
        containerQuillEditor: HTMLTextAreaElement | undefined;
        iconFinish: HTMLElement | undefined;
        iconEdit: HTMLElement | undefined;
        set cbFinishEdit(fc: Function);
        get text(): any;
        firstUpdated(changedProperties: any): void;
        private cbFinishFc;
        private openedToolbar;
        id: string;
        easyMDE: any;
        editor: any;
        private initEditor;
        private onOpenedChanged;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private _initEditor;
        private onEditClick;
        private onFinishClick;
        render(): any;
        static styles: any;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectReadMe" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { CollabEditMd } from "_100555_/l2/utils/collabEditMd";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectReadMe extends PluginBaseModule {
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        mkEditor: CollabEditMd | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private renderReadme;
        private setReadme;
        private onChangeMd;
        private createFile;
        _getValueInfo(file: mls.stor.IFileInfo, originalShortName?: string, originalFolder?: string, originalProject?: number, originalCRC?: string): Promise<mls.stor.IFileInfoValue>;
        static styles: any;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectReadMe.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginProjectReadMe";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testAutoPrepareGuard(testCase: {
        input: {
            autoPrepare: boolean;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginProjectRunTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/tsTestMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines(model: monaco.editor.ITextModel): string[];
        replaceLines(model: monaco.editor.ITextModel, lineNrInit: number, lineNrInitEnd: number, newContent: string): boolean;
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine(model: monaco.editor.ITextModel, lineNr: number, line: string): boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine(model: monaco.editor.ITextModel, lineNr: number): boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines(model: monaco.editor.ITextModel, startLine: number, countLines: number): boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine(model: monaco.editor.ITextModel, lineNr: number, columnNr: number, newText: string): boolean;
        /**
         * Moves the editor's cursor to the specified lines, selects the text between them,
         * and scrolls the editor to bring the selection into view.
         *
         * @param {monaco.editor.ITextModel} model - The text model associated with the editor.
         * @param {number} start - The starting line number for the selection.
         * @param {number} end - The ending line number for the selection.
         *
         * @returns {void}
         */
        goTo(model: monaco.editor.ITextModel, start: number, end: number): void;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (model: monaco.editor.ITextModel) => void;
    }
}
declare module "_100555_/l2/utils/tsTestAST" {
    import { MonacoDriver } from "_100555_/l2/utils/tsTestMonaco";
    /**
     * Represents an AST node.
     * @typedef {Object} ASTNode
     * @property {string} type - The type of the AST node (e.g., 'Program', 'FunctionDeclaration').
     * @property {string} [name] - The name of the node (e.g., function name).
     * @property {any} [value] - The value associated with the node (e.g., function body or array content).
     * @property {ASTNode[]} [children] - An array of child nodes.
     * @property {number} [startLine] - The start line of the node in the source code.
     * @property {number} [endLine] - The end line of the node in the source code.
     */
    type ASTNode = {
        type: string;
        name?: string;
        value?: any;
        children?: ASTNode[];
        startLine: number;
        endLine: number;
    };
    /**
     * Class to parse a TypeScript test file and generate an AST.
     */
    export class TsTestAst {
        ast: ASTNode | undefined;
        modelTest: mls.editor.IModelTest | undefined;
        monacoDriver: MonacoDriver;
        editor: monaco.editor.IStandaloneCodeEditor;
        /**
         * Creates an instance of TsTestAst.
         * @param {mls.editor.IModelTest} modelTest - The Monaco editor model test instance.
         */
        constructor(modelTest: mls.editor.IModelTest, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * Parses the TypeScript code from the model test and returns the AST.
         * @returns {ASTNode | undefined} The generated AST, or undefined if parsing fails.
         */
        parse: () => ASTNode | undefined;
        /**
         * Gets the integrations from the parsed AST.
         * @returns {any[]} The integrations parsed from the AST.
         */
        getIntegrations(): ICANIntegration[];
        /**
         * Gets the tests from the parsed AST.
         * @returns {any[]} The tests parsed from the AST.
         */
        getTests(): ICANTest[];
        /**
         * Adds a new test to the AST and inserts it into the test array in the Monaco editor.
         * @param {ICANTest} test - The test object to be added.
         * @param {Function} fcTest - The test function to be associated with the test.
         * @returns {boolean} True if the test was added successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        addTest(test: ICANTest, fcTest: Function | string): boolean;
        /**
         * Deletes a test from the AST and updates the Monaco editor.
         * @param {String} testName - The test name to be removed.
         * @returns {boolean} True if the test was removed successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        deleteTest(testName: string, index?: number): boolean;
        /**
         * Navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        goToTest(testName: string): boolean;
        /**
         * Retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        getTestInfo(functionName: string, paramsIndex?: number): ITestInfo;
        /**
        * Executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        runTest(testName: string, paramsIndex?: number): Promise<string>;
        /**
         * Adds a new integration to the test file.
         * @param {ICANIntegration} integration - The integration to be added.
         * @param {Function} fc - The function associated with the integration.
         * @returns {boolean} Returns true if the integration was successfully added.
         */
        addIntegration(integration: ICANIntegration, fc: Function | string): boolean;
        /**
         * Parses TypeScript code into an AST.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode} The generated AST from the code.
         */
        private parseTypeScript;
        /**
         * Parses imports from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the imports in the code.
         */
        private parseImports;
        /**
         * Parses arrays from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the arrays in the code.
         */
        private parseArrays;
        /**
         * Parses function names from TypeScript code and returns an array of function declarations as AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing function declarations in the code.
         */
        private parseFunctionNames;
        /**
         * Parses and retrieves the integrations from the AST's children.
         * @returns {ICANIntegration[]} The parsed integrations.
         * @throws {Error} Throws an error if parsing the integrations fails.
         */
        private _getIntegrations;
        /**
         * Parses and retrieves the tests from the AST's children.
         * @returns {ICANTest[]} The parsed tests.
         * @throws {Error} Throws an error if parsing the tests fails.
         */
        private _getTests;
        /**
         * Internal method to add a test to the AST and update the Monaco editor.
         * @param {ICANTest} test - The test object to add.
         * @param {Function} fcTest - The test function to add.
         * @returns {boolean} True if the test was successfully added.
         * @throws {Error} Throws an error if the test already exists or AST information is missing.
         */
        private _addTest;
        /**
         * Internal method to deletes a test from the AST and updates the Monaco editor.
         * @param {string} testName - The name of the test to delete.
         * @throws {Error} Throws an error if the test does not exist or deletion fails.
         */
        private _deleteTest2;
        /**
     * Internal method to delete a test from the AST and update the Monaco editor.
     * @param {string} functionName - The name of the test to delete.
     * @param {number} [index] - (Optional) The index of the parameter to remove.
     * @throws {Error} Throws an error if the test does not exist or deletion fails.
     */
        private _deleteTest;
        /**
        * Internal method to executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        private _runTest;
        /**
         * Internal method to retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        private _getTestInfo;
        /**
         * Internal method to navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        private _goToTest;
        /**
         * Intenal method to delete a function on the AST and updates the Monaco editor.
         * @param {String} fcName - The function name to be deleted.
         * @returns {boolean} True if the function was successfully deleted.
         * @throws {Error} Throws an error if the test model is invalid.
         */
        private _deleteFunction;
        /**
         * Adds a new integration to the AST and updates the Monaco editor.
         * @param {ICANIntegrations} integration - The integration object to add.
         * @param {Function} fcIntegration - The integration function to add.
         * @throws {Error} Throws an error if the integration already exists or if AST information is missing.
         */
        private _addIntegration;
        /**
         * Deletes an integration from the AST and updates the Monaco editor.
         * @param {string} integrationName - The name of the integration to delete.
         * @throws {Error} Throws an error if the integration does not exist or deletion fails.
         */
        private _deleteIntegration;
        /**
         * Adds a new function to the AST and updates the Monaco editor.
         * @param {Function} fc - The function to add.
         * @returns {boolean} True if the function was successfully added.
         * @throws {Error} Throws an error if AST information is missing or the test model is invalid.
         */
        private _addFunction;
        private checkImports;
        /**
         * Adds an import statement to the TypeScript code.
         * If an interval is provided, it replaces the existing import.
         * Otherwise, it inserts the import after the root startLine.
         *
         * @param {string} value - The import statement to add.
         * @param {Object} [interval] - The optional start and end line to replace.
         */
        private _addImport;
        private _formatEditor;
    }
    export interface ITestInfo {
        fileName: string;
        functionName: string;
        params: Record<string, any>;
    }
    export interface ICANTest {
        functionName: string;
        params: Record<string, any>[];
    }
    export interface ICANIntegration {
        enabled: boolean;
        description: string;
        page: string;
        functionName: string;
        schema: Record<string, ICANSchema>;
    }
    export interface ICANSchema {
        type: string;
        optional?: boolean;
        description?: string;
    }
}
declare module "_102027_/l2/collabPageElement" {
    import { PropertyValueMap, LitElement } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export const PREFIX_ICA_ID = "ica_";
    export function toPascalCase(str: string): string;
    export abstract class CollabPageElement extends StateLitElement {
        abstract initPage(): void;
        modeoverlay: string;
        initPageComplete: boolean;
        level: string;
        overlay: any | undefined;
        isPage: boolean;
        recreateOverlay(): void;
        refreshOverlay(): void;
        constructor();
        createRenderRoot(): this;
        firstUpdated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): any;
        private setupIds;
        private checkToAddOverlay;
        private createOverlay;
        private hasImport;
        private importWCDOverlay;
        private findAllElementsIca;
    }
    export interface LitElementBaseMethods extends LitElement {
        level: '1' | '2' | '3' | '4' | '5' | '6' | '7' | undefined;
        globalVariation: number | undefined;
        baseName: string;
        overlayRef: HTMLElement | undefined;
        mySymbol: string;
        getActionsTags(): ActionTag[];
    }
    interface ActionTag {
        name: string;
        position?: 'p-l0' | 'p-l1' | 'p-l2' | 'p-l3' | 'p-l4' | 'p-m0' | 'p-m1' | 'p-m2' | 'p-m3' | 'p-m4' | 'p-r0' | 'p-r1' | 'p-r2' | 'p-r3' | 'p-r4' | 'p-title' | 'p-title-top' | '';
        args?: string;
        level?: number[];
        toolboxOptions?: IToolboxOptions;
    }
    export interface IToolboxOptions {
        background?: string;
        border?: string;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectRunTest" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import '/_100554_/l2/collabResultTest.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectRunTest extends PluginBaseModule {
        private msg;
        collabResultContainer: HTMLElement | undefined;
        progress: number;
        totalTest: number;
        totalTestPass: number;
        totalTestFailed: number;
        startTime: number;
        endTime: number;
        actualAllPagesTests: number;
        filesWithTest: string[];
        render(): TemplateResult;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private init;
        private exec;
        private clear;
        private countTotalTests;
        private calcProgress;
        private createModelsIfNeeded;
        private getTestsByFile;
        private getStorFilesWithTest;
        private addTestResultItem;
        private createPageContainer;
        private runTest;
        private delay;
        private runAllTests;
        private createResume;
        private createResumeFinal;
        private waitForPreviewLoaded;
        private waitForLitComponentsInIframe;
        private fireEvents;
        private onFinishTest;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectRunTest.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginProjectRunTest";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testCountTotalTests(testCase: {
        input: {
            tests: any;
        };
        expected: any;
    }): Promise<string>;
    export function testCalcProgress(testCase: {
        input: {
            sequence: {
                total: number;
                actual: number;
            }[];
        };
        expected: any;
    }): Promise<string>;
    export function testCreateResume(testCase: {
        input: {
            total: number;
            success: number;
            failed: number;
        };
        expected: any;
    }): Promise<string>;
    export function testCreateResumeFinal(testCase: {
        input: {
            total: number;
            success: number;
            failed: number;
            start: number;
            end: number;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginProject/pluginProjectUsage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginProjectUsage" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectUsage extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        designSystems: number | undefined;
        projectLastModified: string | undefined;
        files: number | undefined;
        chartData: {};
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private renderResume;
        static styles: any;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectUsage.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginProject/pluginProjectUsage";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginActiveUsers extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginErrors extends PluginBaseModule {
        filter: string;
        chartData: {};
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            filter: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExpenses extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginRegionalLatency extends PluginBaseModule {
        filter: string;
        chartDataBar: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        bar: HTMLDivElement | undefined;
        map: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginResponseTime extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSales extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSiteMonitorDashboard/pluginSales";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSpikes extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginLessPseudo.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginLessPseudo" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginLessPseudo extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100555_/l2/pluginStyle/pluginLessPseudo.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginLessPseudo";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testRendersReferenceList(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleBackground.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/lessMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines: (url: string) => string[];
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine: (url: string, lineNr: number, line: string) => boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine: (url: string, lineNr: number) => boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines: (url: string, startLine: number, countLines: number) => boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine: (url: string, lineNr: number, columnNr: number, newText: string) => boolean;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (url: string) => void;
    }
}
declare module "_100555_/l2/utils/lessAST" {
    import { MonacoDriver } from "_100555_/l2/utils/lessMonaco";
    interface ILessAST {
        root: {
            [token: string]: {
                value: string;
                line: number;
                column: number;
            };
        };
        [selector: string]: {
            _startLine?: number;
            _endLine?: number;
            [property: string]: {
                value: string;
                line: number;
                column: number;
            } | number | undefined;
        };
    }
    /**
     * @class LessAst
     *
     * This class parses a LESS model, building an AST and converting LESS selectors
     * into a CSS-compatible format. Note that this implementation supports only a subset
     * of LESS functionalities. Advanced features, such as variable interpolation within selectors,
     * parameterized mixins, and color manipulation functions, are not supported.
     *
     * ### Supported Features
     * - **Basic Selector Nesting**: Supports nesting selectors with `&`, converting them to a CSS-compatible format.
     * - **Simple Variables**: Allows the use of variables within properties (e.g., `@color-primary: #333;`).
     * - **Basic LESS Structure**: Parses basic selectors, properties, and tokens, ignoring advanced logic.
     *
     * ### Unsupported Features
     * - **Variable Interpolation within Selectors**: Selectors like `@{variable}-name` are not expanded in the AST.
     * - **Parameterized Mixins**: Mixins with parameters are not evaluated or expanded.
     * - **Mathematical and Color Functions**: Functions like `darken`, `lighten`, or `add` are not processed.
     * - **Looping and Iteration**: Constructs such as `each` or `for` are ignored, as they are not supported in CSS.
     * - **Global Scope Management**: Selectors with `:global` will not retain global scoping behavior.
     *
     * ### Usage Example
     * ```typescript
     * const lessAst = new LessAst("your-url");
     * lessAst.parse();
     * const cssSelector = lessAst.selectorLESS2CSS("less-a-s-t-100554 &:hover");
     * console.log(cssSelector); // Output: less-a-s-t-100554:hover
     * ```
     *
     * ### Limitations
     * Since this class does not handle dynamic processing features of LESS, it is recommended
     * only for static LESS-to-CSS conversions that do not require runtime evaluation.
     */
    export class LessAst {
        ast: ILessAST;
        url: string;
        monacoDriver: MonacoDriver;
        stack: string[];
        constructor(url: string, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * parse a full LESS model (monaco editor)
         */
        parse: () => void;
        /**
         * Parses a single line and updates the AST accordingly.
         */
        private parseLine;
        /**
         * Finds the column index where the given `value` starts in the provided `line`.
         *
         * This method calculates the precise position of the `value` in the string `line`
         * after the first occurrence of a colon (`:`), considering any leading spaces.
         * If the `value` is not found or the colon is absent, it returns undefined.
         *
         * @param {string} line - The line of text to be searched.
         * @param {string} value - The target string to locate within the `line`.
         * @returns {number} - The zero-based index of the starting position of `value` in `line`,
         *                     or undefined if the colon or value is not found.
         *
         * @example
         * // Example 1:
         * const line = "        text-shadow: 3em -8em 3em;";
         * const value = "3em -8em 3em";
         * findColumn(line, value); // Returns: 23
         *
         * // Example 2:
         * const line = "        flex-wrap: wrap;";
         * const value = "wrap";
         * findColumn(line, value); // Returns: 21
         *
         * // Example 3:
         * const line = "invalid line without colon";
         * const value = "anything";
         * findColumn(line, value); // Returns: undefined
         */
        private findColumn;
        /**
         * Lists all themes available in the AST.
         * Each theme is identified by its selector. If the selector has a `.`, the part after the dot is the theme name.
         * If no dot is present, the theme is named "default".
         *
         * @returns An object where each key is a theme name (e.g., "default", "theme2") and each value is the corresponding selector.
         */
        listThemes(): {
            [themeName: string]: string;
        };
        /**
         * Adds a new theme to the specified component variation.
         *
         * @param variation The name of the new theme variation (e.g., "theme3").
         * @returns `true` if the theme was added successfully, `false` otherwise.
         */
        addTheme(variation: string): boolean;
        /**
         * Deletes a theme from the specified component variation.
         *
         * @param variation The name of the theme variation to delete (e.g., "theme2").
         * If `null`, deletes the "default" theme (the main component selector).
         * @returns `true` if the theme was deleted successfully, `false` otherwise.
         */
        deleteTheme(variation: string | null): boolean;
        /**
         * Retrieves the description comments for a specified theme.
         *
         * @param variation The name of the theme variation (e.g., "theme2").
         *                  If `null`, retrieves the "default" theme.
         * @returns An array of comment lines that describe the theme, or an empty array if no comments are found.
         */
        getThemeDescription(variation: string | null): string[];
        private getThemeRangeLines;
        /**
         * Converts a full CSS selector back to the LESS format using "&" where appropriate.
         * - If the selector parts match a parent selector, it replaces the match with "&".
         *
         * @param selector The CSS selector to convert to LESS format.
         * @returns The converted LESS format selector with "&" where possible.
         */
        selectorCSS2LESS: (selector: string) => string;
        selectorLESS2CSS: (selector: string) => string;
        /**
         * Converts a kebab-case property name to camelCase, e.g., background-color to backgroundColor.
         * This ensures property names align with JavaScript/TypeScript conventions.
         */
        toCamelCaseProperty(property: string): string;
        /**
         * Converts a camelCase property name to kebab-case, e.g., backgroundColor to background-color.
         * This ensures property names align with CSS/LESS conventions.
         */
        toKebabCaseProperty(property: string): string;
        getProperty(selector: string, property: string): string | undefined;
        private updateASTAfterInsertLine;
        saveProperty(selector: string, property: string, newValue: string | undefined): boolean;
        /**
         * Returns the last line number within a selector block. aka "}"
         */
        findLastLineInSelector(selectorLESS: string): number;
        findInfoByLine(selectorLESS: string, lineNumber: number): {
            key: string;
            value: string;
        } | undefined;
        /**
         * Finds the most specific LESS selector path for a given line number in the source.
         * - This method searches the AST to determine the most specific selector block containing the specified line.
         * - It returns the full path of the most deeply nested selector in LESS format (e.g., `.cl1 .cl2 &:hover`).
         *
         * ### Usage
         * This method is useful for identifying the exact selector block a line belongs to, especially
         * in scenarios where nested selectors exist in the LESS structure.
         *
         * @param lineNr The line number to check for a corresponding selector.
         * @returns The most specific LESS selector path as a string if found; otherwise, `undefined`.
         */
        findSelectorByLine(lineNr: number): string | undefined;
        /**
         * Finds the start line of the first selector after the root in a JSON representation of a stylesheet.
         *
         * @param json - A JSON object representing a stylesheet, where keys are selectors and values contain metadata.
         * @param tagName - The tag name to exclude from the search.
         * @returns The start line of the first selector after the root, or `null` if no such selector exists.
         */
        findFirstSelectorAfterRoot(ast: Record<string, any>): number | null;
        /**
         * Inserts a new selector into the AST and the Monaco model if it does not exist.
         * - Example: If the AST only contains ".cl1" and `newSelectorLESS` is ".cl1 .cl2 &:hover",
         *   the function will:
         *   1. Check if ".cl1 .cl2" exists in the AST.
         *   2. If not, insert ".cl2" as a nested block within ".cl1".
         *   3. Then insert "&:hover" as a nested selector inside ".cl1 .cl2".
         *
         * This function supports nested selectors by iteratively checking each level
         * and inserting any missing selectors in sequence.
         *
         * @param newSelectorLESS The LESS selector to add to the AST and source code.
         * @result start line of the block
         */
        insertSelector(newSelectorLESS: string): number;
    }
}
declare module "_100555_/l2/utils/lessCSS" {
    import { LessAst } from "_100555_/l2/utils/lessAST";
    /**
     * A unique symbol used as a key for properties that should be ignored during JSON serialization.
     *
     * Properties defined with this symbol as a key will not appear in the output of `JSON.stringify`,
     * ensuring that the property is excluded from serialization while avoiding key collisions.
     *
     * @const {symbol} ignoredProperty - A unique symbol for marking non-serializable properties.
     */
    const _editor: unique symbol;
    export class LessCSS {
        lessAST: LessAst;
        selector: string;
        position: "left" | "right";
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        _url: string;
        styles: CSSStyleDeclaration;
        constructor(url: string, editor: monaco.editor.IStandaloneCodeEditor, position?: "left" | "right");
        setEditor(editor: monaco.editor.IStandaloneCodeEditor): void;
        /**
         * Sets the current selector for which properties will be applied.
         */
        setSelector(selector: string): void;
        /**
         * Retrieves a specific CSS property value for the current selector from the AST.
         * @param property The CSS property to retrieve
         */
        getProperty(property: string): string | undefined;
        /**
         * Sets or updates a CSS property in the AST and source model.
         * @param property The CSS property to set
         * @param value The new value for the property
         */
        setProperty(property: string, value: string): void;
        refresh(): void;
        setStateByLine(lineNumber: number, lineContent: string, emitter: 'editor' | 'helper' | 'preview'): void;
        private clearState;
        private updateState;
        private initStateIfNeeded;
    }
    export interface ICSSState {
        uri: string;
        selector: string | undefined;
        lineNumber: number | undefined;
        lineContent: string | undefined;
        key: string | undefined;
        value: string | undefined;
        lessCSS: LessCSS | undefined;
        emitter: 'editor' | 'helper' | 'preview';
    }
}
declare module "_100555_/l2/utils/collabDsInputSelectColor" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export function initCollabDsInputSelectColor(): void;
    export class CollabDsInputSelectColor extends CollabLitElement {
        get value(): string;
        set value(str: string);
        get valueInput(): string;
        set valueInput(str: string);
        get valueSelect(): string;
        set valueSelect(str: string);
        get valueColor(): string;
        set valueColor(str: string);
        arrayInputSelect: string[];
        arraySelect: string[];
        _valueInput: string;
        _valueSelect: string;
        _valueColor: string;
        prop: string;
        useInput: string;
        useSelect: string;
        useColor: string;
        render(): any;
        renderInput(): any;
        renderSelect(): any;
        renderColor(): any;
        updated(): void;
        private configGetValue;
        private configSetValue;
        private onlyNumber;
        private onlyTxt;
        private handleWhell;
        private changeInput;
        private allChange;
        private fireEvents;
    }
}
declare module "_100555_/l2/utils/collabDsInputRange" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export function initCollabDSInputRange(): void;
    export class CollabDSInputRange extends StateLitElement {
        arraySelect: string[];
        useSelect: string;
        value: string;
        valueInput: string;
        prop: string;
        min: number;
        max: number;
        render(): any;
        renderSelect(): any;
        updated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private cursorPosition;
        private onlyNumber;
        private onlyTxt;
        private handleWhell;
        private changeInput;
        private changeSelect;
        private allChange;
        private fireEvents;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleBackground" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginCssTokens extends StateLitElement {
        private msg;
        showFull: string;
        position: 'left' | 'right';
        info: IMyInfoBackground;
        css: string;
        state: ICSSState | undefined;
        private actualKey;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private setValues;
        private findCSSRuleInIframe;
        render(): any;
        renderBody2(): any;
        renderBody(): any;
        renderConfig(): any;
        renderAux(): any;
        renderItens(): any;
        renderGallery(): any;
        private clickGallery;
        private onlyNumber;
        private changeType;
        private add;
        private del;
        private configString;
        private rgbaToHex;
        private hexToRgba;
        private changeStr;
        private timeonChangeProp;
        private onChangeProp;
        private onChangeAux;
        private changeValues;
        private mountMyValue;
        private setState;
        private arrayGallery;
    }
    interface IMyInfoBackground {
        tp: string;
        aux: string;
        itens: {
            value: string;
            transp: string;
            stop: string;
        }[];
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleBackground.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleBackground";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            presetCss: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleBorder.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleBorder" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { CollabDsInputSelectColor } from "_100555_/l2/utils/collabDsInputSelectColor";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleBorder extends StateLitElement {
        private msg;
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        borderLocked: boolean;
        borderRadiusLocked: boolean;
        borderLeft: string | undefined;
        borderRight: string | undefined;
        borderTop: string | undefined;
        borderBottom: string | undefined;
        borderLeftWidth: string | undefined;
        borderRightWidth: string | undefined;
        borderTopWidth: string | undefined;
        borderBottomWidth: string | undefined;
        borderLeftStyle: string | undefined;
        borderRightStyle: string | undefined;
        borderTopStyle: string | undefined;
        borderBottomStyle: string | undefined;
        borderLeftColor: string | undefined;
        borderRightColor: string | undefined;
        borderTopColor: string | undefined;
        borderBottomColor: string | undefined;
        borderTopLeftRadius: string | undefined;
        borderTopRightRadius: string | undefined;
        borderBottomLeftRadius: string | undefined;
        borderBottomRightRadius: string | undefined;
        inputLockRadius: HTMLInputElement | undefined;
        inputLock: HTMLInputElement | undefined;
        borderInputs: CollabDsInputSelectColor[] | undefined;
        borderRadiusInputs: HTMLInputElement[] | undefined;
        private tpMeasures;
        private tpBorder;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        render(): any;
        renderBorder(): any;
        renderBorderRadius(): any;
        renderBorderGallery(): any;
        private timeonChangeBorder;
        private handleChangeBorder;
        private timeonChangeBorderRadius;
        private handleChangeBorderRadius;
        private handleChangeLockBorderRadius;
        private handleChangeLockBorder;
        private _onIcaStateChange;
        private setBorderValues;
        private setState;
        private updateBorderRadius;
        private updateBorder;
        private setValues;
        private checkBorderEquals;
        private checkBorderRadiusEquals;
        private replaceTokens;
        private findCSSRuleInIframe;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleBorder.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleBorder";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            galleryIndex: number;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleBoxShadow.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleBoxShadow" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleBoxShadow extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        boxShadow: string | undefined;
        color: string | undefined;
        spread: string | undefined;
        boxBlur: string | undefined;
        offsetY: string | undefined;
        offsetX: string | undefined;
        shadowMode: 'inset' | 'outset';
        private tpMeasures;
        private msg;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues2;
        private setValues;
        private mountValue;
        private setState;
        private timeonChangeProp;
        private handleChange;
        render(): any;
        renderBoxShadow(): any;
        renderGallery(): any;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleBoxShadow.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleBoxShadow";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            galleryIndex: number;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleClippath.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleClippath" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleClipath extends StateLitElement {
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        clipPath: string | undefined;
        svgOverlay: HTMLElement | undefined;
        output: HTMLTextAreaElement | undefined;
        image: HTMLImageElement | undefined;
        pointsContainer: HTMLDivElement | undefined;
        private msg;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues;
        render(): any;
        renderGallery(): any;
        renderPreviewEditable(): any;
        private points;
        private parameters;
        private currentTemplate;
        private shapeType;
        private outputRes;
        private renderClipPath;
        private applyChanges;
        private timeonChange;
        private handleChangeCss;
        private setState;
        private initClipPathMaker;
        private setParameters;
        private identifyShapeType;
        private arrayGallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleClippath.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleClippath";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            presetCss: string;
            presetName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleColumn.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleColumn" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { CollabDsInputSelectColor } from "_100555_/l2/utils/collabDsInputSelectColor";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleColumn extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        columnCount: string | undefined;
        columnWidth: string | undefined;
        columnGap: string | undefined;
        columnSpan: string | undefined;
        columnRule: string | undefined;
        columnRuleColor: string | undefined;
        columnRuleStyle: string | undefined;
        columnRuleWidth: string | undefined;
        breakInside: string | undefined;
        columnRuleInputs: CollabDsInputSelectColor[] | undefined;
        private msg;
        private tpMeasures;
        private tpBorder;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private setValues;
        private findCSSRuleInIframe;
        private setColumnRuleValues;
        private setState;
        private timeonChange;
        private handleChange;
        render(): any;
        renderColumn(): any;
        renderGallery(): any;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleColumn.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleColumn";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            presetStyle: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleCursor.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleCursor" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleClipath extends StateLitElement {
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        render(): any;
        renderGallery(): any;
        private timeonChange;
        private handleChangeCss;
        private setState;
        private arrayGallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleCursor.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleCursor";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyCursor(testCase: {
        input: {
            presetCss: string;
            presetName: string;
        };
        expected: any;
    }): Promise<string>;
    export function testApplyCursorGuardClause(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleFilter.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleFilter" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleFilter extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        filter: string | undefined;
        grayscale: string | undefined;
        filterBlur: string | undefined;
        sepia: string | undefined;
        saturate: string | undefined;
        opacity: string | undefined;
        brightness: string | undefined;
        contrast: string | undefined;
        huerotate: string | undefined;
        invert: string | undefined;
        private msg;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues;
        private setValues2;
        render(): any;
        renderFilter(): any;
        renderGallery(): any;
        private mountValue;
        private setState;
        private timeonChangeProp;
        private handleChange;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleFilter.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleFilter";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            presetStyle: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleFlex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleFlex" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleFlex extends StateLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        render(): any;
        renderFlex(): any;
        renderFlexItem(): any;
        renderGallery(): any;
        private _onIcaStateChange;
        private setValues;
        private timeonChange;
        private handleChangeCss;
        private handleChangeGalleryCss;
        private setState;
        private arrayGallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleFlex.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleFlex";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyFlexChange(testCase: {
        input: {
            prop: string;
            value: string;
        };
        expected: any;
    }): Promise<string>;
    export function testApplyFlexChangeWithoutState(testCase: {
        input: {
            prop: string;
            value: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleIndexItem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleIndexItem" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class PluginStyleIndexItem extends CollabLitElement {
        help: any | undefined;
        position: 'left' | 'right';
        mode: 'collapsed' | 'expanded' | 'full';
        pluginLoaded: boolean;
        firstUpdated(): void;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private pluginEl;
        private openPlugin;
        handleOpenPlugin(e: MouseEvent, help: any, close?: boolean): Promise<void>;
        handleExpandedClick(e: MouseEvent): Promise<void>;
        handleFullClick(e: MouseEvent): void;
        handleLikeClick(e: MouseEvent): Promise<void>;
        handleInfoClick(e: MouseEvent): Promise<void>;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleIndexItem.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleIndexItem";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testHandleLikeClick(testCase: {
        input: {
            liked: boolean;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleInfoClick(testCase: {
        input: {
            showInfo: boolean;
        };
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleMargin.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleMargin" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleSpacing extends StateLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        marginLocked: boolean;
        marginLeft: string | undefined;
        marginRight: string | undefined;
        marginTop: string | undefined;
        marginBottom: string | undefined;
        inputLockM: HTMLInputElement | undefined;
        marginInputs: HTMLInputElement[] | undefined;
        private tpMeasures;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        render(): any;
        renderMargin(): any;
        renderGallery(): any;
        private _onIcaStateChange;
        private timeonChangeMargin;
        private handleChangeMargin;
        private handleChangeLockMargin;
        private setState;
        updateMargins(margin: string | {
            [key: string]: string;
        }): void;
        private setValues;
        private checkMarginsEquals;
        private findCSSRuleInIframe;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleMargin.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleMargin";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            presetStyle: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStylePadding.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStylePadding" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStylePadding extends StateLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        paddingLocked: boolean;
        paddingLeft: string | undefined;
        paddingRight: string | undefined;
        paddingTop: string | undefined;
        paddingBottom: string | undefined;
        inputLockP: HTMLInputElement | undefined;
        paddingInputs: HTMLInputElement[] | undefined;
        private tpMeasures;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        render(): any;
        renderPadding(): any;
        renderGallery(): any;
        private _onIcaStateChange;
        private timeonChangePadding;
        private handleChangePadding;
        private handleChangeLockPadding;
        private setState;
        updatePadding(padding: string | {
            [key: string]: string;
        }): void;
        private setValues;
        private checkPaddingEquals;
        private findCSSRuleInIframe;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStylePadding.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStylePadding";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            presetStyle: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleTextShadow.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleTextShadow" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleTextShadow extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        textShadow: string | undefined;
        offSetX: string | undefined;
        offSetY: string | undefined;
        textBlur: string | undefined;
        color: string | undefined;
        private msg;
        private tpMeasures;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues;
        private setValues2;
        private arrayGallery;
        private mountValue;
        private setState;
        private timeonChangeProp;
        private handleChange;
        render(): any;
        renderColumn(): any;
        renderGallery(): any;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleTextShadow.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleTextShadow";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            presetStyle: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleTokens.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleTokens" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginCssTokens extends StateLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        level: number;
        prop: string;
        value: string;
        theme: string;
        tokens: Record<string, Record<string, Record<string, string>>>;
        private needOrder;
        private getTokensColor;
        private groupColorsByState;
        handleColorClick(key: string, value: string): void;
        setTooltip(): void;
        getTokens(): Promise<void>;
        updated(changedProperties: any): void;
        firstUpdated(a: any): Promise<void>;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        render(): any;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleTokens.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleTokens";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testGroupColorsByState(testCase: {
        input: {
            items: {
                key: string;
                value: string;
            }[];
        };
        expected: any;
    }): Promise<string>;
    export function testHandleColorClick(testCase: {
        input: {
            prop: string;
            hasState: boolean;
            key: string;
            value: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            key: string;
            value: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginStyle/pluginStyleTransform.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginStyle/pluginStyleTransform" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ICSSState } from "_100555_/l2/utils/lessCSS";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    import "_100555_/l2/utils/collabDsInputSelectColor";
    import "_100555_/l2/utils/collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleTransform extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        transform: string | undefined;
        scaleX: string | undefined;
        scaleY: string | undefined;
        rotate: string | undefined;
        translateX: string | undefined;
        translateY: string | undefined;
        skewX: string | undefined;
        skewY: string | undefined;
        columnRuleInputs: HTMLInputElement[] | undefined;
        private msg;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues2;
        private setValues;
        private mountValue;
        private setState;
        private timeonChangeProp;
        private handleChange;
        render(): any;
        renderTransform(): any;
        renderGallery(): any;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100555_/l2/pluginStyle/pluginStyleTransform.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginStyle/pluginStyleTransform";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testApplyPreset(testCase: {
        input: {
            presetStyle: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleIcaStateChange(testCase: {
        input: {
            astProperties: Record<string, {
                value: string;
                line: number;
            }>;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginInfo(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSystem/pluginSystemLanguage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSystem/pluginSystemLanguage" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSystemLanguage100555 extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        actualLanguage: ILanguage;
        selectLanguage: HTMLSelectElement | undefined;
        firstUpdated(): void;
        prepare(): Promise<void>;
        private init;
        render(): TemplateResult;
        private getUserLanguage;
        private handleChangeLanguageClick;
        private setUserLanguage;
        private getUserDefault;
        private getNavigatorLanguage;
    }
    type ILanguage = 'pt-BR' | 'en-US' | 'default';
}
declare module "_100555_/l2/pluginSystem/pluginSystemLanguage.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSystem/pluginSystemLanguage";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testAutoPrepareGuard(testCase: {
        input: {
            autoPrepare: boolean;
        };
        expected: any;
    }): Promise<string>;
    export function testGetUserLanguage(testCase: {
        input: {
            userSettings: string | null;
        };
        expected: any;
    }): Promise<string>;
    export function testMessageLanguage(testCase: {
        input: {
            htmlLang: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSystem/pluginSystemTheme.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSystem/pluginSystemTheme" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSystemTheme100555 extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        actualTheme: string;
        selectTheme: HTMLSelectElement | undefined;
        firstUpdated(): void;
        prepare(): Promise<void>;
        private init;
        render(): TemplateResult;
        private handleChangeThemeClick;
        private getUserSettings;
        private setUserTheme;
        private getUserTheme;
        private getUserThemeOS;
    }
}
declare module "_100555_/l2/pluginSystem/pluginSystemTheme.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSystem/pluginSystemTheme";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testAutoPrepareGuard(testCase: {
        input: {
            autoPrepare: boolean;
        };
        expected: any;
    }): Promise<string>;
    export function testGetUserSettings(testCase: {
        input: {
            storedTheme: string | null;
            osDark?: boolean;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSystem/pluginSystemUser.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSystem/pluginSystemUser" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSystemLanguage100555 extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        consoleEnabled: boolean;
        inputConsole: HTMLInputElement | undefined;
        firstUpdated(): void;
        prepare(): Promise<void>;
        private init;
        private onChangeConsoleEnabled;
        render(): TemplateResult;
    }
}
declare module "_100555_/l2/pluginSystem/pluginSystemUser.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginSystem/pluginSystemUser";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testAutoPrepareGuard(testCase: {
        input: {
            autoPrepare: boolean;
        };
        expected: any;
    }): Promise<string>;
    export function testInitConsoleState(testCase: {
        input: {
            showAttr: string | null;
        };
        expected: any;
    }): Promise<string>;
    export function testOnChangeConsoleEnabled(testCase: {
        input: {
            checked: boolean;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginTester/pluginPluginRunTest" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    interface ITestCaseResult {
        functionName: string;
        env: string;
        index: number;
        status: 'pass' | 'fail';
        message: string;
    }
    interface ITestFileResult {
        file: string;
        status: 'ok' | 'import-error' | 'no-tests';
        error?: string;
        cases: ITestCaseResult[];
    }
    export class PluginPluginRunTest extends PluginBaseModule {
        private msg;
        running: boolean;
        hasRun: boolean;
        totalFiles: number;
        totalPassed: number;
        totalFailed: number;
        totalNoTests: number;
        results: ITestFileResult[];
        createRenderRoot(): this;
        render(): TemplateResult;
        private renderPlayIcon;
        private renderSpinnerIcon;
        private renderFileResult;
        runAll(): Promise<void>;
        private findTestFiles;
        private runFile;
        private logToConsole;
    }
}
declare module "_100555_/l2/pluginVerify/pluginVerifyError.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginVerify/pluginVerifyError" {
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export class PluginVerifyError extends PluginBaseModule {
        private msg;
        private continueVerify;
        find: string[];
        current: string;
        tot: string;
        error: string;
        autoPrepare: boolean;
        isLoad: boolean;
        listErrors: string[];
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        renderLoad(): any;
        renderHeader(): any;
        renderErros(): any;
        renderItem(i: string): any;
        prepare(): Promise<void>;
        private setFilesErros;
        private cancelVerify;
        private progressCallback;
        private fireEvent;
    }
}
declare module "_100555_/l2/pluginVerify/pluginVerifyError.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginVerify/pluginVerifyError";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginVerify/pluginVerifyErrorDesignSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginVerify/pluginVerifyErrorDesignSystem" {
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export class PluginVerifyErrorDesignSystem extends PluginBaseModule {
        private msg;
        private continueVerify;
        find: string[];
        current: string;
        tot: string;
        error: string;
        autoPrepare: boolean;
        isLoad: boolean;
        listErrors: string[];
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        renderLoad(): any;
        renderHeader(): any;
        renderErros(): any;
        renderItem(i: string): any;
        prepare(): Promise<void>;
        private compileAll;
        private setFilesErros;
        private cancelVerify;
        private progressCallback;
        private fireEvent;
    }
}
declare module "_100555_/l2/pluginVerify/pluginVerifyErrorDesignSystem.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginVerify/pluginVerifyErrorDesignSystem";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginView/pluginViewFile" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import "_102027_/l2/collabMonacoEditor";
    export class PluginViewFile extends PluginBaseModule {
        private msg;
        nameFile: string;
        current: number;
        file: mls.stor.IFileInfo | undefined;
        contentText: string;
        contentUrl: string;
        extension: string;
        msize: string;
        private editor;
        elEditor: IHTMLEditorElement | undefined;
        private _ed1;
        get confE(): string;
        firstUpdated(): void;
        updated(changedProps: Map<string, any>): void;
        private updateEditorContent;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderViewMode(): TemplateResult;
        renderInfoMode(): TemplateResult;
        private createModel;
        private createEditor;
        private init;
        private isImage;
        private isAudio;
        private isVideo;
        private isReadableText;
        private conf;
    }
    export const pluginData: mls.plugin.IPluginData;
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100555_/l2/pluginView/pluginViewFile.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    import "_100555_/l2/pluginView/pluginViewFile";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testMediaTypeDetection(testCase: {
        input: {
            extension: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/utils/collabDsInputRange.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/collabDsInputSelectColor.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/collabEditMd.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/collabIcons.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/lessAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/lessCSS.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/lessMonaco.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/projectAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/tsTestAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/tsTestMonaco.defs" {
    export const asis: mls.defs.AsIs;
}
