declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_100555_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_100555_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_100555_/l2/pluginExplore/collabInputSearch" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabInputSearch extends CollabLitElement {
        private msg;
        placeholder: string;
        value: string;
        private focused;
        firstUpdated(): void;
        render(): any;
        private _onInput;
        private _onFocus;
        private _onBlur;
        private _clear;
        private _onKeyDown;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_100555_/l2/pluginExplore/mlsFileTree" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    interface FileInfo {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    interface TreeNode {
        name: string;
        fullPath: string;
        isFolder: boolean;
        children: TreeNode[];
        fileKey?: string;
        extension?: string;
        file: mls.stor.IFileInfo;
    }
    export class MlsFileTree extends CollabLitElement {
        position: string | undefined;
        project: string | undefined;
        filter: string;
        files: Record<string, FileInfo>;
        private expanded;
        private selected;
        private _loading;
        private _loadingMsg;
        firstUpdated(): void;
        render(): any;
        private _renderOverlay;
        private renderFiltered;
        private highlightText;
        private renderNode;
        renderItem(node: TreeNode, depth: number): any;
        private deleteFile;
        private undoFile;
        private getTitleInLocalStorage;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private buildTree;
        private toggleFolder;
        private selectFile;
        private clickGroupHidden;
        private collectFilesFromNode;
        private delAllByFolders;
        private undoAllByFolders;
        private getLevel;
        private clearPath;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreList.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libHistoriesRecents" {
    export function addInHistory(file: mls.stor.IFileInfo): void;
    export function getHistory(): HistoryList;
    export function removeFromHistory(target: HistoryItem): void;
    export function renameHistoryItem(target: HistoryItem, newShortName: string): void;
    export function loadProjectHistory(): IHistoryProject[];
    export function saveProjectHistory(history: IHistoryProject[]): void;
    export function removeProjectFromHistory(projectId: number): void;
    export function renameProjectInHistory(projectId: number, newName: string): void;
    interface IHistoryProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    export interface HistoryItem {
        project: number;
        shortName: string;
        extension: string;
        folder: string;
    }
    type HistoryList = HistoryItem[];
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_102027_/l2/pluginBaseModule" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "../l2/pluginExplore/collabInputSearch" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabInputSearch extends CollabLitElement {
        private msg;
        placeholder: string;
        value: string;
        private focused;
        firstUpdated(): void;
        render(): any;
        private _onInput;
        private _onFocus;
        private _onBlur;
        private _clear;
        private _onKeyDown;
    }
}
declare module "../l2/pluginExplore/mlsFileTree" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    interface FileInfo {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    interface TreeNode {
        name: string;
        fullPath: string;
        isFolder: boolean;
        children: TreeNode[];
        fileKey?: string;
        extension?: string;
        file: mls.stor.IFileInfo;
    }
    export class MlsFileTree extends CollabLitElement {
        position: string | undefined;
        project: string | undefined;
        filter: string;
        files: Record<string, FileInfo>;
        private expanded;
        private selected;
        private _loading;
        private _loadingMsg;
        firstUpdated(): void;
        render(): any;
        private _renderOverlay;
        private renderFiltered;
        private highlightText;
        private renderNode;
        renderItem(node: TreeNode, depth: number): any;
        private deleteFile;
        private undoFile;
        private getTitleInLocalStorage;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private buildTree;
        private toggleFolder;
        private selectFile;
        private clickGroupHidden;
        private collectFilesFromNode;
        private delAllByFolders;
        private undoAllByFolders;
        private getLevel;
        private clearPath;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
    }
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "../l2/pluginExplore/pluginExploreListAddL1" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        service: ServiceBase | undefined;
        father: HTMLElement | undefined;
        level: number;
        error: string;
        position: string;
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        private handleInputInput;
        private clickCancel;
        private getNewNameAndValid;
        private showLoad;
        private createFile;
        private setHistory;
        private showError;
        private fireEvents;
    }
}
declare module "../l2/pluginNewFile/pluginNewFileBase" {
    export interface IDetails {
        title: string;
        description: string;
        tags: string[];
    }
    export function changeClassName(source: string, project: number, shortname: string): string;
    export function changeWidget(source: string, project: number, shortname: string): string;
    export function changeShortName(source: string, shortname: string): string;
    export function changeTagName(source: string, tagName: string): string;
    export function changeProject(source: string, project: number): string;
    export function changeFolder(source: string, folder: string): string;
    export function changeStateName(source: string, stateName: string): string;
    export function getTemplateImport(projectBase: number, shortName: string, folder: string): string;
    export interface IRequestNewFile {
        project: number;
        position: 'left' | 'right';
        shortName: string;
        folder?: string;
        enhancement: string;
        sourceTS: string;
        sourceHTML?: string;
        sourceLess?: string;
        sourceTest?: string;
        sourceDefs?: string;
        openPreview: boolean;
    }
    export function createNewFile(args: IRequestNewFile): Promise<void>;
}
declare module "../l2/pluginExplore/pluginExploreListAddL2" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        level: number;
        error: string;
        position: string;
        father?: ServiceBase | undefined;
        plugins: IPlugins[];
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        renderTemplates(): any;
        private goBack;
        private handleInputInput;
        private handleClickTemplate;
        private clickCancel;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private getPlugins;
        private getPluginsInfo;
    }
    interface IPlugins extends IDetails {
        widget: string;
        category: string | null;
    }
}
declare module "../l2/pluginExplore/pluginExploreListAddL3" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL3 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptOrganism: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "../l2/pluginExplore/pluginExploreListAddL4" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL4 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptPage: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private verifyModuleConfig;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreList" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import '/_100555_/l2/pluginExplore/collabInputSearch.js';
    import '/_100555_/l2/pluginExplore/mlsFileTree.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExploreList extends PluginBaseModule {
        createModels(stor: mls.stor.IFileInfo): Promise<void>;
        private resizeObserver;
        private myDep;
        private msg;
        service: ServiceBase | undefined;
        private filterByLevel;
        autoPrepare: boolean;
        mode: TModeExploreList;
        refresh: string;
        position: string;
        levelFiles: number;
        project: number;
        projectLabel: string;
        filterProject: number;
        modeView: number;
        hiddenFiles: boolean;
        errorAux: string;
        files: mls.stor.IFileInfo[];
        history: mls.stor.IFileInfo[];
        modeFilter: string | undefined;
        lis: HTMLElement[] | undefined;
        constructor();
        private info;
        prepare(): Promise<void>;
        private showAdd;
        private filesInLocal;
        private setEvents;
        private onlevelChange;
        private onMLSEvents;
        connectedCallback(): void;
        disconnectedCallback(): void;
        createRenderRoot(): this;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        renderModeList(): any;
        renderHeader(): any;
        renderHistory(): any;
        renderList(): any;
        renderFolder(): any;
        renderFolder2(files: mls.stor.IFileInfo[]): any;
        getTitleInLocalStorage(ts: mls.stor.IFileInfo, html: mls.stor.IFileInfo, less: mls.stor.IFileInfo, test: mls.stor.IFileInfo, defs: mls.stor.IFileInfo): string;
        renderLiItem(file: mls.stor.IFileInfo, index: number, inHistory: boolean): any;
        renderAddL1(): any;
        renderAddL2(): any;
        renderAddL3(): any;
        renderAddL4(): any;
        private getAllName;
        private showLoading;
        private showError;
        private closeAllMenus;
        private clickOptUndo;
        private clickOptDel;
        private clickOptOpen;
        private clickOptOpenSecurity;
        private clickOptRename;
        private clickOptClone;
        private cloneFile;
        private renameFile;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
        private fireEventThisProject;
        private fireEventLoadProject;
        private changeListTimeout;
        changeList(time?: number): void;
        private extensionLevel;
        private levelByLevel;
        private init;
        private setLastFilter;
        private getMyFileInElement;
        private clickGroupHidden;
        private changeSelectProject;
        private changeHiddenFiles;
        private changeModeOrder;
        private inFilter;
        private timeFilterChange;
        private searchTerm;
        private filterLiChange;
        private getFiles;
        private filterArrayHistory;
        private validFileByLevel;
        private getFilesProject;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private getFileHistory;
        private isValidNewName;
        private initObserverResize;
        private saveLocalStorageLastOpen;
        private delAllByFolders;
        private loadLastPreference;
        private getLastModeFilter;
        private setLastPreference;
    }
    type TModeExploreList = 'list' | 'addL1' | 'addL2' | 'addL3' | 'addL4';
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL1" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        service: ServiceBase | undefined;
        father: HTMLElement | undefined;
        level: number;
        error: string;
        position: string;
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        private handleInputInput;
        private clickCancel;
        private getNewNameAndValid;
        private showLoad;
        private createFile;
        private setHistory;
        private showError;
        private fireEvents;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL2" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        level: number;
        error: string;
        position: string;
        father?: ServiceBase | undefined;
        plugins: IPlugins[];
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        renderTemplates(): any;
        private goBack;
        private handleInputInput;
        private handleClickTemplate;
        private clickCancel;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private getPlugins;
        private getPluginsInfo;
    }
    interface IPlugins extends IDetails {
        widget: string;
        category: string | null;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL3" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL3 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptOrganism: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL4" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL4 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptPage: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private verifyModuleConfig;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "../l2/pluginNewFile/widgetTextCode" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class WidgetTextCode extends CollabLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        setCode(): void;
        firstUpdated(): void;
        render(): any;
        private onChangeText;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileAgent" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import '/_100555_/l2/pluginNewFile/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileBlank extends StateLitElement {
        shortName: string | undefined;
        folder: string | undefined;
        project: number | undefined;
        position: 'left' | 'right';
        loading: boolean;
        templateType: AgentTemplateType;
        private service;
        private enhancement;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
    type AgentTemplateType = 'agent' | 'agentParallel' | 'agentWithClarification';
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBase.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBase" {
    export interface IDetails {
        title: string;
        description: string;
        tags: string[];
    }
    export function changeClassName(source: string, project: number, shortname: string): string;
    export function changeWidget(source: string, project: number, shortname: string): string;
    export function changeShortName(source: string, shortname: string): string;
    export function changeTagName(source: string, tagName: string): string;
    export function changeProject(source: string, project: number): string;
    export function changeFolder(source: string, folder: string): string;
    export function changeStateName(source: string, stateName: string): string;
    export function getTemplateImport(projectBase: number, shortName: string, folder: string): string;
    export interface IRequestNewFile {
        project: number;
        position: 'left' | 'right';
        shortName: string;
        folder?: string;
        enhancement: string;
        sourceTS: string;
        sourceHTML?: string;
        sourceLess?: string;
        sourceTest?: string;
        sourceDefs?: string;
        openPreview: boolean;
    }
    export function createNewFile(args: IRequestNewFile): Promise<void>;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBlank.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileBlank" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import '/_100555_/l2/pluginNewFile/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileBlank extends StateLitElement {
        shortName: string | undefined;
        folder: string | undefined;
        project: number | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileMd" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import '/_100555_/l2/pluginNewFile/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileMd extends StateLitElement {
        shortName: string | undefined;
        folder: string | undefined;
        project: number | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFilePage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFilePage" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import '/_100555_/l2/pluginNewFile/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFilePage extends StateLitElement {
        shortName: string | undefined;
        project: number | undefined;
        folder: string | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplateTS;
        private getTemplateHTML;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileService.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileService" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import '/_100555_/l2/pluginNewFile/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileService extends StateLitElement {
        shortName: string | undefined;
        project: number | undefined;
        folder: string | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileWebComponent.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/pluginNewFileWebComponent" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDetails } from "_100555_/l2/pluginNewFile/pluginNewFileBase";
    import '/_100555_/l2/pluginNewFile/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileWebComponent extends StateLitElement {
        shortName: string | undefined;
        project: number | undefined;
        folder: string | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100555_/l2/pluginNewFile/widgetTextCode.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginNewFile/widgetTextCode" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class WidgetTextCode extends CollabLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        setCode(): void;
        firstUpdated(): void;
        render(): any;
        private onChangeText;
    }
}
declare module "_100555_/l2/pluginProject/pluginGenerateDist" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export class PluginGenerateDist extends PluginBaseModule {
        private msg;
        error: string;
        tag: string;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderTag(): any;
        renderDefault(): TemplateResult;
        renderHeader(): TemplateResult;
        private init;
        private hasExtension;
        private getBuildByProject;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100555_/l2/pluginProject/pluginPresenterRecorder.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginPresenterRecorder" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginPresenterRecorder extends PluginBaseModule {
        private screenStream;
        private cameraStream;
        private mediaRecorder;
        private chunks;
        private downloadUrl;
        avatarShape: 'square' | 'round';
        avatarZoom: number;
        isRecording: boolean;
        isCountdown: boolean;
        countdownValue: number;
        private countdownTimer?;
        render(): TemplateResult;
        handleZoomChange(e: Event): void;
        updated(): void;
        startRecording(): Promise<void>;
        private _doStartRecording;
        stopRecording(): void;
        saveRecording(): void;
        showPipPreview(): void;
        hidePipPreview(): void;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectConfig.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libProjectConfig" {
    export const projectConfig: IProjectConfigCache;
    export function clearLocalChanges(project: number): Promise<void>;
    export function getConfigProject(project: number, ignoreLocalChanges?: boolean): Promise<mls.l5_common.ProjectConfig | undefined>;
    export function updateConfigProject(project: number, newConfig: mls.l5_common.ProjectConfig): Promise<void>;
    export function updateConfigProjectPlugins(project: number, newPlugins: {
        [key: string]: mls.l5_common.IPlugin;
    }): Promise<void>;
    export function createConfigFile(project: number): Promise<mls.l5_common.ProjectConfig>;
    interface IProjectConfigCache {
        [key: number]: {
            versionRef: string;
            config: mls.l5_common.ProjectConfig;
        };
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectConfig" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectConfig extends PluginBaseModule {
        static modelCount: number;
        private msg;
        autoPrepare: boolean;
        msize: string;
        c2: HTMLElement | undefined;
        body: HTMLDivElement | undefined;
        private _ed1;
        private model;
        private lastProject;
        private template;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        setEvents(): Promise<void>;
        private _clearChanges;
        private refreshIfNeeded;
        private createEditor;
        private loadProjectConfigs;
        private setInitialConfig;
        private createOrGetModel;
        private timeoutChangesEditorStyle;
        private setEventsModel;
        private onEditorChange;
        private getUri;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectDeleteFiles.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/utils/projectAST" {
    export function addModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message?: undefined;
    } | {
        ok: boolean;
        message: string;
    }>;
    export function configureMasterFrontEnd(project: number, start: string, build: string, liveView: string): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
    export function removeModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
}
declare module "_100555_/l2/pluginProject/pluginProjectDeleteFiles" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export class PluginProjectDeleteFiles extends PluginBaseModule {
        private msg;
        groupName: string;
        filesToDelete: mls.stor.IFileInfo[];
        selectedFiles: Map<string, mls.stor.IFileInfo>;
        logs: string[];
        render(): TemplateResult;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private getFileKey;
        private clear;
        onSearch(): Promise<void>;
        onDelete(): Promise<void>;
        private removeThemeFromDesignSystem;
        private removeModuleFromProjectFile;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100555_/l2/pluginProject/pluginProjectDetail.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/utils/collabIcons" {
    export const collab_terminal: any;
    export const collab_home: any;
    export const collab_bars: any;
    export const collab_magnifying_glass: any;
    export const collab_file_half_dashed: any;
    export const collab_book_skull: any;
    export const collab_rectangle_list: any;
    export const collab_lightbulb: any;
    export const collab_translate: any;
    export const collab_file_fragment: any;
    export const collab_file_code: any;
    export const collab_dot: any;
    export const collab_minus: any;
    export const collab_user_plus: any;
    export const collab_bell: any;
    export const collab_bell_slash: any;
    export const collab_message: any;
    export const collab_money: any;
    export const collab_clock: any;
    export const collab_clock_static: any;
    export const collab_test: any;
    export const collab_html: any;
    export const collab_typescript: any;
    export const collab_less: any;
    export const collab_fileTest: any;
    export const collab_record: any;
    export const collab_stop: any;
    export const collab_copy: any;
    export const collab_check: any;
    export const collab_double_check: any;
    export const collab_file: any;
    export const collab_location_dot: any;
    export const collab_rotate_left: any;
    export const collab_bug: any;
    export const collab_bug_x12: any;
    export const collab_unbalanced: any;
    export const collab_info: any;
    export const collab_info_circle: any;
    export const collab_question: any;
    export const collab_heart: any;
    export const collab_heart_o: any;
    export const collab_angles_right: any;
    export const collab_chevron_right: any;
    export const collab_chevron_left: any;
    export const collab_chevron_down: any;
    export const collab_undo: any;
    export const collab_clone: any;
    export const collab_file_pen: any;
    export const collab_trash: any;
    export const collab_ellipsis_vertical: any;
    export const collab_ban: any;
    export const collab_file_signature: any;
    export const collab_calendar_days: any;
    export const collab_user: any;
    export const collab_users: any;
    export const collab_book: any;
    export const collab_list_check: any;
    export const collab_folder_tree: any;
    export const collab_cube: any;
    export const collab_pen_nib: any;
    export const collab_plus: any;
    export const collab_bolt: any;
    export const collab_pencil: any;
    export const collab_cubes: any;
    export const collab_floppy_disk: any;
    export const collab_xmark: any;
    export const collab_arrow_up_long: any;
    export const collab_arrow_down_long: any;
    export const collab_arrows_up_down_left_right: any;
    export const collab_caret_righttv: any;
    export const collab_repeat: any;
    export const collab_thumbs_down_solid: any;
    export const collab_thumbs_down: any;
    export const collab_thumbs_up_solid: any;
    export const collab_thumbs_up: any;
    export const collab_edit_style: any;
    export const collab_play: any;
    export const collab_pause: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
    export const collab_commit: any;
    export const collab_branch: any;
    export const collab_pull_request: any;
    export const collab_arrows_rotate: any;
    export const collab_circle_notch: any;
    export const collab_triangle_exclamation: any;
    export const collab_circle_exclamation: any;
    export const collab_gear: any;
    export const collab_spinner_clock: any;
    export const collab_lock: any;
    export const collab_lock_open: any;
    export const collab_image: any;
    export const collab_unsplash: any;
    export const collab_video: any;
    export const collab_code: any;
    export const collab_ellipsis: any;
    export const collab_link: any;
    export const collab_border_top: any;
    export const collab_border_left: any;
    export const collab_border_bottom: any;
    export const collab_border_right: any;
    export const collab_border_topLeft: any;
    export const collab_border_bottomLeft: any;
    export const collab_border_bottomRight: any;
    export const collab_border_topRight: any;
    export const collab_margin_top: any;
    export const collab_margin_left: any;
    export const collab_margin_bottom: any;
    export const collab_margin_right: any;
    export const collab_padding_top: any;
    export const collab_padding_left: any;
    export const collab_padding_bottom: any;
    export const collab_padding_right: any;
}
declare module "../l2/pluginProject/pluginProjectInfo" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectInfo extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        project: number | undefined;
        projectName: string | undefined;
        projectDriver: "local" | "mls" | "GitHub" | "GitLab";
        projectOrg: string | undefined;
        projectOwner: string | undefined;
        projectCreatedAt: string | undefined;
        projectURL: string | undefined;
        projectDescription: string | undefined;
        forks: mls.stor.others.IFork[] | undefined;
        branches: mls.stor.others.IBranch[] | undefined;
        deps: IDependenciesInfo[];
        isSavingDeps: boolean;
        labelOk: string;
        labelError: string;
        labelErrorDeps: string;
        isAddingDep: boolean;
        newDepId: number | null;
        isEditingDeps: boolean;
        originalDeps: IDependenciesInfo[];
        isEditingInfo: boolean;
        isSavingInfo: boolean;
        labelOkInfo: string;
        labelErrorInfo: string;
        editName: string;
        editProjectURL: string;
        editProjectDriver: string;
        editProjectDescription: string;
        body: HTMLDivElement | undefined;
        private projectDetails;
        private projectSettings;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderBody(): TemplateResult;
        renderInfo(): TemplateResult;
        renderInfoViewMode(): TemplateResult;
        renderInfoEditMode(): TemplateResult;
        renderDependencies(): TemplateResult;
        renderDepsViewMode(): TemplateResult;
        renderDepsEditMode(): TemplateResult;
        private startEditingDeps;
        private cancelEditingDeps;
        private startEditingInfo;
        private cancelEditingInfo;
        private handleSaveInfo;
        private saveInfo;
        private moveDepUp;
        private moveDepDown;
        toggleAddDep(): void;
        private addDependency;
        private handleSaveDeps;
        private saveDeps;
        private init;
        private getDependencies;
        private setInfos;
    }
    interface IDependenciesInfo {
        id: number;
        name: string;
        auth: string;
        unknown?: boolean;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectDetail" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import "/_100555_/l2/pluginProject/pluginProjectInfo.js";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectDetail extends PluginBaseModule {
        contentproject: HTMLElement | undefined;
        contentprojectinfo: HTMLElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        private loadProject;
        static styles: any;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectFindFiles.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginProjectFindFiles" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { MindMapData } from "_102027_/l2/libMindMap";
    import '/_100554_/l2/widgetMindMapL4.js';
    export class PluginProjectFindFiles extends PluginBaseModule {
        private msg;
        private matchedFiles;
        private usingRegex;
        private progressValue;
        mode: 'list' | 'map';
        dataJson: MindMapData | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        renderList(): any;
        renderMap(): any;
        onSearch(): Promise<void>;
        searchFiles(files: string[], searchText: string): Promise<void>;
        changeMode(e: MouseEvent): void;
        configMode(): void;
        openFile(e: MouseEvent): void;
        fireEvents(action: string, file: mls.stor.IFileInfo, timeout?: number): Promise<void>;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100555_/l2/pluginProject/pluginProjectIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default: "disabled";
    export default _default;
}
declare module "_100555_/l2/pluginProject/pluginProjectIndex" {
    import { PluginBaseIndex } from "_102027_/l2/pluginBaseIndex";
    export class PluginProjectIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_1: PluginProjectIndex;
    export default _default_1;
}
declare module "_100555_/l2/pluginProject/pluginProjectInfo.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginProjectInfo" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectInfo extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        project: number | undefined;
        projectName: string | undefined;
        projectDriver: "local" | "mls" | "GitHub" | "GitLab";
        projectOrg: string | undefined;
        projectOwner: string | undefined;
        projectCreatedAt: string | undefined;
        projectURL: string | undefined;
        projectDescription: string | undefined;
        forks: mls.stor.others.IFork[] | undefined;
        branches: mls.stor.others.IBranch[] | undefined;
        deps: IDependenciesInfo[];
        isSavingDeps: boolean;
        labelOk: string;
        labelError: string;
        labelErrorDeps: string;
        isAddingDep: boolean;
        newDepId: number | null;
        isEditingDeps: boolean;
        originalDeps: IDependenciesInfo[];
        isEditingInfo: boolean;
        isSavingInfo: boolean;
        labelOkInfo: string;
        labelErrorInfo: string;
        editName: string;
        editProjectURL: string;
        editProjectDriver: string;
        editProjectDescription: string;
        body: HTMLDivElement | undefined;
        private projectDetails;
        private projectSettings;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderBody(): TemplateResult;
        renderInfo(): TemplateResult;
        renderInfoViewMode(): TemplateResult;
        renderInfoEditMode(): TemplateResult;
        renderDependencies(): TemplateResult;
        renderDepsViewMode(): TemplateResult;
        renderDepsEditMode(): TemplateResult;
        private startEditingDeps;
        private cancelEditingDeps;
        private startEditingInfo;
        private cancelEditingInfo;
        private handleSaveInfo;
        private saveInfo;
        private moveDepUp;
        private moveDepDown;
        toggleAddDep(): void;
        private addDependency;
        private handleSaveDeps;
        private saveDeps;
        private init;
        private getDependencies;
        private setInfos;
    }
    interface IDependenciesInfo {
        id: number;
        name: string;
        auth: string;
        unknown?: boolean;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectReadMe.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/utils/collabEditMd" {
    import { LitElement } from 'lit';
    export function initEditorQuillMD(): boolean;
    export class CollabEditMd extends LitElement {
        private value;
        private opened;
        containerEditor: HTMLElement | undefined;
        containerQuillEditor: HTMLTextAreaElement | undefined;
        iconFinish: HTMLElement | undefined;
        iconEdit: HTMLElement | undefined;
        set cbFinishEdit(fc: Function);
        get text(): any;
        firstUpdated(changedProperties: any): void;
        private cbFinishFc;
        private openedToolbar;
        id: string;
        easyMDE: any;
        editor: any;
        private initEditor;
        private onOpenedChanged;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private _initEditor;
        private onEditClick;
        private onFinishClick;
        render(): any;
        static styles: any;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectReadMe" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { CollabEditMd } from '_100555_/l2/utils/collabEditMd';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectReadMe extends PluginBaseModule {
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        mkEditor: CollabEditMd | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private renderReadme;
        private setReadme;
        private onChangeMd;
        private createFile;
        _getValueInfo(file: mls.stor.IFileInfo, originalShortName?: string, originalFolder?: string, originalProject?: number, originalCRC?: string): Promise<mls.stor.IFileInfoValue>;
        static styles: any;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectRunTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/utils/tsTestMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines(model: monaco.editor.ITextModel): string[];
        replaceLines(model: monaco.editor.ITextModel, lineNrInit: number, lineNrInitEnd: number, newContent: string): boolean;
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine(model: monaco.editor.ITextModel, lineNr: number, line: string): boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine(model: monaco.editor.ITextModel, lineNr: number): boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines(model: monaco.editor.ITextModel, startLine: number, countLines: number): boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine(model: monaco.editor.ITextModel, lineNr: number, columnNr: number, newText: string): boolean;
        /**
         * Moves the editor's cursor to the specified lines, selects the text between them,
         * and scrolls the editor to bring the selection into view.
         *
         * @param {monaco.editor.ITextModel} model - The text model associated with the editor.
         * @param {number} start - The starting line number for the selection.
         * @param {number} end - The ending line number for the selection.
         *
         * @returns {void}
         */
        goTo(model: monaco.editor.ITextModel, start: number, end: number): void;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (model: monaco.editor.ITextModel) => void;
    }
}
declare module "../l2/utils/tsTestAST" {
    import { MonacoDriver } from "_100555_/l2/utils/tsTestMonaco";
    /**
     * Represents an AST node.
     * @typedef {Object} ASTNode
     * @property {string} type - The type of the AST node (e.g., 'Program', 'FunctionDeclaration').
     * @property {string} [name] - The name of the node (e.g., function name).
     * @property {any} [value] - The value associated with the node (e.g., function body or array content).
     * @property {ASTNode[]} [children] - An array of child nodes.
     * @property {number} [startLine] - The start line of the node in the source code.
     * @property {number} [endLine] - The end line of the node in the source code.
     */
    type ASTNode = {
        type: string;
        name?: string;
        value?: any;
        children?: ASTNode[];
        startLine: number;
        endLine: number;
    };
    /**
     * Class to parse a TypeScript test file and generate an AST.
     */
    export class TsTestAst {
        ast: ASTNode | undefined;
        modelTest: mls.editor.IModelTest | undefined;
        monacoDriver: MonacoDriver;
        editor: monaco.editor.IStandaloneCodeEditor;
        /**
         * Creates an instance of TsTestAst.
         * @param {mls.editor.IModelTest} modelTest - The Monaco editor model test instance.
         */
        constructor(modelTest: mls.editor.IModelTest, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * Parses the TypeScript code from the model test and returns the AST.
         * @returns {ASTNode | undefined} The generated AST, or undefined if parsing fails.
         */
        parse: () => ASTNode | undefined;
        /**
         * Gets the integrations from the parsed AST.
         * @returns {any[]} The integrations parsed from the AST.
         */
        getIntegrations(): ICANIntegration[];
        /**
         * Gets the tests from the parsed AST.
         * @returns {any[]} The tests parsed from the AST.
         */
        getTests(): ICANTest[];
        /**
         * Adds a new test to the AST and inserts it into the test array in the Monaco editor.
         * @param {ICANTest} test - The test object to be added.
         * @param {Function} fcTest - The test function to be associated with the test.
         * @returns {boolean} True if the test was added successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        addTest(test: ICANTest, fcTest: Function | string): boolean;
        /**
         * Deletes a test from the AST and updates the Monaco editor.
         * @param {String} testName - The test name to be removed.
         * @returns {boolean} True if the test was removed successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        deleteTest(testName: string, index?: number): boolean;
        /**
         * Navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        goToTest(testName: string): boolean;
        /**
         * Retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        getTestInfo(functionName: string, paramsIndex?: number): ITestInfo;
        /**
        * Executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        runTest(testName: string, paramsIndex?: number): Promise<string>;
        /**
         * Adds a new integration to the test file.
         * @param {ICANIntegration} integration - The integration to be added.
         * @param {Function} fc - The function associated with the integration.
         * @returns {boolean} Returns true if the integration was successfully added.
         */
        addIntegration(integration: ICANIntegration, fc: Function | string): boolean;
        /**
         * Parses TypeScript code into an AST.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode} The generated AST from the code.
         */
        private parseTypeScript;
        /**
         * Parses imports from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the imports in the code.
         */
        private parseImports;
        /**
         * Parses arrays from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the arrays in the code.
         */
        private parseArrays;
        /**
         * Parses function names from TypeScript code and returns an array of function declarations as AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing function declarations in the code.
         */
        private parseFunctionNames;
        /**
         * Parses and retrieves the integrations from the AST's children.
         * @returns {ICANIntegration[]} The parsed integrations.
         * @throws {Error} Throws an error if parsing the integrations fails.
         */
        private _getIntegrations;
        /**
         * Parses and retrieves the tests from the AST's children.
         * @returns {ICANTest[]} The parsed tests.
         * @throws {Error} Throws an error if parsing the tests fails.
         */
        private _getTests;
        /**
         * Internal method to add a test to the AST and update the Monaco editor.
         * @param {ICANTest} test - The test object to add.
         * @param {Function} fcTest - The test function to add.
         * @returns {boolean} True if the test was successfully added.
         * @throws {Error} Throws an error if the test already exists or AST information is missing.
         */
        private _addTest;
        /**
         * Internal method to deletes a test from the AST and updates the Monaco editor.
         * @param {string} testName - The name of the test to delete.
         * @throws {Error} Throws an error if the test does not exist or deletion fails.
         */
        private _deleteTest2;
        /**
     * Internal method to delete a test from the AST and update the Monaco editor.
     * @param {string} functionName - The name of the test to delete.
     * @param {number} [index] - (Optional) The index of the parameter to remove.
     * @throws {Error} Throws an error if the test does not exist or deletion fails.
     */
        private _deleteTest;
        /**
        * Internal method to executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        private _runTest;
        /**
         * Internal method to retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        private _getTestInfo;
        /**
         * Internal method to navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        private _goToTest;
        /**
         * Intenal method to delete a function on the AST and updates the Monaco editor.
         * @param {String} fcName - The function name to be deleted.
         * @returns {boolean} True if the function was successfully deleted.
         * @throws {Error} Throws an error if the test model is invalid.
         */
        private _deleteFunction;
        /**
         * Adds a new integration to the AST and updates the Monaco editor.
         * @param {ICANIntegrations} integration - The integration object to add.
         * @param {Function} fcIntegration - The integration function to add.
         * @throws {Error} Throws an error if the integration already exists or if AST information is missing.
         */
        private _addIntegration;
        /**
         * Deletes an integration from the AST and updates the Monaco editor.
         * @param {string} integrationName - The name of the integration to delete.
         * @throws {Error} Throws an error if the integration does not exist or deletion fails.
         */
        private _deleteIntegration;
        /**
         * Adds a new function to the AST and updates the Monaco editor.
         * @param {Function} fc - The function to add.
         * @returns {boolean} True if the function was successfully added.
         * @throws {Error} Throws an error if AST information is missing or the test model is invalid.
         */
        private _addFunction;
        private checkImports;
        /**
         * Adds an import statement to the TypeScript code.
         * If an interval is provided, it replaces the existing import.
         * Otherwise, it inserts the import after the root startLine.
         *
         * @param {string} value - The import statement to add.
         * @param {Object} [interval] - The optional start and end line to replace.
         */
        private _addImport;
        private _formatEditor;
    }
    export interface ITestInfo {
        fileName: string;
        functionName: string;
        params: Record<string, any>;
    }
    export interface ICANTest {
        functionName: string;
        params: Record<string, any>[];
    }
    export interface ICANIntegration {
        enabled: boolean;
        description: string;
        page: string;
        functionName: string;
        schema: Record<string, ICANSchema>;
    }
    export interface ICANSchema {
        type: string;
        optional?: boolean;
        description?: string;
    }
}
declare module "_102027_/l2/collabPageElement" {
    import { PropertyValueMap, LitElement } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export const PREFIX_ICA_ID = "ica_";
    export function toPascalCase(str: string): string;
    export abstract class CollabPageElement extends StateLitElement {
        abstract initPage(): void;
        modeoverlay: string;
        initPageComplete: boolean;
        level: string;
        overlay: any | undefined;
        isPage: boolean;
        recreateOverlay(): void;
        refreshOverlay(): void;
        constructor();
        createRenderRoot(): this;
        firstUpdated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): any;
        private setupIds;
        private checkToAddOverlay;
        private createOverlay;
        private hasImport;
        private importWCDOverlay;
        private findAllElementsIca;
    }
    export interface LitElementBaseMethods extends LitElement {
        level: '1' | '2' | '3' | '4' | '5' | '6' | '7' | undefined;
        globalVariation: number | undefined;
        baseName: string;
        overlayRef: HTMLElement | undefined;
        mySymbol: string;
        getActionsTags(): ActionTag[];
    }
    interface ActionTag {
        name: string;
        position?: 'p-l0' | 'p-l1' | 'p-l2' | 'p-l3' | 'p-l4' | 'p-m0' | 'p-m1' | 'p-m2' | 'p-m3' | 'p-m4' | 'p-r0' | 'p-r1' | 'p-r2' | 'p-r3' | 'p-r4' | 'p-title' | 'p-title-top' | '';
        args?: string;
        level?: number[];
        toolboxOptions?: IToolboxOptions;
    }
    export interface IToolboxOptions {
        background?: string;
        border?: string;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectRunTest" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import '/_100554_/l2/collabResultTest.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectRunTest extends PluginBaseModule {
        private msg;
        collabResultContainer: HTMLElement | undefined;
        progress: number;
        totalTest: number;
        totalTestPass: number;
        totalTestFailed: number;
        startTime: number;
        endTime: number;
        actualAllPagesTests: number;
        filesWithTest: string[];
        render(): TemplateResult;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private init;
        private exec;
        private clear;
        private countTotalTests;
        private calcProgress;
        private createModelsIfNeeded;
        private getTestsByFile;
        private getStorFilesWithTest;
        private addTestResultItem;
        private createPageContainer;
        private runTest;
        private delay;
        private runAllTests;
        private createResume;
        private createResumeFinal;
        private waitForPreviewLoaded;
        private waitForLitComponentsInIframe;
        private fireEvents;
        private onFinishTest;
    }
}
declare module "_100555_/l2/pluginProject/pluginProjectUsage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginProject/pluginProjectUsage" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectUsage extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        designSystems: number | undefined;
        projectLastModified: string | undefined;
        files: number | undefined;
        chartData: {};
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private renderResume;
        static styles: any;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/plugins/pluginTestUtils" {
    /**
     * Where a test case can run:
     * - 'browser': needs real DOM/customElements (mounts the component, dispatches events, etc.).
     * - 'vscode': pure logic, runs without DOM (e.g. an exported function that only transforms data).
     * When in doubt, use 'browser' — it's the environment with full fidelity; 'vscode' is opt-in
     * only for logic proven to be DOM-independent.
     */
    export type TestEnv = 'browser' | 'vscode';
    export interface IPluginTestParams {
        input?: any;
        expected: any;
        /** When true, `compare` checks that `expected` is a subset of `actual` (useful for large/dynamic outputs). */
        contains?: boolean;
    }
    /**
     * Shape-compatible with `ICANTest` (tsTestAST.ts): same functionName/params pair,
     * with `env` added so the runner can decide where to execute each function.
     */
    export interface IPluginTestCase {
        functionName: string;
        env: TestEnv;
        params: IPluginTestParams[];
    }
    /** Sorts tests so 'browser' comes before 'vscode' — use before running a batch. */
    export function sortByEnvironment(tests: IPluginTestCase[]): IPluginTestCase[];
    export function isBrowser(): boolean;
    /**
     * Creates the element, applies properties, appends it to the document and waits for the first render.
     * Every call is tracked so `cleanup()` can remove it later — never forget to call cleanup().
     */
    export function mount<T extends HTMLElement = HTMLElement>(tag: string, props?: Record<string, any>): Promise<T>;
    /** Looks inside the shadow DOM if it exists, otherwise falls back to the light DOM (plugins vary between the two). */
    export function query(el: Element, selector: string): Element | null;
    /**
     * Replaces `mls.*` keys with mocked values; returns a function that restores the original state.
     * `cleanup()` also restores any pending override, so using only overrideMls is already safe
     * even if the test throws before manually calling the restorer.
     */
    export function overrideMls(overrides: Record<string, any>): () => void;
    /** Removes every mounted element and undoes any pending `mls.*` overrides. Call at the end of each test (try/finally). */
    export function cleanup(): void;
    /**
     * Universal contract check (layer 1 of the strategy): element registered and renders without throwing.
     * Works for any of the 88 plugins, regardless of type.
     */
    export function mountAndVerify(tag: string, props?: Record<string, any>): Promise<{
        registered: boolean;
        rendered: boolean;
    }>;
    /**
     * Compares the actual value against the expected one (deep-equal with normalization) and throws
     * a formatted error on mismatch — keeps the "threw = failed" semantics of the ICAN runner.
     */
    export function compare(actual: any, expected: any, opts?: {
        contains?: boolean;
    }): void;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginActiveUsers" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginActiveUsers extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginActiveUsers extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginErrors" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginErrors extends PluginBaseModule {
        filter: string;
        chartData: {};
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            filter: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginErrors extends PluginBaseModule {
        filter: string;
        chartData: {};
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginExpenses" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExpenses extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExpenses extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginRegionalLatency" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginRegionalLatency extends PluginBaseModule {
        filter: string;
        chartDataBar: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        bar: HTMLDivElement | undefined;
        map: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginRegionalLatency extends PluginBaseModule {
        filter: string;
        chartDataBar: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        bar: HTMLDivElement | undefined;
        map: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginResponseTime" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginResponseTime extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginResponseTime extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginSales" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSales extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSales extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginSpikes" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSpikes extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSpikes extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginTester/pluginPluginRunTest" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    interface ITestCaseResult {
        functionName: string;
        env: string;
        index: number;
        status: 'pass' | 'fail';
        message: string;
    }
    interface ITestFileResult {
        file: string;
        status: 'ok' | 'import-error' | 'no-tests';
        error?: string;
        cases: ITestCaseResult[];
    }
    export class PluginPluginRunTest extends PluginBaseModule {
        private msg;
        running: boolean;
        hasRun: boolean;
        totalFiles: number;
        totalPassed: number;
        totalFailed: number;
        totalNoTests: number;
        results: ITestFileResult[];
        createRenderRoot(): this;
        render(): TemplateResult;
        private renderPlayIcon;
        private renderSpinnerIcon;
        private renderFileResult;
        runAll(): Promise<void>;
        private findTestFiles;
        private runFile;
        private logToConsole;
    }
}
declare module "_100555_/l2/utils/collabEditMd.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/collabEditMd" {
    import { LitElement } from 'lit';
    export function initEditorQuillMD(): boolean;
    export class CollabEditMd extends LitElement {
        private value;
        private opened;
        containerEditor: HTMLElement | undefined;
        containerQuillEditor: HTMLTextAreaElement | undefined;
        iconFinish: HTMLElement | undefined;
        iconEdit: HTMLElement | undefined;
        set cbFinishEdit(fc: Function);
        get text(): any;
        firstUpdated(changedProperties: any): void;
        private cbFinishFc;
        private openedToolbar;
        id: string;
        easyMDE: any;
        editor: any;
        private initEditor;
        private onOpenedChanged;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private _initEditor;
        private onEditClick;
        private onFinishClick;
        render(): any;
        static styles: any;
    }
}
declare module "_100555_/l2/utils/collabIcons.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/collabIcons" {
    export const collab_terminal: any;
    export const collab_home: any;
    export const collab_bars: any;
    export const collab_magnifying_glass: any;
    export const collab_file_half_dashed: any;
    export const collab_book_skull: any;
    export const collab_rectangle_list: any;
    export const collab_lightbulb: any;
    export const collab_translate: any;
    export const collab_file_fragment: any;
    export const collab_file_code: any;
    export const collab_dot: any;
    export const collab_minus: any;
    export const collab_user_plus: any;
    export const collab_bell: any;
    export const collab_bell_slash: any;
    export const collab_message: any;
    export const collab_money: any;
    export const collab_clock: any;
    export const collab_clock_static: any;
    export const collab_test: any;
    export const collab_html: any;
    export const collab_typescript: any;
    export const collab_less: any;
    export const collab_fileTest: any;
    export const collab_record: any;
    export const collab_stop: any;
    export const collab_copy: any;
    export const collab_check: any;
    export const collab_double_check: any;
    export const collab_file: any;
    export const collab_location_dot: any;
    export const collab_rotate_left: any;
    export const collab_bug: any;
    export const collab_bug_x12: any;
    export const collab_unbalanced: any;
    export const collab_info: any;
    export const collab_info_circle: any;
    export const collab_question: any;
    export const collab_heart: any;
    export const collab_heart_o: any;
    export const collab_angles_right: any;
    export const collab_chevron_right: any;
    export const collab_chevron_left: any;
    export const collab_chevron_down: any;
    export const collab_undo: any;
    export const collab_clone: any;
    export const collab_file_pen: any;
    export const collab_trash: any;
    export const collab_ellipsis_vertical: any;
    export const collab_ban: any;
    export const collab_file_signature: any;
    export const collab_calendar_days: any;
    export const collab_user: any;
    export const collab_users: any;
    export const collab_book: any;
    export const collab_list_check: any;
    export const collab_folder_tree: any;
    export const collab_cube: any;
    export const collab_pen_nib: any;
    export const collab_plus: any;
    export const collab_bolt: any;
    export const collab_pencil: any;
    export const collab_cubes: any;
    export const collab_floppy_disk: any;
    export const collab_xmark: any;
    export const collab_arrow_up_long: any;
    export const collab_arrow_down_long: any;
    export const collab_arrows_up_down_left_right: any;
    export const collab_caret_righttv: any;
    export const collab_repeat: any;
    export const collab_thumbs_down_solid: any;
    export const collab_thumbs_down: any;
    export const collab_thumbs_up_solid: any;
    export const collab_thumbs_up: any;
    export const collab_edit_style: any;
    export const collab_play: any;
    export const collab_pause: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
    export const collab_commit: any;
    export const collab_branch: any;
    export const collab_pull_request: any;
    export const collab_arrows_rotate: any;
    export const collab_circle_notch: any;
    export const collab_triangle_exclamation: any;
    export const collab_circle_exclamation: any;
    export const collab_gear: any;
    export const collab_spinner_clock: any;
    export const collab_lock: any;
    export const collab_lock_open: any;
    export const collab_image: any;
    export const collab_unsplash: any;
    export const collab_video: any;
    export const collab_code: any;
    export const collab_ellipsis: any;
    export const collab_link: any;
    export const collab_border_top: any;
    export const collab_border_left: any;
    export const collab_border_bottom: any;
    export const collab_border_right: any;
    export const collab_border_topLeft: any;
    export const collab_border_bottomLeft: any;
    export const collab_border_bottomRight: any;
    export const collab_border_topRight: any;
    export const collab_margin_top: any;
    export const collab_margin_left: any;
    export const collab_margin_bottom: any;
    export const collab_margin_right: any;
    export const collab_padding_top: any;
    export const collab_padding_left: any;
    export const collab_padding_bottom: any;
    export const collab_padding_right: any;
}
declare module "_100555_/l2/utils/projectAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/projectAST" {
    export function addModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message?: undefined;
    } | {
        ok: boolean;
        message: string;
    }>;
    export function configureMasterFrontEnd(project: number, start: string, build: string, liveView: string): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
    export function removeModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
}
declare module "_100555_/l2/utils/tsTestAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/tsTestAST" {
    import { MonacoDriver } from "_100555_/l2/utils/tsTestMonaco";
    /**
     * Represents an AST node.
     * @typedef {Object} ASTNode
     * @property {string} type - The type of the AST node (e.g., 'Program', 'FunctionDeclaration').
     * @property {string} [name] - The name of the node (e.g., function name).
     * @property {any} [value] - The value associated with the node (e.g., function body or array content).
     * @property {ASTNode[]} [children] - An array of child nodes.
     * @property {number} [startLine] - The start line of the node in the source code.
     * @property {number} [endLine] - The end line of the node in the source code.
     */
    type ASTNode = {
        type: string;
        name?: string;
        value?: any;
        children?: ASTNode[];
        startLine: number;
        endLine: number;
    };
    /**
     * Class to parse a TypeScript test file and generate an AST.
     */
    export class TsTestAst {
        ast: ASTNode | undefined;
        modelTest: mls.editor.IModelTest | undefined;
        monacoDriver: MonacoDriver;
        editor: monaco.editor.IStandaloneCodeEditor;
        /**
         * Creates an instance of TsTestAst.
         * @param {mls.editor.IModelTest} modelTest - The Monaco editor model test instance.
         */
        constructor(modelTest: mls.editor.IModelTest, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * Parses the TypeScript code from the model test and returns the AST.
         * @returns {ASTNode | undefined} The generated AST, or undefined if parsing fails.
         */
        parse: () => ASTNode | undefined;
        /**
         * Gets the integrations from the parsed AST.
         * @returns {any[]} The integrations parsed from the AST.
         */
        getIntegrations(): ICANIntegration[];
        /**
         * Gets the tests from the parsed AST.
         * @returns {any[]} The tests parsed from the AST.
         */
        getTests(): ICANTest[];
        /**
         * Adds a new test to the AST and inserts it into the test array in the Monaco editor.
         * @param {ICANTest} test - The test object to be added.
         * @param {Function} fcTest - The test function to be associated with the test.
         * @returns {boolean} True if the test was added successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        addTest(test: ICANTest, fcTest: Function | string): boolean;
        /**
         * Deletes a test from the AST and updates the Monaco editor.
         * @param {String} testName - The test name to be removed.
         * @returns {boolean} True if the test was removed successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        deleteTest(testName: string, index?: number): boolean;
        /**
         * Navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        goToTest(testName: string): boolean;
        /**
         * Retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        getTestInfo(functionName: string, paramsIndex?: number): ITestInfo;
        /**
        * Executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        runTest(testName: string, paramsIndex?: number): Promise<string>;
        /**
         * Adds a new integration to the test file.
         * @param {ICANIntegration} integration - The integration to be added.
         * @param {Function} fc - The function associated with the integration.
         * @returns {boolean} Returns true if the integration was successfully added.
         */
        addIntegration(integration: ICANIntegration, fc: Function | string): boolean;
        /**
         * Parses TypeScript code into an AST.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode} The generated AST from the code.
         */
        private parseTypeScript;
        /**
         * Parses imports from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the imports in the code.
         */
        private parseImports;
        /**
         * Parses arrays from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the arrays in the code.
         */
        private parseArrays;
        /**
         * Parses function names from TypeScript code and returns an array of function declarations as AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing function declarations in the code.
         */
        private parseFunctionNames;
        /**
         * Parses and retrieves the integrations from the AST's children.
         * @returns {ICANIntegration[]} The parsed integrations.
         * @throws {Error} Throws an error if parsing the integrations fails.
         */
        private _getIntegrations;
        /**
         * Parses and retrieves the tests from the AST's children.
         * @returns {ICANTest[]} The parsed tests.
         * @throws {Error} Throws an error if parsing the tests fails.
         */
        private _getTests;
        /**
         * Internal method to add a test to the AST and update the Monaco editor.
         * @param {ICANTest} test - The test object to add.
         * @param {Function} fcTest - The test function to add.
         * @returns {boolean} True if the test was successfully added.
         * @throws {Error} Throws an error if the test already exists or AST information is missing.
         */
        private _addTest;
        /**
         * Internal method to deletes a test from the AST and updates the Monaco editor.
         * @param {string} testName - The name of the test to delete.
         * @throws {Error} Throws an error if the test does not exist or deletion fails.
         */
        private _deleteTest2;
        /**
     * Internal method to delete a test from the AST and update the Monaco editor.
     * @param {string} functionName - The name of the test to delete.
     * @param {number} [index] - (Optional) The index of the parameter to remove.
     * @throws {Error} Throws an error if the test does not exist or deletion fails.
     */
        private _deleteTest;
        /**
        * Internal method to executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        private _runTest;
        /**
         * Internal method to retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        private _getTestInfo;
        /**
         * Internal method to navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        private _goToTest;
        /**
         * Intenal method to delete a function on the AST and updates the Monaco editor.
         * @param {String} fcName - The function name to be deleted.
         * @returns {boolean} True if the function was successfully deleted.
         * @throws {Error} Throws an error if the test model is invalid.
         */
        private _deleteFunction;
        /**
         * Adds a new integration to the AST and updates the Monaco editor.
         * @param {ICANIntegrations} integration - The integration object to add.
         * @param {Function} fcIntegration - The integration function to add.
         * @throws {Error} Throws an error if the integration already exists or if AST information is missing.
         */
        private _addIntegration;
        /**
         * Deletes an integration from the AST and updates the Monaco editor.
         * @param {string} integrationName - The name of the integration to delete.
         * @throws {Error} Throws an error if the integration does not exist or deletion fails.
         */
        private _deleteIntegration;
        /**
         * Adds a new function to the AST and updates the Monaco editor.
         * @param {Function} fc - The function to add.
         * @returns {boolean} True if the function was successfully added.
         * @throws {Error} Throws an error if AST information is missing or the test model is invalid.
         */
        private _addFunction;
        private checkImports;
        /**
         * Adds an import statement to the TypeScript code.
         * If an interval is provided, it replaces the existing import.
         * Otherwise, it inserts the import after the root startLine.
         *
         * @param {string} value - The import statement to add.
         * @param {Object} [interval] - The optional start and end line to replace.
         */
        private _addImport;
        private _formatEditor;
    }
    export interface ITestInfo {
        fileName: string;
        functionName: string;
        params: Record<string, any>;
    }
    export interface ICANTest {
        functionName: string;
        params: Record<string, any>[];
    }
    export interface ICANIntegration {
        enabled: boolean;
        description: string;
        page: string;
        functionName: string;
        schema: Record<string, ICANSchema>;
    }
    export interface ICANSchema {
        type: string;
        optional?: boolean;
        description?: string;
    }
}
declare module "_100555_/l2/utils/tsTestMonaco.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/utils/tsTestMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines(model: monaco.editor.ITextModel): string[];
        replaceLines(model: monaco.editor.ITextModel, lineNrInit: number, lineNrInitEnd: number, newContent: string): boolean;
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine(model: monaco.editor.ITextModel, lineNr: number, line: string): boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine(model: monaco.editor.ITextModel, lineNr: number): boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines(model: monaco.editor.ITextModel, startLine: number, countLines: number): boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine(model: monaco.editor.ITextModel, lineNr: number, columnNr: number, newText: string): boolean;
        /**
         * Moves the editor's cursor to the specified lines, selects the text between them,
         * and scrolls the editor to bring the selection into view.
         *
         * @param {monaco.editor.ITextModel} model - The text model associated with the editor.
         * @param {number} start - The starting line number for the selection.
         * @param {number} end - The ending line number for the selection.
         *
         * @returns {void}
         */
        goTo(model: monaco.editor.ITextModel, start: number, end: number): void;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (model: monaco.editor.ITextModel) => void;
    }
}
