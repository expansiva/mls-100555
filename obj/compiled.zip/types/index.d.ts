declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(theme?: number | string, path?: string): Promise<string>;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { DsFont } from "_102029_/l2/designSystemBase";
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
        /** Font roles that need LOADING (@import/@font-face) — see DsFont in _102029_/l2/designSystemBase. */
        fonts?: DsFont[];
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_100555_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_100555_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/plugins/pluginTestUtils" {
    /**
     * Where a test case can run:
     * - 'browser': needs real DOM/customElements (mounts the component, dispatches events, etc.).
     * - 'vscode': pure logic, runs without DOM (e.g. an exported function that only transforms data).
     * When in doubt, use 'browser' — it's the environment with full fidelity; 'vscode' is opt-in
     * only for logic proven to be DOM-independent.
     */
    export type TestEnv = 'browser' | 'vscode';
    export interface IPluginTestParams {
        input?: any;
        expected: any;
        /** When true, `compare` checks that `expected` is a subset of `actual` (useful for large/dynamic outputs). */
        contains?: boolean;
    }
    /**
     * Shape-compatible with `ICANTest` (tsTestAST.ts): same functionName/params pair,
     * with `env` added so the runner can decide where to execute each function.
     */
    export interface IPluginTestCase {
        functionName: string;
        env: TestEnv;
        params: IPluginTestParams[];
    }
    /** Sorts tests so 'browser' comes before 'vscode' — use before running a batch. */
    export function sortByEnvironment(tests: IPluginTestCase[]): IPluginTestCase[];
    export function isBrowser(): boolean;
    /**
     * Creates the element, applies properties, appends it to the document and waits for the first render.
     * Every call is tracked so `cleanup()` can remove it later — never forget to call cleanup().
     */
    export function mount<T extends HTMLElement = HTMLElement>(tag: string, props?: Record<string, any>): Promise<T>;
    /** Looks inside the shadow DOM if it exists, otherwise falls back to the light DOM (plugins vary between the two). */
    export function query(el: Element, selector: string): Element | null;
    /**
     * Replaces `mls.*` keys with mocked values; returns a function that restores the original state.
     * `cleanup()` also restores any pending override, so using only overrideMls is already safe
     * even if the test throws before manually calling the restorer.
     */
    export function overrideMls(overrides: Record<string, any>): () => void;
    /** Removes every mounted element and undoes any pending `mls.*` overrides. Call at the end of each test (try/finally). */
    export function cleanup(): void;
    /**
     * Universal contract check (layer 1 of the strategy): element registered and renders without throwing.
     * Works for any of the 88 plugins, regardless of type.
     */
    export function mountAndVerify(tag: string, props?: Record<string, any>): Promise<{
        registered: boolean;
        rendered: boolean;
    }>;
    /**
     * Compares the actual value against the expected one (deep-equal with normalization) and throws
     * a formatted error on mismatch — keeps the "threw = failed" semantics of the ICAN runner.
     */
    export function compare(actual: any, expected: any, opts?: {
        contains?: boolean;
    }): void;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102027_/l2/pluginBaseModule" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "../l2/pluginSiteMonitorDashboard/pluginActiveUsers" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginActiveUsers extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginActiveUsers extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginErrors extends PluginBaseModule {
        filter: string;
        chartData: {};
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExpenses extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginRegionalLatency extends PluginBaseModule {
        filter: string;
        chartDataBar: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        bar: HTMLDivElement | undefined;
        map: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginResponseTime extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSales extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSpikes extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginTester/pluginPluginRunTest" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    interface ITestCaseResult {
        functionName: string;
        env: string;
        index: number;
        status: 'pass' | 'fail';
        message: string;
    }
    interface ITestFileResult {
        file: string;
        status: 'ok' | 'import-error' | 'no-tests';
        error?: string;
        cases: ITestCaseResult[];
    }
    export class PluginPluginRunTest extends PluginBaseModule {
        private msg;
        running: boolean;
        hasRun: boolean;
        totalFiles: number;
        totalPassed: number;
        totalFailed: number;
        totalNoTests: number;
        results: ITestFileResult[];
        createRenderRoot(): this;
        render(): TemplateResult;
        private renderPlayIcon;
        private renderSpinnerIcon;
        private renderFileResult;
        runAll(): Promise<void>;
        private findTestFiles;
        private runFile;
        private logToConsole;
    }
}
