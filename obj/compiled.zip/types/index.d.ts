declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(theme?: number | string, path?: string): Promise<string>;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { DsFont } from "_102029_/l2/designSystemBase";
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
        /** Font roles that need LOADING (@import/@font-face) — see DsFont in _102029_/l2/designSystemBase. */
        fonts?: DsFont[];
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_100555_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_100555_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_100555_/l2/pluginExplore/collabInputSearch" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabInputSearch extends CollabLitElement {
        private msg;
        placeholder: string;
        value: string;
        private focused;
        firstUpdated(): void;
        render(): any;
        private _onInput;
        private _onFocus;
        private _onBlur;
        private _clear;
        private _onKeyDown;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_100555_/l2/pluginExplore/mlsFileTree" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    interface FileInfo {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    interface TreeNode {
        name: string;
        fullPath: string;
        isFolder: boolean;
        children: TreeNode[];
        fileKey?: string;
        extension?: string;
        file: mls.stor.IFileInfo;
    }
    export class MlsFileTree extends CollabLitElement {
        position: string | undefined;
        project: string | undefined;
        filter: string;
        files: Record<string, FileInfo>;
        private expanded;
        private selected;
        private _loading;
        private _loadingMsg;
        firstUpdated(): void;
        render(): any;
        private _renderOverlay;
        private renderFiltered;
        private highlightText;
        private renderNode;
        renderItem(node: TreeNode, depth: number): any;
        private deleteFile;
        private undoFile;
        private getTitleInLocalStorage;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private buildTree;
        private toggleFolder;
        private selectFile;
        private clickGroupHidden;
        private collectFilesFromNode;
        private delAllByFolders;
        private undoAllByFolders;
        private getLevel;
        private clearPath;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreList.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libHistoriesRecents" {
    export function addInHistory(file: mls.stor.IFileInfo): void;
    export function getHistory(): HistoryList;
    export function removeFromHistory(target: HistoryItem): void;
    export function renameHistoryItem(target: HistoryItem, newShortName: string): void;
    export function loadProjectHistory(): IHistoryProject[];
    export function saveProjectHistory(history: IHistoryProject[]): void;
    export function removeProjectFromHistory(projectId: number): void;
    export function renameProjectInHistory(projectId: number, newName: string): void;
    interface IHistoryProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    export interface HistoryItem {
        project: number;
        shortName: string;
        extension: string;
        folder: string;
    }
    type HistoryList = HistoryItem[];
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_102027_/l2/pluginBaseModule" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "../l2/pluginExplore/collabInputSearch" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabInputSearch extends CollabLitElement {
        private msg;
        placeholder: string;
        value: string;
        private focused;
        firstUpdated(): void;
        render(): any;
        private _onInput;
        private _onFocus;
        private _onBlur;
        private _clear;
        private _onKeyDown;
    }
}
declare module "../l2/pluginExplore/mlsFileTree" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    interface FileInfo {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    interface TreeNode {
        name: string;
        fullPath: string;
        isFolder: boolean;
        children: TreeNode[];
        fileKey?: string;
        extension?: string;
        file: mls.stor.IFileInfo;
    }
    export class MlsFileTree extends CollabLitElement {
        position: string | undefined;
        project: string | undefined;
        filter: string;
        files: Record<string, FileInfo>;
        private expanded;
        private selected;
        private _loading;
        private _loadingMsg;
        firstUpdated(): void;
        render(): any;
        private _renderOverlay;
        private renderFiltered;
        private highlightText;
        private renderNode;
        renderItem(node: TreeNode, depth: number): any;
        private deleteFile;
        private undoFile;
        private getTitleInLocalStorage;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private buildTree;
        private toggleFolder;
        private selectFile;
        private clickGroupHidden;
        private collectFilesFromNode;
        private delAllByFolders;
        private undoAllByFolders;
        private getLevel;
        private clearPath;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
    }
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "../l2/pluginExplore/pluginExploreListAddL1" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        service: ServiceBase | undefined;
        father: HTMLElement | undefined;
        level: number;
        error: string;
        position: string;
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        private handleInputInput;
        private clickCancel;
        private getNewNameAndValid;
        private showLoad;
        private createFile;
        private setHistory;
        private showError;
        private fireEvents;
    }
}
declare module "../l2/pluginExplore/pluginExploreListAddL2" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        level: number;
        error: string;
        position: string;
        father?: ServiceBase | undefined;
        plugins: IPlugins[];
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        renderTemplates(): any;
        private goBack;
        private handleInputInput;
        private handleClickTemplate;
        private clickCancel;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private getPlugins;
        private getPluginsInfo;
    }
    interface IPlugins extends IDetails {
        widget: string;
        category: string | null;
    }
}
declare module "../l2/pluginExplore/pluginExploreListAddL3" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL3 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptOrganism: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "../l2/pluginExplore/pluginExploreListAddL4" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL4 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptPage: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private verifyModuleConfig;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreList" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import '/_100555_/l2/pluginExplore/collabInputSearch.js';
    import '/_100555_/l2/pluginExplore/mlsFileTree.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExploreList extends PluginBaseModule {
        createModels(stor: mls.stor.IFileInfo): Promise<void>;
        private resizeObserver;
        private myDep;
        private msg;
        service: ServiceBase | undefined;
        private filterByLevel;
        autoPrepare: boolean;
        mode: TModeExploreList;
        refresh: string;
        position: string;
        levelFiles: number;
        project: number;
        projectLabel: string;
        filterProject: number;
        modeView: number;
        hiddenFiles: boolean;
        errorAux: string;
        files: mls.stor.IFileInfo[];
        history: mls.stor.IFileInfo[];
        modeFilter: string | undefined;
        lis: HTMLElement[] | undefined;
        constructor();
        private info;
        prepare(): Promise<void>;
        private showAdd;
        private filesInLocal;
        private setEvents;
        private onlevelChange;
        private onMLSEvents;
        connectedCallback(): void;
        disconnectedCallback(): void;
        createRenderRoot(): this;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        renderModeList(): any;
        renderHeader(): any;
        renderHistory(): any;
        renderList(): any;
        renderFolder(): any;
        renderFolder2(files: mls.stor.IFileInfo[]): any;
        getTitleInLocalStorage(ts: mls.stor.IFileInfo, html: mls.stor.IFileInfo, less: mls.stor.IFileInfo, test: mls.stor.IFileInfo, defs: mls.stor.IFileInfo): string;
        renderLiItem(file: mls.stor.IFileInfo, index: number, inHistory: boolean): any;
        renderAddL1(): any;
        renderAddL2(): any;
        renderAddL3(): any;
        renderAddL4(): any;
        private getAllName;
        private showLoading;
        private showError;
        private closeAllMenus;
        private clickOptUndo;
        private clickOptDel;
        private clickOptOpen;
        private clickOptOpenSecurity;
        private clickOptRename;
        private clickOptClone;
        private cloneFile;
        private renameFile;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
        private fireEventThisProject;
        private fireEventLoadProject;
        private changeListTimeout;
        changeList(time?: number): void;
        private extensionLevel;
        private levelByLevel;
        private init;
        private setLastFilter;
        private getMyFileInElement;
        private clickGroupHidden;
        private changeSelectProject;
        private changeHiddenFiles;
        private changeModeOrder;
        private inFilter;
        private timeFilterChange;
        private searchTerm;
        private filterLiChange;
        private getFiles;
        private filterArrayHistory;
        private validFileByLevel;
        private getFilesProject;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private getFileHistory;
        private isValidNewName;
        private initObserverResize;
        private saveLocalStorageLastOpen;
        private delAllByFolders;
        private loadLastPreference;
        private getLastModeFilter;
        private setLastPreference;
    }
    type TModeExploreList = 'list' | 'addL1' | 'addL2' | 'addL3' | 'addL4';
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL1" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        service: ServiceBase | undefined;
        father: HTMLElement | undefined;
        level: number;
        error: string;
        position: string;
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        private handleInputInput;
        private clickCancel;
        private getNewNameAndValid;
        private showLoad;
        private createFile;
        private setHistory;
        private showError;
        private fireEvents;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL2" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    export class ServiceListFilesAdd100555 extends CollabLitElement {
        private baseProject;
        private msg;
        level: number;
        error: string;
        position: string;
        father?: ServiceBase | undefined;
        plugins: IPlugins[];
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        renderTemplates(): any;
        private goBack;
        private handleInputInput;
        private handleClickTemplate;
        private clickCancel;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private getPlugins;
        private getPluginsInfo;
    }
    interface IPlugins extends IDetails {
        widget: string;
        category: string | null;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL3" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL3 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptOrganism: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100555_/l2/pluginExplore/pluginExploreListAddL4" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL4 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptPage: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private verifyModuleConfig;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/plugins/pluginTestUtils" {
    /**
     * Where a test case can run:
     * - 'browser': needs real DOM/customElements (mounts the component, dispatches events, etc.).
     * - 'vscode': pure logic, runs without DOM (e.g. an exported function that only transforms data).
     * When in doubt, use 'browser' — it's the environment with full fidelity; 'vscode' is opt-in
     * only for logic proven to be DOM-independent.
     */
    export type TestEnv = 'browser' | 'vscode';
    export interface IPluginTestParams {
        input?: any;
        expected: any;
        /** When true, `compare` checks that `expected` is a subset of `actual` (useful for large/dynamic outputs). */
        contains?: boolean;
    }
    /**
     * Shape-compatible with `ICANTest` (tsTestAST.ts): same functionName/params pair,
     * with `env` added so the runner can decide where to execute each function.
     */
    export interface IPluginTestCase {
        functionName: string;
        env: TestEnv;
        params: IPluginTestParams[];
    }
    /** Sorts tests so 'browser' comes before 'vscode' — use before running a batch. */
    export function sortByEnvironment(tests: IPluginTestCase[]): IPluginTestCase[];
    export function isBrowser(): boolean;
    /**
     * Creates the element, applies properties, appends it to the document and waits for the first render.
     * Every call is tracked so `cleanup()` can remove it later — never forget to call cleanup().
     */
    export function mount<T extends HTMLElement = HTMLElement>(tag: string, props?: Record<string, any>): Promise<T>;
    /** Looks inside the shadow DOM if it exists, otherwise falls back to the light DOM (plugins vary between the two). */
    export function query(el: Element, selector: string): Element | null;
    /**
     * Replaces `mls.*` keys with mocked values; returns a function that restores the original state.
     * `cleanup()` also restores any pending override, so using only overrideMls is already safe
     * even if the test throws before manually calling the restorer.
     */
    export function overrideMls(overrides: Record<string, any>): () => void;
    /** Removes every mounted element and undoes any pending `mls.*` overrides. Call at the end of each test (try/finally). */
    export function cleanup(): void;
    /**
     * Universal contract check (layer 1 of the strategy): element registered and renders without throwing.
     * Works for any of the 88 plugins, regardless of type.
     */
    export function mountAndVerify(tag: string, props?: Record<string, any>): Promise<{
        registered: boolean;
        rendered: boolean;
    }>;
    /**
     * Compares the actual value against the expected one (deep-equal with normalization) and throws
     * a formatted error on mismatch — keeps the "threw = failed" semantics of the ICAN runner.
     */
    export function compare(actual: any, expected: any, opts?: {
        contains?: boolean;
    }): void;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginActiveUsers" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginActiveUsers extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginActiveUsers" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginActiveUsers extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginErrors" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginErrors extends PluginBaseModule {
        filter: string;
        chartData: {};
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            filter: string;
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginErrors" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginErrors extends PluginBaseModule {
        filter: string;
        chartData: {};
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginExpenses" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExpenses extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExpenses extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginRegionalLatency" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginRegionalLatency extends PluginBaseModule {
        filter: string;
        chartDataBar: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        bar: HTMLDivElement | undefined;
        map: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginRegionalLatency" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginRegionalLatency extends PluginBaseModule {
        filter: string;
        chartDataBar: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        bar: HTMLDivElement | undefined;
        map: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginResponseTime" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginResponseTime extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginResponseTime extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginSales" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSales extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSales" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSales extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginSiteMonitorDashboard/pluginSpikes" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSpikes extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes.test" {
    import { IPluginTestCase } from "_102027_/l2/plugins/pluginTestUtils";
    export const tests: IPluginTestCase[];
    export function testSmoke(testCase: {
        expected: any;
    }): Promise<string>;
    export function testPrepare(testCase: {
        input: {
            mode: 'simplified' | 'full';
        };
        expected: any;
    }): Promise<string>;
    export function testHandleChange(testCase: {
        input: {
            selectedValue: string;
        };
        expected: any;
    }): Promise<string>;
    export function testRenderRespectsScope(testCase: {
        input: {
            scope: string;
        };
        expected: any;
    }): Promise<string>;
    export function testPluginData(testCase: {
        expected: any;
    }): Promise<string>;
}
declare module "_100555_/l2/pluginSiteMonitorDashboard/pluginSpikes" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSpikes extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100555_/l2/pluginTester/pluginPluginRunTest" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    interface ITestCaseResult {
        functionName: string;
        env: string;
        index: number;
        status: 'pass' | 'fail';
        message: string;
    }
    interface ITestFileResult {
        file: string;
        status: 'ok' | 'import-error' | 'no-tests';
        error?: string;
        cases: ITestCaseResult[];
    }
    export class PluginPluginRunTest extends PluginBaseModule {
        private msg;
        running: boolean;
        hasRun: boolean;
        totalFiles: number;
        totalPassed: number;
        totalFailed: number;
        totalNoTests: number;
        results: ITestFileResult[];
        createRenderRoot(): this;
        render(): TemplateResult;
        private renderPlayIcon;
        private renderSpinnerIcon;
        private renderFileResult;
        runAll(): Promise<void>;
        private findTestFiles;
        private runFile;
        private logToConsole;
    }
}
