/// <mls fileReference="_100555_/l2/pluginTester/pluginPluginRunTest.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { property, customElement } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
import { ordenarPorAmbiente } from '/_102027_/l2/plugins/pluginTestUtils.js';
import { collab_fileTest } from '/_100554_/l2/collabIcons.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Executar testes de plugins',
    info: 'Procura todos os arquivos plugin*.test.ts do projeto atual e executa os testes declarados, mostrando o resultado no console.',
    run: 'Executar',
    running: 'Executando...',
    noProject: 'Nenhum projeto aberto.',
    summary: (arquivos, passou, falhou, semTestes) => `${arquivos} arquivo(s) — ${passou} passou, ${falhou} falhou, ${semTestes} sem testes`,
};
const message_en = {
    title: 'Run plugin tests',
    info: 'Finds every plugin*.test.ts file in the current project and runs its declared tests, logging the result to the console.',
    run: 'Run',
    running: 'Running...',
    noProject: 'No project open.',
    summary: (arquivos, passou, falhou, semTestes) => `${arquivos} file(s) — ${passou} passed, ${falhou} failed, ${semTestes} without tests`,
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Plugin Run Test",
    getSvg() {
        return collab_fileTest;
    }
};
let PluginPluginRunTest = class PluginPluginRunTest extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-tester--plugin-plugin-run-test-100555 {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
}
plugin-tester--plugin-plugin-run-test-100555 header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
plugin-tester--plugin-plugin-run-test-100555 h2 {
  font-size: 18px;
  font-weight: bold;
  margin: 0;
}
plugin-tester--plugin-plugin-run-test-100555 .actions {
  margin: 1rem 0;
}
plugin-tester--plugin-plugin-run-test-100555 button {
  background-color: var(--active-color);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: #fff;
  cursor: pointer;
  min-width: 80px;
}
plugin-tester--plugin-plugin-run-test-100555 button:hover {
  background-color: var(--active-color-hover);
}
plugin-tester--plugin-plugin-run-test-100555 button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
plugin-tester--plugin-plugin-run-test-100555 .summary {
  display: block;
  margin-top: 0.5rem;
  color: var(--text-primary-color);
}
`);
        this.msg = messages['en'];
        this.rodando = false;
        this.totalArquivos = 0;
        this.totalPassou = 0;
        this.totalFalhou = 0;
        this.totalSemTestes = 0;
        this.jaRodou = false;
    }
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="plugin-container">
                <header>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </header>
                <small>${this.msg.info}</small>
                <div class="actions">
                    <button ?disabled=${this.rodando} @click=${this.runAll}>
                        ${this.rodando ? this.msg.running : this.msg.run}
                    </button>
                </div>
                ${this.jaRodou ? html `
                    <small class="summary">
                        ${this.msg.summary(this.totalArquivos, this.totalPassou, this.totalFalhou, this.totalSemTestes)}
                    </small>
                ` : ''}
            </div>
        `;
    }
    async runAll() {
        if (this.rodando)
            return;
        this.rodando = true;
        const project = mls.actualProject;
        if (!project) {
            console.error(`[pluginPluginRunTest] ${this.msg.noProject}`);
            this.rodando = false;
            return;
        }
        const arquivos = this.buscarArquivosDeTeste(project);
        console.group(`%c[pluginPluginRunTest] ${arquivos.length} arquivo(s) plugin*.test.ts encontrados no projeto ${project}`, 'font-weight:bold');
        const resultados = [];
        for (const arquivo of arquivos) {
            const resultado = await this.executarArquivo(arquivo);
            resultados.push(resultado);
            this.logResultadoArquivo(resultado);
        }
        this.totalArquivos = resultados.length;
        this.totalPassou = resultados.reduce((acc, r) => acc + r.casos.filter(c => c.status === 'pass').length, 0);
        this.totalFalhou = resultados.reduce((acc, r) => acc + r.casos.filter(c => c.status === 'fail').length, 0);
        this.totalSemTestes = resultados.filter(r => r.status === 'sem-testes').length;
        this.jaRodou = true;
        const cor = this.totalFalhou > 0 ? 'color:#c0392b;font-weight:bold' : 'color:#27ae60;font-weight:bold';
        console.info(`%c[pluginPluginRunTest] ${this.msg.summary(this.totalArquivos, this.totalPassou, this.totalFalhou, this.totalSemTestes)}`, cor);
        console.groupEnd();
        this.rodando = false;
    }
    buscarArquivosDeTeste(project) {
        return Object.keys(mls.stor.files)
            .map((key) => mls.stor.files[key])
            .filter((file) => file && file.project === project && file.extension === '.test.ts' && file.shortName.startsWith('plugin'));
    }
    async executarArquivo(file) {
        const nomeArquivo = file.folder ? `${file.folder}/${file.shortName}.test.ts` : `${file.shortName}.test.ts`;
        const suffix = `.test.js?cacheBuster=${Date.now()}`;
        const caminho = file.folder
            ? `/_${file.project}_/l2/${file.folder}_${file.shortName}${suffix}`
            : `/_${file.project}_/l2/${file.shortName}${suffix}`;
        let module;
        try {
            module = await import(caminho);
        }
        catch (err) {
            return { arquivo: nomeArquivo, status: 'erro-import', erro: err?.message ?? String(err), casos: [] };
        }
        const declarados = Array.isArray(module.tests)
            ? module.tests.map((t) => ({ env: 'browser', ...t }))
            : [];
        if (declarados.length === 0) {
            return { arquivo: nomeArquivo, status: 'sem-testes', casos: [] };
        }
        const ordenados = ordenarPorAmbiente(declarados);
        const casos = [];
        for (const teste of ordenados) {
            const fn = module[teste.functionName];
            if (typeof fn !== 'function') {
                casos.push({
                    functionName: teste.functionName,
                    env: teste.env,
                    indice: -1,
                    status: 'fail',
                    mensagem: `Função '${teste.functionName}' não exportada pelo módulo.`,
                });
                continue;
            }
            const params = Array.isArray(teste.params) && teste.params.length > 0 ? teste.params : [{}];
            for (let i = 0; i < params.length; i++) {
                try {
                    const resultado = await fn(params[i]);
                    casos.push({
                        functionName: teste.functionName,
                        env: teste.env,
                        indice: i,
                        status: 'pass',
                        mensagem: typeof resultado === 'string' ? resultado : JSON.stringify(resultado),
                    });
                }
                catch (err) {
                    casos.push({
                        functionName: teste.functionName,
                        env: teste.env,
                        indice: i,
                        status: 'fail',
                        mensagem: err?.message ?? String(err),
                    });
                }
            }
        }
        return { arquivo: nomeArquivo, status: 'ok', casos };
    }
    logResultadoArquivo(resultado) {
        if (resultado.status === 'erro-import') {
            console.error(`✗ ${resultado.arquivo} — falha ao importar: ${resultado.erro}`);
            return;
        }
        if (resultado.status === 'sem-testes') {
            console.info(`… ${resultado.arquivo} — nenhum teste declarado`);
            return;
        }
        const passou = resultado.casos.filter(c => c.status === 'pass').length;
        const falhou = resultado.casos.filter(c => c.status === 'fail').length;
        const cor = falhou > 0 ? 'color:#c0392b' : 'color:#27ae60';
        console.groupCollapsed(`%c${falhou > 0 ? '✗' : '✓'} ${resultado.arquivo} — ${passou} passou, ${falhou} falhou`, cor);
        console.table(resultado.casos.map((c) => ({
            teste: c.functionName,
            caso: c.indice,
            env: c.env,
            status: c.status,
            detalhe: c.mensagem,
        })));
        console.groupEnd();
    }
};
__decorate([
    property({ type: Boolean })
], PluginPluginRunTest.prototype, "rodando", void 0);
__decorate([
    property({ type: Number })
], PluginPluginRunTest.prototype, "totalArquivos", void 0);
__decorate([
    property({ type: Number })
], PluginPluginRunTest.prototype, "totalPassou", void 0);
__decorate([
    property({ type: Number })
], PluginPluginRunTest.prototype, "totalFalhou", void 0);
__decorate([
    property({ type: Number })
], PluginPluginRunTest.prototype, "totalSemTestes", void 0);
__decorate([
    property({ type: Boolean })
], PluginPluginRunTest.prototype, "jaRodou", void 0);
PluginPluginRunTest = __decorate([
    customElement('plugin-tester--plugin-plugin-run-test-100555')
], PluginPluginRunTest);
export { PluginPluginRunTest };
