/// <mls fileReference="_100555_/l2/pluginTester/pluginPluginRunTest.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { property, customElement } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
import { sortByEnvironment } from '/_102027_/l2/plugins/pluginTestUtils.js';
import { collabImport } from '/_102027_/l2/collabImport.js';
import { collab_fileTest } from '/_100554_/l2/collabIcons.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Executar testes de plugins',
    info: 'Clique em executar para procurar e rodar os testes de todos os arquivos plugin*.test.ts do projeto atual.',
    run: 'Executar testes',
    running: 'Executando...',
    noProject: 'Nenhum projeto aberto.',
    noTests: 'nenhum teste declarado',
    importError: 'falha ao importar',
    caseSummary: (passed, failed) => `${passed} passou, ${failed} falhou`,
    summary: (files, passed, failed, noTests) => `${files} arquivo(s) — ${passed} passou, ${failed} falhou, ${noTests} sem testes`,
};
const message_en = {
    title: 'Run plugin tests',
    info: 'Click run to find and execute the tests declared in every plugin*.test.ts file in the current project.',
    run: 'Run tests',
    running: 'Running...',
    noProject: 'No project open.',
    noTests: 'no tests declared',
    importError: 'failed to import',
    caseSummary: (passed, failed) => `${passed} passed, ${failed} failed`,
    summary: (files, passed, failed, noTests) => `${files} file(s) — ${passed} passed, ${failed} failed, ${noTests} without tests`,
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Plugin Run Test",
    getSvg() {
        return collab_fileTest;
    }
};
let PluginPluginRunTest = class PluginPluginRunTest extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-tester--plugin-plugin-run-test-100555 {
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  color: var(--text-primary-color);
}
plugin-tester--plugin-plugin-run-test-100555 .plugin-container {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}
plugin-tester--plugin-plugin-run-test-100555 header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}
plugin-tester--plugin-plugin-run-test-100555 .title-group {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
plugin-tester--plugin-plugin-run-test-100555 .title-group .icon {
  display: flex;
  color: var(--active-color);
}
plugin-tester--plugin-plugin-run-test-100555 .title-group h2 {
  margin: 0;
  font-size: 18px;
  font-weight: bold;
}
plugin-tester--plugin-plugin-run-test-100555 .play-button {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  flex-shrink: 0;
  border-radius: 50%;
  border: none;
  background-color: var(--active-color);
  color: #fff;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.1s ease;
}
plugin-tester--plugin-plugin-run-test-100555 .play-button:hover:not(:disabled) {
  background-color: var(--active-color-hover);
}
plugin-tester--plugin-plugin-run-test-100555 .play-button:active:not(:disabled) {
  transform: scale(0.94);
}
plugin-tester--plugin-plugin-run-test-100555 .play-button:disabled {
  cursor: not-allowed;
  opacity: 0.85;
}
plugin-tester--plugin-plugin-run-test-100555 .play-button.running svg {
  animation: plugin-run-test-spin 1s linear infinite;
}
@keyframes plugin-run-test-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
plugin-tester--plugin-plugin-run-test-100555 .terminal {
  background-color: #0d1117;
  color: #c9d1d9;
  font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
  font-size: 13px;
  line-height: 1.6;
  border-radius: 8px;
  padding: 0.85rem 1rem;
  max-height: 420px;
  overflow-y: auto;
  border: 1px solid #30363d;
}
plugin-tester--plugin-plugin-run-test-100555 .terminal-placeholder {
  color: #6e7681;
  font-style: italic;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result {
  border-bottom: 1px solid #21262d;
  padding: 0.4rem 0;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result:last-of-type {
  border-bottom: none;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result summary {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  list-style: none;
  user-select: none;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result summary::-webkit-details-marker {
  display: none;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result summary::before {
  content: '▸';
  display: inline-block;
  width: 0.8rem;
  color: #6e7681;
  transition: transform 0.15s ease;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result[open] summary::before {
  transform: rotate(90deg);
}
plugin-tester--plugin-plugin-run-test-100555 .file-result .status-icon {
  font-weight: bold;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result.pass .status-icon {
  color: #3fb950;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result.fail .status-icon {
  color: #f85149;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result.empty .status-icon {
  color: #6e7681;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result .file-name {
  color: #58a6ff;
}
plugin-tester--plugin-plugin-run-test-100555 .file-result .file-meta {
  color: #6e7681;
  margin-left: auto;
  white-space: nowrap;
}
plugin-tester--plugin-plugin-run-test-100555 .case-list {
  margin: 0.5rem 0 0.25rem 1.3rem;
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
}
plugin-tester--plugin-plugin-run-test-100555 .case-line {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: 0.5rem;
}
plugin-tester--plugin-plugin-run-test-100555 .case-line .case-status {
  font-weight: bold;
}
plugin-tester--plugin-plugin-run-test-100555 .case-line.pass .case-status {
  color: #3fb950;
}
plugin-tester--plugin-plugin-run-test-100555 .case-line.fail .case-status {
  color: #f85149;
}
plugin-tester--plugin-plugin-run-test-100555 .case-line .case-name {
  color: #c9d1d9;
}
plugin-tester--plugin-plugin-run-test-100555 .case-line .case-index {
  color: #6e7681;
}
plugin-tester--plugin-plugin-run-test-100555 .case-line .case-env {
  color: #6e7681;
  font-size: 11px;
  border: 1px solid #30363d;
  border-radius: 4px;
  padding: 0 0.35rem;
}
plugin-tester--plugin-plugin-run-test-100555 .case-error {
  flex-basis: 100%;
  color: #f85149;
  padding-left: 1.3rem;
  white-space: pre-wrap;
}
plugin-tester--plugin-plugin-run-test-100555 .terminal-summary {
  margin-top: 0.6rem;
  padding-top: 0.6rem;
  border-top: 1px solid #30363d;
  font-weight: bold;
}
plugin-tester--plugin-plugin-run-test-100555 .terminal-summary.pass {
  color: #3fb950;
}
plugin-tester--plugin-plugin-run-test-100555 .terminal-summary.fail {
  color: #f85149;
}
`);
        this.msg = messages['en'];
        this.running = false;
        this.hasRun = false;
        this.totalFiles = 0;
        this.totalPassed = 0;
        this.totalFailed = 0;
        this.totalNoTests = 0;
        this.results = [];
    }
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="plugin-container">
                <header>
                    <div class="title-group">
                        <span class="icon">${pluginData.getSvg()}</span>
                        <h2>${pluginData.title}</h2>
                    </div>
                    <button
                        class="play-button ${this.running ? 'running' : ''}"
                        ?disabled=${this.running}
                        @click=${this.runAll}
                        title=${this.running ? this.msg.running : this.msg.run}
                        aria-label=${this.running ? this.msg.running : this.msg.run}
                    >
                        ${this.running ? this.renderSpinnerIcon() : this.renderPlayIcon()}
                    </button>
                </header>

                <div class="terminal">
                    ${!this.hasRun && this.results.length === 0
            ? html `<div class="terminal-placeholder">${this.msg.info}</div>`
            : ''}
                    ${this.results.map((result) => this.renderFileResult(result))}
                    ${this.hasRun ? html `
                        <div class="terminal-summary ${this.totalFailed > 0 ? 'fail' : 'pass'}">
                            ${this.msg.summary(this.totalFiles, this.totalPassed, this.totalFailed, this.totalNoTests)}
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }
    renderPlayIcon() {
        return svg `<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>`;
    }
    renderSpinnerIcon() {
        return svg `
            <svg viewBox="0 0 24 24" width="16" height="16" class="spinner">
                <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-dasharray="40 100"/>
            </svg>
        `;
    }
    renderFileResult(result) {
        if (result.status === 'import-error') {
            return html `
                <details class="file-result fail" open>
                    <summary>
                        <span class="status-icon">✗</span>
                        <span class="file-name">${result.file}</span>
                        <span class="file-meta">${this.msg.importError}</span>
                    </summary>
                    <div class="case-list">
                        <div class="case-error">${result.error}</div>
                    </div>
                </details>
            `;
        }
        if (result.status === 'no-tests') {
            return html `
                <details class="file-result empty">
                    <summary>
                        <span class="status-icon">…</span>
                        <span class="file-name">${result.file}</span>
                        <span class="file-meta">${this.msg.noTests}</span>
                    </summary>
                </details>
            `;
        }
        const passed = result.cases.filter((c) => c.status === 'pass').length;
        const failed = result.cases.filter((c) => c.status === 'fail').length;
        return html `
            <details class="file-result ${failed > 0 ? 'fail' : 'pass'}">
                <summary>
                    <span class="status-icon">${failed > 0 ? '✗' : '✓'}</span>
                    <span class="file-name">${result.file}</span>
                    <span class="file-meta">${this.msg.caseSummary(passed, failed)}</span>
                </summary>
                <div class="case-list">
                    ${result.cases.map((c) => html `
                        <div class="case-line ${c.status}">
                            <span class="case-status">${c.status === 'pass' ? '✓' : '✗'}</span>
                            <span class="case-name">${c.functionName}</span>
                            ${c.index >= 0 ? html `<span class="case-index">#${c.index}</span>` : ''}
                            <span class="case-env">${c.env}</span>
                            ${c.status === 'fail' ? html `<div class="case-error">${c.message}</div>` : ''}
                        </div>
                    `)}
                </div>
            </details>
        `;
    }
    async runAll() {
        if (this.running)
            return;
        this.running = true;
        this.hasRun = false;
        this.results = [];
        this.totalFiles = 0;
        this.totalPassed = 0;
        this.totalFailed = 0;
        this.totalNoTests = 0;
        const project = mls.actualProject;
        if (!project) {
            console.error(`[PluginPluginRunTest] ${this.msg.noProject}`);
            this.running = false;
            return;
        }
        const files = this.findTestFiles(project);
        console.group(`%c[PluginPluginRunTest] Found ${files.length} plugin*.test.ts file(s) in project ${project}`, 'font-weight:bold');
        for (const file of files) {
            const result = await this.runFile(file);
            this.results = [...this.results, result];
            this.logToConsole(result);
        }
        this.totalFiles = this.results.length;
        this.totalPassed = this.results.reduce((acc, r) => acc + r.cases.filter((c) => c.status === 'pass').length, 0);
        this.totalFailed = this.results.reduce((acc, r) => acc + r.cases.filter((c) => c.status === 'fail').length, 0);
        this.totalNoTests = this.results.filter((r) => r.status === 'no-tests').length;
        this.hasRun = true;
        const color = this.totalFailed > 0 ? 'color:#e06c75;font-weight:bold' : 'color:#98c379;font-weight:bold';
        console.info(`%c[PluginPluginRunTest] ${this.msg.summary(this.totalFiles, this.totalPassed, this.totalFailed, this.totalNoTests)}`, color);
        console.groupEnd();
        this.running = false;
    }
    findTestFiles(project) {
        return Object.keys(mls.stor.files)
            .map((key) => mls.stor.files[key])
            .filter((file) => file && file.project === project && file.extension === '.test.ts' && file.shortName.startsWith('plugin'));
    }
    async runFile(file) {
        const fileName = file.folder ? `${file.folder}/${file.shortName}.test.ts` : `${file.shortName}.test.ts`;
        let module;
        try {
            module = await collabImport({
                project: file.project,
                shortName: file.shortName,
                folder: file.folder,
                extension: '.test.ts',
            });
        }
        catch (err) {
            return { file: fileName, status: 'import-error', error: err?.message ?? String(err), cases: [] };
        }
        const declaredTests = Array.isArray(module.tests)
            ? module.tests.map((t) => ({ env: 'browser', ...t }))
            : [];
        if (declaredTests.length === 0) {
            return { file: fileName, status: 'no-tests', cases: [] };
        }
        const orderedTests = sortByEnvironment(declaredTests);
        const cases = [];
        for (const test of orderedTests) {
            const fn = module[test.functionName];
            if (typeof fn !== 'function') {
                cases.push({
                    functionName: test.functionName,
                    env: test.env,
                    index: -1,
                    status: 'fail',
                    message: `Function '${test.functionName}' is not exported by the module.`,
                });
                continue;
            }
            const params = Array.isArray(test.params) && test.params.length > 0 ? test.params : [{}];
            for (let i = 0; i < params.length; i++) {
                try {
                    const result = await fn(params[i]);
                    cases.push({
                        functionName: test.functionName,
                        env: test.env,
                        index: i,
                        status: 'pass',
                        message: typeof result === 'string' ? result : JSON.stringify(result),
                    });
                }
                catch (err) {
                    cases.push({
                        functionName: test.functionName,
                        env: test.env,
                        index: i,
                        status: 'fail',
                        message: err?.message ?? String(err),
                    });
                }
            }
        }
        return { file: fileName, status: 'ok', cases };
    }
    logToConsole(result) {
        if (result.status === 'import-error') {
            console.error(`✗ ${result.file} — ${this.msg.importError}: ${result.error}`);
            return;
        }
        if (result.status === 'no-tests') {
            console.info(`… ${result.file} — ${this.msg.noTests}`);
            return;
        }
        const passed = result.cases.filter((c) => c.status === 'pass').length;
        const failed = result.cases.filter((c) => c.status === 'fail').length;
        const color = failed > 0 ? 'color:#e06c75' : 'color:#98c379';
        console.groupCollapsed(`%c${failed > 0 ? '✗' : '✓'} ${result.file} — ${passed} passed, ${failed} failed`, color);
        console.table(result.cases.map((c) => ({
            test: c.functionName,
            case: c.index,
            env: c.env,
            status: c.status,
            detail: c.message,
        })));
        console.groupEnd();
    }
};
__decorate([
    property({ type: Boolean })
], PluginPluginRunTest.prototype, "running", void 0);
__decorate([
    property({ type: Boolean })
], PluginPluginRunTest.prototype, "hasRun", void 0);
__decorate([
    property({ type: Number })
], PluginPluginRunTest.prototype, "totalFiles", void 0);
__decorate([
    property({ type: Number })
], PluginPluginRunTest.prototype, "totalPassed", void 0);
__decorate([
    property({ type: Number })
], PluginPluginRunTest.prototype, "totalFailed", void 0);
__decorate([
    property({ type: Number })
], PluginPluginRunTest.prototype, "totalNoTests", void 0);
__decorate([
    property({ attribute: false })
], PluginPluginRunTest.prototype, "results", void 0);
PluginPluginRunTest = __decorate([
    customElement('plugin-tester--plugin-plugin-run-test-100555')
], PluginPluginRunTest);
export { PluginPluginRunTest };
