/// <mls fileReference="_100555_/l2/pluginVerify/pluginVerifyError.test.ts" enhancement="_blank" />
import { mount, cleanup, compare, overrideMls, mountAndVerify } from '/_102027_/l2/plugins/pluginTestUtils.js';
import '/_100555_/l2/pluginVerify/pluginVerifyError.js'; // side-effect import: guarantees this module's top-level registration (e.g. @customElement) always runs, regardless of whether the named imports above survive compilation (TS elides imports used only as types)
const TAG = 'plugin-verify--plugin-verify-error-100555';
export const tests = [
    // ---- browser: need real DOM/customElements ----
    { functionName: 'testSmoke', env: 'browser', params: [
            { expected: { registered: true, rendered: true } },
        ] },
    // `setFilesErros` is the fragile message-parsing routine: it extracts a numeric project id
    // and a file path out of strings like "--- Error compiling _100554_/l2/x". It is private,
    // so it is called through a cast on a mounted instance.
    { functionName: 'testSetFilesErrosParsing', env: 'browser', params: [
            { input: { errors: ['--- Error compiling _100554_/l2/x'] },
                expected: { calls: [{ prj: 100554, path: '/l2/x' }] } },
            // Edge case: a non-numeric "project id" segment. The source falls back to 0
            // (see the "// error" comment next to `if (isNaN(prID)) prID = 0;`) instead of
            // discarding the entry, so it still attempts a (very likely wrong) file lookup.
            { input: { errors: ['--- Error compiling _abc_/l2/y.ts'] },
                expected: { calls: [{ prj: 0, path: '/l2/y.ts' }] } },
        ] },
    // Normal (non-canceled) path, for contrast with the quirk test below: when verification
    // runs to completion, `tsFree` faithfully reflects whether errors were found.
    { functionName: 'testPrepareFiresTsFreeBasedOnErrorsWhenNotCanceled', env: 'browser', params: [
            { expected: { errorsFound: 1, wasCanceled: false, firedTsFree: false } },
        ] },
    // DOCUMENTED QUIRK (current characteristic, not something to fix here): when the user
    // cancels verification mid-run, `prepare()` calls `fireEvent(true)` unconditionally —
    // regardless of how many errors were already collected in `listErrors`. So the dispatched
    // 'ProjectCompilationComplete' event reports `tsFree: true` even though errors were found.
    { functionName: 'testPrepareCancelForcesTsFreeTrueDespiteErrors', env: 'browser', params: [
            { expected: { errorsFound: 2, wasCanceled: true, firedTsFree: true } },
        ] },
];
export async function testSmoke(testCase) {
    try {
        const result = await mountAndVerify(TAG);
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testSetFilesErrosParsing(testCase) {
    try {
        const el = await mount(TAG);
        const calls = [];
        overrideMls({
            stor: {
                getKeyToFiles: (prj, _level, path, _folder, _ext) => {
                    calls.push({ prj, path });
                    return `${prj}|${path}`;
                },
                files: {},
            },
        });
        el.setFilesErros(testCase.input.errors);
        const result = { calls };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
/** Shared mls mock setup so `prepare()` can run end-to-end without touching real Monaco/typescript services. */
function mockPrepareDependencies(el, compileAllMock) {
    return overrideMls({
        actualProject: 999001,
        actualLevel: 'test-level',
        editor: {
            InitMonaco: async () => { },
            getModels: () => ({ ts: true }),
        },
        l5: {
            getProjectDependencies: () => [],
        },
        stor: {
            LOCALPROJECTNUMBER: -999,
            getKeyToFiles: (prj, _level, path) => `${prj}|${path}`,
            files: {},
        },
        l2: {
            typescript: {
                compileAll: compileAllMock,
            },
        },
        events: {
            fire: async (_levels, _type, desc) => {
                firedEvents.push(desc ? JSON.parse(desc) : undefined);
            },
        },
    });
}
let firedEvents = [];
export async function testPrepareFiresTsFreeBasedOnErrorsWhenNotCanceled(testCase) {
    firedEvents = [];
    try {
        const el = await mount(TAG, { autoPrepare: false });
        mockPrepareDependencies(el, async (_project, onProgress) => {
            const results = ['--- Error compiling _999001_/l2/fileA.ts'];
            onProgress?.(1, 1, results);
            return results;
        });
        await el.prepare();
        const result = {
            errorsFound: el.listErrors.length,
            wasCanceled: !el.continueVerify,
            firedTsFree: firedEvents[0]?.tsFree,
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testPrepareCancelForcesTsFreeTrueDespiteErrors(testCase) {
    firedEvents = [];
    try {
        const el = await mount(TAG, { autoPrepare: false });
        mockPrepareDependencies(el, async (_project, onProgress) => {
            const results = ['--- Error compiling _999001_/l2/fileA.ts'];
            onProgress?.(1, 2, results);
            // Simulate the user clicking "cancel" mid-verification, after an error was already found.
            el.cancelVerify();
            results.push('--- Error compiling _999001_/l2/fileB.ts');
            onProgress?.(2, 2, results);
            return results;
        });
        await el.prepare();
        const result = {
            errorsFound: el.listErrors.length,
            wasCanceled: !el.continueVerify,
            firedTsFree: firedEvents[0]?.tsFree,
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
