/// <mls fileReference="_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { query, property, customElement } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
export const pluginData = {
    title: "Expenses",
    getSvg() {
        return svg `
     <svg svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 64zm64 320l-64 0 0-64c35.3 0 64 28.7 64 64zM64 192l0-64 64 0c0 35.3-28.7 64-64 64zM448 384c0-35.3 28.7-64 64-64l0 64-64 0zm64-192c-35.3 0-64-28.7-64-64l64 0 0 64zM288 160a96 96 0 1 1 0 192 96 96 0 1 1 0-192z"/></svg>
    `;
    }
};
let PluginExpenses = class PluginExpenses extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-site-monitor-dashboard--plugin-expenses-100555 {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-default);
  background-color: var(--surface-bg);
}
plugin-site-monitor-dashboard--plugin-expenses-100555 .plugin-body {
  height: 100%;
  width: 100%;
}
plugin-site-monitor-dashboard--plugin-expenses-100555 .plugin-container {
  background-color: #f4f5ff;
  border-radius: 8px;
  padding: 10px 0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  height: 100%;
  width: 100%;
}
plugin-site-monitor-dashboard--plugin-expenses-100555 header {
  display: flex;
  align-items: center;
  gap: 3rem;
  margin-bottom: 16px;
}
plugin-site-monitor-dashboard--plugin-expenses-100555 header > div {
  display: flex;
  gap: 0.5rem;
}
plugin-site-monitor-dashboard--plugin-expenses-100555 icon {
  margin-right: 10px;
}
plugin-site-monitor-dashboard--plugin-expenses-100555 h2 {
  font-size: 18px;
  font-weight: bold;
  margin: 0;
  color: #333;
}
plugin-site-monitor-dashboard--plugin-expenses-100555 small {
  color: #888;
  margin-left: auto;
  font-size: 14px;
}
plugin-site-monitor-dashboard--plugin-expenses-100555 p {
  font-size: 16px;
  color: #555;
}
plugin-site-monitor-dashboard--plugin-expenses-100555 select {
  border-radius: 13px;
  border: 1px solid #cecece;
  padding: 0.3rem;
  cursor: pointer;
  outline: none;
}
`);
        this.filter = "today";
        this.chartData = {};
        this.autoPrepare = false;
        this.mode = 'simplified';
    }
    async prepare() {
        const url = '/_100554_/l2/widgetCollabChart.js';
        await import(url);
        this.chartData = {
            tooltip: {
                trigger: "item",
                formatter: "{a} <br/>{b}: ${c} ({d}%)"
            },
            series: [
                {
                    name: "Expenses",
                    type: "pie",
                    radius: "50%",
                    data: [
                        { "value": 300, "name": "CDN" },
                        { "value": 250, "name": "EC2" },
                        { "value": 200, "name": "Database" },
                        { "value": 100, "name": "Domain" },
                        { "value": 70, "name": "Others" }
                    ],
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: "rgba(0, 0, 0, 0.5)"
                        }
                    }
                }
            ],
        };
        if (this.mode === 'full') {
            this.chartData.title = {
                text: "Expense Breakdown",
                subtext: "Total Expenses: $920",
                left: "center"
            };
            this.chartData.legend = {
                orient: "vertical",
                left: "left",
                data: ["CDN", "EC2", "Database", "Domain", "Others"]
            };
        }
        await this.updateComplete;
        const data = JSON.stringify(this.chartData);
        function escapeHTML(str) {
            return str
                .replace(/&/g, "&amp;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");
        }
        if (this.body)
            this.body.innerHTML = `<widget-collab-chart-100554 renderer="svg" data="${escapeHTML(data)}"></widget-collab-chart-100554>`;
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
                <select @change=${this.handleChange}>
                    <option value="today">Today</option>
                    <option value="week">Week</option>
                    <option value="mounth">Last 30 days</option>
                    <option value="all">All Time</option>
                </select>
            </header>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body"></div>`;
    }
    handleChange(e) {
        const target = e.target;
        const value = target.value;
        this.filter = value;
        this.prepare();
    }
};
__decorate([
    property({ type: String })
], PluginExpenses.prototype, "filter", void 0);
__decorate([
    property()
], PluginExpenses.prototype, "chartData", void 0);
__decorate([
    property({ type: Boolean })
], PluginExpenses.prototype, "autoPrepare", void 0);
__decorate([
    property({ type: String })
], PluginExpenses.prototype, "mode", void 0);
__decorate([
    query('.plugin-body')
], PluginExpenses.prototype, "body", void 0);
PluginExpenses = __decorate([
    customElement('plugin-site-monitor-dashboard--plugin-expenses-100555')
], PluginExpenses);
export { PluginExpenses };
