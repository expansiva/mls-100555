/// <mls fileReference="_100555_/l2/pluginSiteMonitorDashboard/pluginSiteMonitorDashboardActiveUsers.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { query, property } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/plugins/pluginBaseModule.js';
export const pluginData = {
    title: "Active Users",
    getSvg() {
        return svg `
     <svg svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M144 0a80 80 0 1 1 0 160A80 80 0 1 1 144 0zM512 0a80 80 0 1 1 0 160A80 80 0 1 1 512 0zM0 298.7C0 239.8 47.8 192 106.7 192l42.7 0c15.9 0 31 3.5 44.6 9.7c-1.3 7.2-1.9 14.7-1.9 22.3c0 38.2 16.8 72.5 43.3 96c-.2 0-.4 0-.7 0L21.3 320C9.6 320 0 310.4 0 298.7zM405.3 320c-.2 0-.4 0-.7 0c26.6-23.5 43.3-57.8 43.3-96c0-7.6-.7-15-1.9-22.3c13.6-6.3 28.7-9.7 44.6-9.7l42.7 0C592.2 192 640 239.8 640 298.7c0 11.8-9.6 21.3-21.3 21.3l-213.3 0zM224 224a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zM128 485.3C128 411.7 187.7 352 261.3 352l117.3 0C452.3 352 512 411.7 512 485.3c0 14.7-11.9 26.7-26.7 26.7l-330.7 0c-14.7 0-26.7-11.9-26.7-26.7z"/></svg>
    `;
    }
};
export class PluginSiteMonitorDashboardActiveUsers extends PluginBaseModule {
    constructor() {
        super(...arguments);
        this.filter = "today";
        this.chartData = {};
        this.autoPrepare = false;
        this.mode = 'simplified';
    }
    async prepare() {
        await import('/_100554_/l2/widgetCollabChart.js');
        this.chartData = {
            "tooltip": {
                "trigger": "axis"
            },
            "xAxis": {
                "type": "category",
                "boundaryGap": false,
                "data": ["12:00", "12:05", "12:10", "12:15", "12:20", "12:25", "12:30"]
            },
            "yAxis": {
                "type": "value",
                "name": "Number of Users"
            },
            "series": [
                {
                    "name": "Anonymous Users",
                    "type": "line",
                    "data": [120, 132, 101, 134, 90, 230, 210],
                    "markPoint": {
                        "data": [
                            { "type": "max", "name": "Max" },
                            { "type": "min", "name": "Min" }
                        ]
                    },
                    "markLine": {
                        "data": [{ "type": "average", "name": "Average" }]
                    }
                },
                {
                    "name": "Logged-In Users",
                    "type": "line",
                    "data": [220, 182, 191, 234, 290, 330, 310],
                    "markPoint": {
                        "data": [
                            { "type": "max", "name": "Max" },
                            { "type": "min", "name": "Min" }
                        ]
                    },
                    "markLine": {
                        "data": [{ "type": "average", "name": "Average" }]
                    }
                }
            ],
        };
        if (this.mode === 'full') {
            this.chartData.title = {
                text: "Active Users",
            };
            this.chartData.legend = {
                data: ["Anonymous Users", "Logged-In Users"]
            };
        }
        await this.updateComplete;
        const data = JSON.stringify(this.chartData);
        function escapeHTML(str) {
            return str
                .replace(/&/g, "&amp;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");
        }
        if (this.body) {
            this.body.innerHTML = `<widget-collab-chart-100554 renderer="svg" data="${escapeHTML(data)}"></widget-collab-chart-100554>`;
        }
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
                <select @change=${this.handleChange}>
                    <option value="today">Today</option>
                    <option value="week">Week</option>
                    <option value="mounth">Last 30 days</option>
                    <option value="all">All Time</option>
                </select>
            </header>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body"></div>`;
    }
    handleChange(e) {
        const target = e.target;
        const value = target.value;
        this.filter = value;
        this.prepare();
    }
}
__decorate([
    property({ type: String })
], PluginSiteMonitorDashboardActiveUsers.prototype, "filter", void 0);
__decorate([
    property()
], PluginSiteMonitorDashboardActiveUsers.prototype, "chartData", void 0);
__decorate([
    property({ type: Boolean })
], PluginSiteMonitorDashboardActiveUsers.prototype, "autoPrepare", void 0);
__decorate([
    property({ type: String })
], PluginSiteMonitorDashboardActiveUsers.prototype, "mode", void 0);
__decorate([
    query('.plugin-body')
], PluginSiteMonitorDashboardActiveUsers.prototype, "body", void 0);
if (!customElements.get('plugin-site-monitor-dashboard-active-users-100555')) {
    customElements.define('plugin-site-monitor-dashboard-active-users-100555', PluginSiteMonitorDashboardActiveUsers);
}
