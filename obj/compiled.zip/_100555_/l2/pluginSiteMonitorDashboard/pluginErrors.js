/// <mls fileReference="_100555_/l2/pluginSiteMonitorDashboard/pluginErrors.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { query, property, customElement } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
export const pluginData = {
    title: "Errors",
    getSvg() {
        return svg `
     <svg svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 32c14.2 0 27.3 7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480L40 480c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24l0 112c0 13.3 10.7 24 24 24s24-10.7 24-24l0-112c0-13.3-10.7-24-24-24zm32 224a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"/></svg>
    `;
    }
};
let PluginErrors = class PluginErrors extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-site-monitor-dashboard--plugin-errors-100555 {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
}
plugin-site-monitor-dashboard--plugin-errors-100555 .plugin-body {
  height: 100%;
  width: 100%;
}
plugin-site-monitor-dashboard--plugin-errors-100555 .plugin-container {
  background-color: #f4f5ff;
  padding: 10px 0;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  height: 100%;
  width: 100%;
}
plugin-site-monitor-dashboard--plugin-errors-100555 header {
  display: flex;
  align-items: center;
  gap: 3rem;
  margin-bottom: 16px;
}
plugin-site-monitor-dashboard--plugin-errors-100555 header > div {
  display: flex;
  gap: 0.5rem;
}
plugin-site-monitor-dashboard--plugin-errors-100555 icon {
  margin-right: 10px;
}
plugin-site-monitor-dashboard--plugin-errors-100555 h2 {
  font-size: 18px;
  font-weight: bold;
  margin: 0;
  color: #333;
}
plugin-site-monitor-dashboard--plugin-errors-100555 small {
  color: #888;
  margin-left: auto;
  font-size: 14px;
}
plugin-site-monitor-dashboard--plugin-errors-100555 p {
  font-size: 16px;
  color: #555;
}
plugin-site-monitor-dashboard--plugin-errors-100555 select {
  border-radius: 13px;
  border: 1px solid #cecece;
  padding: 0.3rem;
  cursor: pointer;
  outline: none;
}
`);
        this.filter = "today";
        this.chartData = {};
        this.autoPrepare = false;
    }
    async prepare() {
        await import('/_100554_/l2/widgetCollabChart.js');
        const dataByFilter = {
            today: [
                ['400', 3],
                ['401', 3],
                ['402', 0],
                ['403', 2],
                ['404', 3],
                ['405', 8],
                ['409', 3],
            ],
            week: [
                ['400', 14],
                ['401', 13],
                ['402', 16],
                ['403', 12],
                ['404', 13],
                ['405', 13],
                ['409', 13],
            ],
            mounth: [
                ['400', 43],
                ['401', 83],
                ['402', 86],
                ['403', 72],
                ['404', 43],
                ['405', 83],
                ['409', 43],
            ],
            all: [
                ['400', 143],
                ['401', 183],
                ['402', 186],
                ['403', 172],
                ['404', 143],
                ['405', 183],
                ['409', 143],
            ],
        };
        this.chartData = {
            legend: {},
            tooltip: {},
            dataset: {
                source: dataByFilter[this.filter || 'today']
            },
            xAxis: { type: 'category' },
            yAxis: {},
            series: [{
                    type: 'bar',
                    itemStyle: {
                        color: (p) => {
                            const colorList = ["#f68a55"];
                            return colorList[p.dataIndex];
                        }
                    }
                }],
        };
        await this.updateComplete;
        if (this.body)
            this.body.innerHTML = `<widget-collab-chart-100554 renderer="svg" data=${JSON.stringify(this.chartData)}></widget-collab-chart-100554>`;
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
                <select @change=${this.handleChange}>
                    <option value="today">Today</option>
                    <option value="week">Week</option>
                    <option value="mounth">Last 30 days</option>
                    <option value="all">All Time</option>
                </select>
            </header>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body"></div>`;
    }
    handleChange(e) {
        const target = e.target;
        const value = target.value;
        this.filter = value;
        this.prepare();
    }
};
__decorate([
    property({ type: String })
], PluginErrors.prototype, "filter", void 0);
__decorate([
    property()
], PluginErrors.prototype, "chartData", void 0);
__decorate([
    property({ type: Boolean })
], PluginErrors.prototype, "autoPrepare", void 0);
__decorate([
    query('.plugin-body')
], PluginErrors.prototype, "body", void 0);
PluginErrors = __decorate([
    customElement('plugin-site-monitor-dashboard--plugin-errors-100555')
], PluginErrors);
export { PluginErrors };
