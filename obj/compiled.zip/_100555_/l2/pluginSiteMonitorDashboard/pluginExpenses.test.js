/// <mls fileReference="_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.test.ts" enhancement="_blank" />
import { mount, cleanup, compare, query, mountAndVerify } from '/_102027_/l2/plugins/pluginTestUtils.js';
import { pluginData } from '/_100555_/l2/pluginSiteMonitorDashboard/pluginExpenses.js';
const TAG = 'plugin-site-monitor-dashboard--plugin-expenses-100555';
export const tests = [
    // ---- browser: need real DOM/customElements ----
    { functionName: 'testSmoke', env: 'browser', params: [
            { expected: { registered: true, rendered: true } },
        ] },
    { functionName: 'testPrepare', env: 'browser', params: [
            { input: { mode: 'full' },
                expected: { hasTitle: true, hasLegend: true, bodyHasWidget: true } },
            { input: { mode: 'simplified' },
                expected: { hasTitle: false, hasLegend: false, bodyHasWidget: true } },
        ] },
    { functionName: 'testHandleChange', env: 'browser', params: [
            { input: { selectedValue: 'week' }, expected: { filter: 'week' } },
            { input: { selectedValue: 'all' }, expected: { filter: 'all' } },
        ] },
    { functionName: 'testRenderRespectsScope', env: 'browser', params: [
            { input: { scope: 'dashboard' }, expected: { containerRendered: true } },
            { input: { scope: 'detail' }, expected: { containerRendered: false } },
        ] },
    // ---- vscode: pure logic, no DOM involved ----
    { functionName: 'testPluginData', env: 'vscode', params: [
            { expected: { title: 'Expenses', svgHasSvgTag: true } },
        ] },
];
export async function testSmoke(testCase) {
    try {
        const result = await mountAndVerify(TAG, { scope: 'dashboard' });
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testPrepare(testCase) {
    try {
        const el = await mount(TAG, { scope: 'dashboard', mode: testCase.input.mode });
        await el.prepare();
        const result = {
            hasTitle: !!el.chartData.title,
            hasLegend: !!el.chartData.legend,
            bodyHasWidget: !!query(el, 'widget-collab-chart-100554'),
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testHandleChange(testCase) {
    try {
        const el = await mount(TAG, { scope: 'dashboard' });
        el.handleChange({ target: { value: testCase.input.selectedValue } });
        const result = { filter: el.filter };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testRenderRespectsScope(testCase) {
    try {
        const el = await mount(TAG, { scope: testCase.input.scope });
        const result = { containerRendered: !!query(el, '.plugin-container') };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testPluginData(testCase) {
    const svg = pluginData.getSvg();
    const svgText = Array.isArray(svg?.strings) ? svg.strings.join('') : String(svg);
    const result = {
        title: pluginData.title,
        svgHasSvgTag: svgText.includes('<svg'),
    };
    compare(result, testCase.expected);
    return JSON.stringify(result);
}
