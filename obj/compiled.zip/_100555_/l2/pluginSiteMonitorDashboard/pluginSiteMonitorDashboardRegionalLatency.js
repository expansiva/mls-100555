/// <mls fileReference="_100555_/l2/pluginSiteMonitorDashboard/pluginSiteMonitorDashboardRegionalLatency.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { query, property } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/plugins/pluginBaseModule.js';
export const pluginData = {
    title: "Regional Latency",
    getSvg() {
        return svg `
     <svg svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M384 476.1L192 421.2l0-385.3L384 90.8l0 385.3zm32-1.2l0-386.5L543.1 37.5c15.8-6.3 32.9 5.3 32.9 22.3l0 334.8c0 9.8-6 18.6-15.1 22.3L416 474.8zM15.1 95.1L160 37.2l0 386.5L32.9 474.5C17.1 480.8 0 469.2 0 452.2L0 117.4c0-9.8 6-18.6 15.1-22.3z"/></svg>
    `;
    }
};
export class PluginSiteMonitorDashboardRegionalLatency extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-site-monitor-dashboard-regional-latency-100555 {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
}
plugin-site-monitor-dashboard-regional-latency-100555 .plugin-body {
  height: 100%;
  width: 100%;
}
plugin-site-monitor-dashboard-regional-latency-100555 .plugin-body > div {
  height: 100%;
  width: 100%;
}
plugin-site-monitor-dashboard-regional-latency-100555 .plugin-container {
  background-color: #f4f5ff;
  border-radius: 8px;
  padding: 10px 0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  height: 100%;
  width: 100%;
}
plugin-site-monitor-dashboard-regional-latency-100555 header {
  display: flex;
  align-items: center;
  gap: 3rem;
  margin-bottom: 16px;
}
plugin-site-monitor-dashboard-regional-latency-100555 header > div {
  display: flex;
  gap: 0.5rem;
}
plugin-site-monitor-dashboard-regional-latency-100555 icon {
  margin-right: 10px;
}
plugin-site-monitor-dashboard-regional-latency-100555 h2 {
  font-size: 18px;
  font-weight: bold;
  margin: 0;
  color: #333;
}
plugin-site-monitor-dashboard-regional-latency-100555 small {
  color: #888;
  margin-left: auto;
  font-size: 14px;
}
plugin-site-monitor-dashboard-regional-latency-100555 p {
  font-size: 16px;
  color: #555;
}
plugin-site-monitor-dashboard-regional-latency-100555 select {
  border-radius: 13px;
  border: 1px solid #cecece;
  padding: 0.3rem;
  cursor: pointer;
  outline: none;
}
`);
        this.filter = "today";
        this.chartDataBar = {};
        this.autoPrepare = false;
        this.mode = 'simplified';
    }
    async prepare() {
        await import('/_100554_/l2/widgetCollabChart.js');
        this.chartDataBar = {
            "tooltip": {
                "trigger": "axis",
                "axisPointer": {
                    "type": "shadow"
                }
            },
            "xAxis": {
                "type": "category",
                "data": ["North America", "Europe", "Asia", "South America", "Africa", "Australia"]
            },
            "yAxis": {
                "type": "value",
                "name": "Response Time (ms)",
                "axisLabel": {
                    "formatter": "{value} ms"
                }
            },
            "series": [
                {
                    "name": "Latency",
                    "type": "bar",
                    "data": [120, 150, 200, 180, 220, 130],
                    "markPoint": {
                        "data": [
                            { "type": "max", "name": "Max Latency" },
                            { "type": "min", "name": "Min Latency" }
                        ]
                    },
                    "markLine": {
                        "data": [
                            { "type": "average", "name": "Average Latency" }
                        ]
                    },
                    "itemStyle": {
                        "color": "#5470C6"
                    }
                }
            ],
            "grid": {
                "left": "3%",
                "right": "4%",
                "bottom": "3%",
                "containLabel": true
            }
        };
        if (this.mode === 'full') {
            this.chartDataBar.title = {
                text: "Regional Latency (ms)",
            };
            this.chartDataBar.legend = {
                "data": ["Latency"]
            };
        }
        await this.updateComplete;
        const dataBar = JSON.stringify(this.chartDataBar);
        function escapeHTML(str) {
            return str
                .replace(/&/g, "&amp;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");
        }
        if (this.bar)
            this.bar.innerHTML = `<widget-collab-chart-100554 renderer="svg" data="${escapeHTML(dataBar)}"></widget-collab-chart-100554>`;
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
                <select @change=${this.handleChange}>
                    <option value="today">Today</option>
                    <option value="week">Week</option>
                    <option value="mounth">Last 30 days</option>
                    <option value="all">All Time</option>
                </select>
            </header>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body">
            <div class="bar"></div>
            <div class="map"></div>


        </div>`;
    }
    handleChange(e) {
        const target = e.target;
        const value = target.value;
        this.filter = value;
        this.prepare();
    }
}
__decorate([
    property({ type: String })
], PluginSiteMonitorDashboardRegionalLatency.prototype, "filter", void 0);
__decorate([
    property()
], PluginSiteMonitorDashboardRegionalLatency.prototype, "chartDataBar", void 0);
__decorate([
    property({ type: Boolean })
], PluginSiteMonitorDashboardRegionalLatency.prototype, "autoPrepare", void 0);
__decorate([
    property({ type: String })
], PluginSiteMonitorDashboardRegionalLatency.prototype, "mode", void 0);
__decorate([
    query('.plugin-body')
], PluginSiteMonitorDashboardRegionalLatency.prototype, "body", void 0);
__decorate([
    query('.bar')
], PluginSiteMonitorDashboardRegionalLatency.prototype, "bar", void 0);
__decorate([
    query('.map')
], PluginSiteMonitorDashboardRegionalLatency.prototype, "map", void 0);
if (!customElements.get('plugin-site-monitor-dashboard-regional-latency-100555')) {
    customElements.define('plugin-site-monitor-dashboard-regional-latency-100555', PluginSiteMonitorDashboardRegionalLatency);
}
