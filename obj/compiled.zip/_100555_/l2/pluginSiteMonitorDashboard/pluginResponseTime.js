/// <mls fileReference="_100555_/l2/pluginSiteMonitorDashboard/pluginResponseTime.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { query, property, customElement } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
export const pluginData = {
    title: "Response Time",
    getSvg() {
        return svg `
     <svg svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M464 256A208 208 0 1 1 48 256a208 208 0 1 1 416 0zM0 256a256 256 0 1 0 512 0A256 256 0 1 0 0 256zM232 120l0 136c0 8 4 15.5 10.7 20l96 64c11 7.4 25.9 4.4 33.3-6.7s4.4-25.9-6.7-33.3L280 243.2 280 120c0-13.3-10.7-24-24-24s-24 10.7-24 24z"/></svg>
    `;
    }
};
let PluginResponseTime = class PluginResponseTime extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-site-monitor-dashboard--plugin-response-time-100555 {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-default);
  background-color: var(--surface-bg);
}
plugin-site-monitor-dashboard--plugin-response-time-100555 .plugin-body {
  height: 100%;
  width: 100%;
}
plugin-site-monitor-dashboard--plugin-response-time-100555 .plugin-container {
  background-color: #f4f5ff;
  padding: 10px 0;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  height: 100%;
  width: 100%;
}
plugin-site-monitor-dashboard--plugin-response-time-100555 header {
  display: flex;
  align-items: center;
  gap: 3rem;
  margin-bottom: 16px;
}
plugin-site-monitor-dashboard--plugin-response-time-100555 header > div {
  display: flex;
  gap: 0.5rem;
}
plugin-site-monitor-dashboard--plugin-response-time-100555 icon {
  margin-right: 10px;
}
plugin-site-monitor-dashboard--plugin-response-time-100555 h2 {
  font-size: 18px;
  font-weight: bold;
  margin: 0;
  color: #333;
}
plugin-site-monitor-dashboard--plugin-response-time-100555 small {
  color: #888;
  margin-left: auto;
  font-size: 14px;
}
plugin-site-monitor-dashboard--plugin-response-time-100555 p {
  font-size: 16px;
  color: #555;
}
plugin-site-monitor-dashboard--plugin-response-time-100555 select {
  border-radius: 13px;
  border: 1px solid #cecece;
  padding: 0.3rem;
  cursor: pointer;
  outline: none;
}
`);
        this.filter = "today";
        this.chartData = {};
        this.autoPrepare = false;
        this.mode = 'simplified';
    }
    async prepare() {
        const url = '/_100554_/l2/widgetCollabChart.js';
        await import(url);
        this.chartData = {
            "tooltip": {
                "trigger": "axis"
            },
            "xAxis": {
                "type": "category",
                "data": ["2024-09-01", "2024-09-02", "2024-09-03", "2024-09-04", "2024-09-05", "2024-09-06"]
            },
            "yAxis": {
                "type": "value",
                "name": "Response Time (ms)",
                "axisLabel": {
                    "formatter": "{value} ms"
                }
            },
            "series": [
                {
                    "name": "Response Time",
                    "type": "line",
                    "data": [120, 200, 150, 80, 70, 110],
                    "markPoint": {
                        "data": [
                            { "type": "max", "name": "Max" },
                            { "type": "min", "name": "Min" }
                        ]
                    },
                    "markLine": {
                        "data": [{ "type": "average", "name": "Average" }]
                    },
                    "smooth": true
                }
            ],
            "grid": {
                "left": "3%",
                "right": "4%",
                "bottom": "3%",
                "containLabel": true
            }
        };
        if (this.mode === 'full') {
            this.chartData.title = {
                text: "Average Response Time Over Time",
            };
        }
        await this.updateComplete;
        const data = JSON.stringify(this.chartData);
        function escapeHTML(str) {
            return str
                .replace(/&/g, "&amp;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");
        }
        if (this.body)
            this.body.innerHTML = `<widget-collab-chart-100554 renderer="svg" data="${escapeHTML(data)}"></widget-collab-chart-100554>`;
    }
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    createRenderRoot() {
        return this;
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
                <select @change=${this.handleChange}>
                    <option value="today">Today</option>
                    <option value="week">Week</option>
                    <option value="mounth">Last 30 days</option>
                    <option value="all">All Time</option>
                </select>
            </header>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body"></div>`;
    }
    handleChange(e) {
        const target = e.target;
        const value = target.value;
        this.filter = value;
        this.prepare();
    }
};
__decorate([
    property({ type: String })
], PluginResponseTime.prototype, "filter", void 0);
__decorate([
    property()
], PluginResponseTime.prototype, "chartData", void 0);
__decorate([
    property({ type: Boolean })
], PluginResponseTime.prototype, "autoPrepare", void 0);
__decorate([
    property({ type: String })
], PluginResponseTime.prototype, "mode", void 0);
__decorate([
    query('.plugin-body')
], PluginResponseTime.prototype, "body", void 0);
PluginResponseTime = __decorate([
    customElement('plugin-site-monitor-dashboard--plugin-response-time-100555')
], PluginResponseTime);
export { PluginResponseTime };
