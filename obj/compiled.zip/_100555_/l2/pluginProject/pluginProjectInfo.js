/// <mls fileReference="_100555_/l2/pluginProject/pluginProjectInfo.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, query, property, state } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
import { renameProjectInHistory } from '/_102027_/l2/libHistoriesRecents.js';
import { collab_trash, collab_lock, collab_lock_open, collab_arrow_up_long, collab_arrow_down_long, collab_pencil } from '/_100555_/l2/utils/collabIcons.js';
/// **collab_i18n_start**
const message_pt = {
    detailsResume: 'Resumo',
    designSystems: 'Design systems',
    lastModified: 'Última modificação',
    fork: 'Galhos',
    deps: 'Dependências',
    files: 'Arquivos',
    detailsInfo: 'Info',
    name: 'Nome',
    projectDriver: 'Driver',
    projectOrg: 'Organização',
    projectOwner: 'Proprietário',
    projectCreatedAt: 'Criado em',
    projectURL: 'URL do Projeto',
    projectDescription: 'Descrição',
    save: 'Salvar',
    cancel: 'Cancelar',
    edit: 'Editar',
    successSavingDeps: 'Dependências atualizadas',
    successSavingInfo: 'Informações atualizadas',
    errorDepNull: "Informe o ID da dependência.",
    errorDepSame: "Não é permitido adicionar o próprio projeto como dependência.",
    errorDepAlreadyAdded: "Esta dependência já foi adicionada.",
    errorDepInvalid: "Este projeto não existe.",
    btnAddDep: "Adicionar",
    btnOpenDep: "Adicionar nova dependência",
    placeholderDep: "ID da dependência",
    noDeps: "Nenhuma dependência configurada."
};
const message_en = {
    designSystems: 'Design systems',
    lastModified: 'Last Modified',
    detailsResume: 'Resume',
    fork: 'Forks',
    deps: 'Dependencies',
    files: 'Files',
    detailsInfo: 'Info',
    name: 'Name',
    projectDriver: 'Project Driver',
    projectOrg: 'Organization',
    projectOwner: 'Owner',
    projectCreatedAt: 'CreatedAt',
    projectURL: 'Project URL',
    projectDescription: 'Description',
    save: 'Save',
    cancel: 'Cancel',
    edit: 'Edit',
    successSavingDeps: 'Dependencies updated',
    successSavingInfo: 'Information updated',
    errorDepNull: "Please enter the dependency ID.",
    errorDepSame: "You cannot add the project itself as a dependency.",
    errorDepAlreadyAdded: "This dependency has already been added.",
    errorDepInvalid: "This project does not exist.",
    btnAddDep: "Add",
    btnOpenDep: "Add new dependency",
    placeholderDep: "Dependency ID",
    noDeps: "No dependencies configured."
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Project Settings",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>
    `;
    }
};
let PluginProjectInfo = class PluginProjectInfo extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-project--plugin-project-info-100555 {
  font-family: var(--font-family-primary);
  display: block;
  overflow: auto;
  background: var(--surface-bg);
  font-size: var(--font-size-16);
}
plugin-project--plugin-project-info-100555 .saving-ok {
  color: var(--status-success-text);
  font-size: var(--font-size-12);
  display: block;
  margin-top: 0.5rem;
}
plugin-project--plugin-project-info-100555 .saving-error {
  color: var(--status-error-text);
  font-size: var(--font-size-12);
  display: block;
  margin-top: 0.5rem;
}
plugin-project--plugin-project-info-100555 input,
plugin-project--plugin-project-info-100555 select,
plugin-project--plugin-project-info-100555 textarea {
  display: block;
  font-size: 1rem;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  outline: none;
  padding: 0.375rem 0.75rem;
}
plugin-project--plugin-project-info-100555 input:focus,
plugin-project--plugin-project-info-100555 select:focus,
plugin-project--plugin-project-info-100555 textarea:focus {
  border-color: var(--selected-border);
  box-shadow: 0 0 0 0.2rem rgba(24, 144, 255, 0.25);
}
plugin-project--plugin-project-info-100555 input:disabled,
plugin-project--plugin-project-info-100555 select:disabled,
plugin-project--plugin-project-info-100555 textarea:disabled {
  background-color: var(--surface-alt-bg);
  cursor: not-allowed;
  opacity: 0.7;
}
plugin-project--plugin-project-info-100555 textarea {
  resize: vertical;
  min-height: 60px;
}
plugin-project--plugin-project-info-100555 button {
  background-color: var(--button-primary-bg);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--border-subtle);
  display: inline-flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  width: max-content;
  transition: all 0.2s ease;
  padding: 0.5rem 1.25rem;
  color: #ffffff;
  cursor: pointer;
}
plugin-project--plugin-project-info-100555 button:hover {
  background-color: var(--button-primary-bg-hover);
  transform: translateY(-1px);
}
plugin-project--plugin-project-info-100555 button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
  transform: none;
}
plugin-project--plugin-project-info-100555 button .loader {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top: 2px solid #fff;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
plugin-project--plugin-project-info-100555 .btn-secondary {
  background-color: transparent;
  color: var(--text-default);
  border: 1px solid var(--border-default);
  box-shadow: none;
}
plugin-project--plugin-project-info-100555 .btn-secondary:hover {
  background-color: var(--surface-alt-bg);
  transform: translateY(-1px);
}
plugin-project--plugin-project-info-100555 .plugin-body {
  height: 100%;
  width: -webkit-fill-available;
  padding: 1rem;
  overflow: auto;
}
plugin-project--plugin-project-info-100555 .plugin-container {
  padding: 10px 0;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  height: 100%;
  width: 100%;
}
plugin-project--plugin-project-info-100555 header {
  margin-left: 16px;
}
plugin-project--plugin-project-info-100555 header > div {
  display: flex;
  gap: 0.5rem;
}
plugin-project--plugin-project-info-100555 icon {
  margin-right: 10px;
}
plugin-project--plugin-project-info-100555 h2 {
  font-size: 18px;
  font-weight: bold;
  margin: 0;
  color: #333;
}
plugin-project--plugin-project-info-100555 small {
  color: #888;
  margin-left: auto;
  font-size: 14px;
}
plugin-project--plugin-project-info-100555 p {
  font-size: 16px;
  color: #555;
}
plugin-project--plugin-project-info-100555 .details-card {
  margin-top: 1rem;
  border: 1px solid var(--border-subtle);
  padding: 1rem;
  border-radius: 10px;
  position: relative;
}
plugin-project--plugin-project-info-100555 .edit-icon {
  position: absolute;
  top: 1rem;
  right: 1rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 6px;
  background-color: var(--surface-alt-bg);
  opacity: 0.8;
  transition: all 0.2s ease;
}
plugin-project--plugin-project-info-100555 .edit-icon svg {
  width: 14px;
  height: 14px;
  fill: var(--text-default);
}
plugin-project--plugin-project-info-100555 .edit-icon:hover {
  opacity: 1;
  background-color: var(--button-primary-bg);
}
plugin-project--plugin-project-info-100555 .edit-icon:hover svg {
  fill: #fff;
}
plugin-project--plugin-project-info-100555 .header-actions {
  position: absolute;
  top: 1rem;
  right: 1rem;
  display: flex;
  gap: 0.5rem;
  z-index: 1;
}
plugin-project--plugin-project-info-100555 .header-actions button {
  height: 32px;
  padding: 0 0.85rem;
  font-size: var(--font-size-12);
  border-radius: 6px;
}
plugin-project--plugin-project-info-100555 .listInfo {
  list-style: none;
  margin: 0px;
  padding: 0px;
  padding-left: 0.5rem;
  margin-bottom: 2rem;
}
plugin-project--plugin-project-info-100555 .listInfo li {
  padding: 0.5rem 0;
  border-bottom: 1px solid var(--border-subtle);
}
plugin-project--plugin-project-info-100555 .listInfo li:last-child {
  border-bottom: none;
}
plugin-project--plugin-project-info-100555 .listInfo li b {
  color: var(--text-muted);
  font-weight: 600;
}
plugin-project--plugin-project-info-100555 .listInfo ul {
  list-style: none;
}
plugin-project--plugin-project-info-100555 .info-edit-form {
  padding: 0.5rem 0;
  max-width: 100%;
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group {
  margin-bottom: 1.25rem;
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group:last-of-type {
  margin-bottom: 0;
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group label {
  display: block;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: var(--text-default);
  font-size: var(--font-size-12);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group input,
plugin-project--plugin-project-info-100555 .info-edit-form .form-group select,
plugin-project--plugin-project-info-100555 .info-edit-form .form-group textarea {
  width: 100%;
  box-sizing: border-box;
  padding: 0.75rem 1rem;
  font-size: var(--font-size-16);
  border: 1px solid var(--border-subtle);
  border-radius: 8px;
  background-color: #fff;
  transition: all 0.2s ease;
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group input:hover:not(:disabled),
plugin-project--plugin-project-info-100555 .info-edit-form .form-group select:hover:not(:disabled),
plugin-project--plugin-project-info-100555 .info-edit-form .form-group textarea:hover:not(:disabled) {
  border-color: var(--border-default);
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group input:focus,
plugin-project--plugin-project-info-100555 .info-edit-form .form-group select:focus,
plugin-project--plugin-project-info-100555 .info-edit-form .form-group textarea:focus {
  border-color: var(--selected-border);
  box-shadow: 0 0 0 3px rgba(24, 144, 255, 0.15);
  background-color: #fff;
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group input:disabled,
plugin-project--plugin-project-info-100555 .info-edit-form .form-group select:disabled,
plugin-project--plugin-project-info-100555 .info-edit-form .form-group textarea:disabled {
  background-color: var(--surface-alt-bg);
  border-color: var(--border-subtle);
  color: var(--text-muted);
  cursor: not-allowed;
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group input::placeholder,
plugin-project--plugin-project-info-100555 .info-edit-form .form-group select::placeholder,
plugin-project--plugin-project-info-100555 .info-edit-form .form-group textarea::placeholder {
  color: var(--text-muted);
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group textarea {
  min-height: 80px;
  resize: vertical;
  line-height: 1.5;
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group.disabled-field {
  opacity: 0.7;
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-group.disabled-field label {
  color: var(--text-muted);
}
plugin-project--plugin-project-info-100555 .info-edit-form .form-divider {
  border: none;
  border-top: 1px dashed var(--border-subtle);
  margin: 1.5rem 0;
}
plugin-project--plugin-project-info-100555 .info-edit-actions {
  display: flex;
  justify-content: flex-end;
  gap: 0.75rem;
  margin-top: 2rem;
  padding-top: 1.5rem;
  border-top: 1px solid var(--border-subtle);
}
plugin-project--plugin-project-info-100555 .deps-action {
  margin-top: 4rem;
  display: flex;
  justify-content: end;
}
plugin-project--plugin-project-info-100555 .deps-details-list {
  list-style: none;
  padding-inline-start: 0;
}
plugin-project--plugin-project-info-100555 .deps-details-list li.li-add {
  border: none;
  display: flex;
  justify-content: center;
}
plugin-project--plugin-project-info-100555 .deps-details-list li.li-add span {
  text-decoration: underline;
  color: var(--selected-text);
  cursor: pointer;
}
plugin-project--plugin-project-info-100555 .deps-details-list li {
  padding: 0.75rem 1.25rem;
  border: 1px solid var(--border-subtle);
  display: flex;
  justify-content: start;
  align-items: center;
  border-right-width: 0;
  border-left-width: 0;
  border-radius: 0;
  gap: 1rem;
}
plugin-project--plugin-project-info-100555 .deps-details-list li:first-child {
  border-top-width: 0;
}
plugin-project--plugin-project-info-100555 .deps-details-list li .deps-details-tags span {
  display: flex;
  align-items: center;
  padding: 0.2em 0.3em;
  font-size: 75%;
  text-align: center;
  white-space: nowrap;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  color: #fff;
  background-color: #2e6596;
  border-radius: 0.25rem;
}
plugin-project--plugin-project-info-100555 .deps-details-list li .deps-details-tags span svg {
  height: 8px;
  fill: currentColor;
}
plugin-project--plugin-project-info-100555 .deps-details-list li .deps-details-actions {
  display: flex;
  gap: 0.5rem;
  margin-left: auto;
  cursor: pointer;
}
plugin-project--plugin-project-info-100555 .deps-details-list li.dep-added > span:first-child {
  color: var(--status-success-text);
  font-weight: 600;
}
plugin-project--plugin-project-info-100555 .deps-details-list li.dep-removed > span:first-child {
  color: var(--status-error-text);
  font-weight: 600;
}
plugin-project--plugin-project-info-100555 .add-dep-wrapper {
  overflow: hidden;
  max-height: 0;
  opacity: 0;
  transform: translateY(-8px);
  transition: max-height 300ms ease, opacity 200ms ease, transform 200ms ease;
}
plugin-project--plugin-project-info-100555 .add-dep-wrapper.open {
  max-height: 120px;
  opacity: 1;
  transform: translateY(0);
}
plugin-project--plugin-project-info-100555 .add-dep-content {
  display: flex;
  gap: 8px;
  margin-top: 8px;
}
plugin-project--plugin-project-info-100555 .add-dep-content input {
  flex: 1;
}
plugin-project--plugin-project-info-100555 details {
  margin-bottom: 1rem;
}
plugin-project--plugin-project-info-100555 details summary {
  cursor: pointer;
  display: flex;
  align-items: center;
  font-weight: 600;
  color: var(--text-default);
}
plugin-project--plugin-project-info-100555 details > div {
  padding-left: 2rem;
  padding-top: 1rem;
}
@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
`);
        this.msg = messages['en'];
        this.autoPrepare = false;
        this.projectDriver = "GitHub";
        this.deps = [];
        this.isSavingDeps = false;
        this.labelOk = '';
        this.labelError = '';
        this.labelErrorDeps = '';
        this.isAddingDep = false;
        this.newDepId = null;
        this.isEditingDeps = false;
        this.originalDeps = [];
        this.isEditingInfo = false;
        this.isSavingInfo = false;
        this.labelOkInfo = '';
        this.labelErrorInfo = '';
        this.editName = '';
        this.editProjectURL = '';
        this.editProjectDriver = '';
        this.editProjectDescription = '';
    }
    async prepare() {
        await this.init();
    }
    //------COMPONENT------
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.style.display = 'block';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderBody()}
            </div>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body">
            ${this.renderInfo()}
            ${this.renderDependencies()}

        </div>`;
    }
    renderInfo() {
        return html `
            <div class="details-card">
                ${!this.isEditingInfo ? html `
                    <span class="edit-icon" @click=${this.startEditingInfo} title="${this.msg.edit}">
                        ${collab_pencil}
                    </span>
                ` : html `
                    <div class="header-actions">
                        <button class="btn-secondary" @click=${this.cancelEditingInfo}>
                            ${this.msg.cancel}
                        </button>
                        <button
                            ?disabled=${this.isSavingInfo || !this.hasInfoChanges}
                            @click=${this.handleSaveInfo}
                        >
                            ${this.isSavingInfo ? html `<span class="loader"></span>` : this.msg.save}
                        </button>
                    </div>
                `}
                <details open>
                    <summary>${this.msg.detailsInfo}</summary>
                    <div>
                        ${this.isEditingInfo ? this.renderInfoEditMode() : this.renderInfoViewMode()}
                    </div>
                </details>
            </div>
        `;
    }
    renderInfoViewMode() {
        return html `
            <ul class="listInfo">
                <li>
                    <b>${this.msg.name}:</b> 
                    ${this.projectName}
                </li>
                <li>
                    <b>${this.msg.projectOrg}:</b> 
                    ${this.projectOrg}
                </li>
                <li>
                    <b>${this.msg.projectOwner}:</b> 
                    ${this.projectOwner}
                </li>
                <li>
                    <b>${this.msg.projectCreatedAt}:</b> 
                    ${this.projectCreatedAt}
                </li>
                <li style="display:flex">
                    <b>${this.msg.projectDriver}:</b> 
                    ${this.projectDriver}
                </li>
                <li>
                    <b>${this.msg.projectURL}:</b>
                    ${this.projectURL}
                </li>
                <li>
                    <b>${this.msg.projectDescription}:</b>
                    ${this.projectDescription || '-'}
                </li>
            </ul>
        `;
    }
    renderInfoEditMode() {
        return html `
            <div class="info-edit-form">
                <div class="form-group">
                    <label>${this.msg.name}</label>
                    <input 
                        type="text" 
                        .value=${this.editName}
                        @input=${(e) => this.editName = e.target.value}
                        placeholder="Nome do projeto"
                    />
                </div>

                <div class="form-group">
                    <label>${this.msg.projectURL}</label>
                    <input 
                        type="text" 
                        .value=${this.editProjectURL}
                        @input=${(e) => this.editProjectURL = e.target.value}
                        placeholder="https://exemplo.com"
                    />
                </div>

                <div class="form-group">
                    <label>${this.msg.projectDriver}</label>
                    <select 
                        .value=${this.editProjectDriver}
                        @change=${(e) => this.editProjectDriver = e.target.value}
                    >
                        <option value="local">local</option>
                        <option value="mls">mls</option>
                        <option value="GitHub">GitHub</option>
                        <option value="GitLab">GitLab</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>${this.msg.projectDescription}</label>
                    <textarea 
                        rows="4"
                        .value=${this.editProjectDescription}
                        @input=${(e) => this.editProjectDescription = e.target.value}
                        placeholder="Descrição do projeto..."
                    ></textarea>
                </div>

                <hr class="form-divider" />

                <div class="form-group disabled-field">
                    <label>${this.msg.projectOrg}</label>
                    <input type="text" .value=${this.projectOrg || ''} disabled />
                </div>

                <div class="form-group disabled-field">
                    <label>${this.msg.projectOwner}</label>
                    <input type="text" .value=${this.projectOwner || ''} disabled />
                </div>

                <div class="form-group disabled-field">
                    <label>${this.msg.projectCreatedAt}</label>
                    <input type="text" .value=${this.projectCreatedAt || ''} disabled />
                </div>

                ${this.labelOkInfo ? html `<small class="saving-ok">${this.labelOkInfo}</small>` : ''}
                ${this.labelErrorInfo ? html `<small class="saving-error">${this.labelErrorInfo}</small>` : ''}
            </div>
        `;
    }
    renderDependencies() {
        return html `
            <div class="details-card">
                ${!this.isEditingDeps ? html `
                    <span class="edit-icon" @click=${this.startEditingDeps} title="${this.msg.edit}">
                        ${collab_pencil}
                    </span>
                ` : html `
                    <div class="header-actions">
                        <button class="btn-secondary" @click=${this.cancelEditingDeps}>
                            ${this.msg.cancel}
                        </button>
                        <button
                            ?disabled=${this.isSavingDeps || !this.hasDepsChanges}
                            @click=${this.handleSaveDeps}
                        >
                            ${this.isSavingDeps ? html `<span class="loader"></span>` : this.msg.save}
                        </button>
                    </div>
                `}
                <details open>
                    <summary>${this.msg.deps}</summary>
                    <div>
                        ${this.isEditingDeps ? this.renderDepsEditMode() : this.renderDepsViewMode()}
                    </div>
                </details>
            </div>
        `;
    }
    renderDepsViewMode() {
        if (this.deps.length === 0) {
            return html `<p class="no-deps">${this.msg.noDeps}</p>`;
        }
        return html `
            <ul class="deps-details-list view-mode">
                ${this.deps.map((dep) => html `
                    <li>
                        <span>${dep.name} (${dep.id})</span>
                        <div class="deps-details-tags">
                            <span>
                                <i>${dep.auth === 'public' ? collab_lock_open : collab_lock}</i>
                                <span>${dep.auth}</span>
                            </span>
                        </div>
                    </li>
                `)}
            </ul>
        `;
    }
    renderDepsEditMode() {
        return html `
            <ul class="deps-details-list">
                ${this.deps.map((dep, index) => {
            const added = this.isDepAdded(dep);
            const moved = this.isDepMoved(dep);
            const marker = dep.removed ? ' -' : (added || moved) ? ' *' : '';
            const statusClass = dep.removed ? 'dep-removed' : added ? 'dep-added' : '';
            return html `
                    <li class="${statusClass}">
                        <span>${dep.name} (${dep.id})${marker}</span>
                        <div class="deps-details-tags">
                            <span>
                                <i>${dep.auth === 'public' ? collab_lock_open : collab_lock}</i>
                                <span>${dep.auth}</span>
                            </span>
                        </div>
                        <div class="deps-details-actions">
                            ${!dep.removed ? html `
                                <span @click=${() => this.moveDepUp(index)}>${collab_arrow_up_long}</span>
                                <span @click=${() => this.moveDepDown(index)}>${collab_arrow_down_long}</span>
                            ` : ''}
                            <span @click=${() => this.toggleRemoveDependency(index)}>
                                ${collab_trash}
                            </span>
                        </div>
                    </li>
                `;
        })}

                <li class="li-add" @click=${this.toggleAddDep}>
                    <span>${this.msg.btnOpenDep}</span>
                </li>
            </ul>

            <div class="add-dep-wrapper ${this.isAddingDep ? 'open' : ''}">
                <div class="add-dep-content">
                    <input
                        type="number"
                        placeholder=${this.msg.placeholderDep}
                        .value=${this.newDepId ?? ''}
                        @input=${(e) => this.newDepId = Number(e.target.value)}
                    />
                    <button @click=${this.addDependency}>
                        ${this.msg.btnAddDep}
                    </button>
                </div>
                ${this.labelErrorDeps ? html `<small class="saving-error">${this.labelErrorDeps}</small>` : ''}
            </div>

            ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}</small>` : ''}
            ${this.labelError ? html `<small class="saving-error">${this.labelError}</small>` : ''}
        `;
    }
    //-------IMPLEMENTS-----------
    startEditingDeps() {
        this.originalDeps = JSON.parse(JSON.stringify(this.deps));
        this.isEditingDeps = true;
        this.isAddingDep = false;
        this.labelOk = '';
        this.labelError = '';
        this.labelErrorDeps = '';
    }
    cancelEditingDeps() {
        this.deps = JSON.parse(JSON.stringify(this.originalDeps));
        this.isEditingDeps = false;
        this.isAddingDep = false;
        this.labelOk = '';
        this.labelError = '';
        this.labelErrorDeps = '';
    }
    startEditingInfo() {
        this.editName = this.projectName || '';
        this.editProjectURL = this.projectURL || '';
        this.editProjectDriver = this.projectDriver || '';
        this.editProjectDescription = this.projectDescription || '';
        this.isEditingInfo = true;
        this.labelOkInfo = '';
        this.labelErrorInfo = '';
    }
    cancelEditingInfo() {
        this.isEditingInfo = false;
        this.labelOkInfo = '';
        this.labelErrorInfo = '';
    }
    async handleSaveInfo() {
        this.labelErrorInfo = '';
        this.labelOkInfo = '';
        this.isSavingInfo = true;
        try {
            await this.saveInfo();
            this.isSavingInfo = false;
            this.labelOkInfo = this.msg.successSavingInfo;
            this.projectName = this.editName;
            this.projectURL = this.editProjectURL;
            this.projectDriver = this.editProjectDriver;
            this.projectDescription = this.editProjectDescription;
            setTimeout(() => {
                this.isEditingInfo = false;
                this.labelOkInfo = '';
            }, 1500);
        }
        catch (error) {
            console.error('Error on update info:', error);
            this.labelErrorInfo = error.message;
            this.isSavingInfo = false;
        }
    }
    async saveInfo() {
        if (!this.project)
            throw new Error(`Project not found`);
        if (!this.projectDetails)
            throw new Error(`Project details ${this.project} not found`);
        this.projectDetails.name = this.editName;
        if (this.projectSettings) {
            this.projectSettings.projectURL = this.editProjectURL;
            this.projectSettings.projectDriver = this.editProjectDriver;
            this.projectSettings.description = this.editProjectDescription;
            this.projectDetails.value = JSON.stringify(this.projectSettings);
        }
        await mls.api.cbeSavePrjSettings(this.project);
        renameProjectInHistory(this.project, this.projectDetails.name);
    }
    getActiveDeps() {
        return this.deps.filter(dep => !dep.removed);
    }
    isDepAdded(dep) {
        return !this.originalDeps.some(o => o.id === dep.id);
    }
    isDepMoved(dep) {
        if (dep.removed || this.isDepAdded(dep))
            return false;
        const activeDeps = this.getActiveDeps();
        const activeIds = new Set(activeDeps.map(d => d.id));
        // compara apenas contra os itens originais que ainda estão ativos, senão remover
        // um item desloca o índice dos itens seguintes e marca falsamente como "movido"
        const expectedOrder = this.originalDeps.filter(o => activeIds.has(o.id));
        const activeIndex = activeDeps.findIndex(d => d.id === dep.id);
        const expectedIndex = expectedOrder.findIndex(o => o.id === dep.id);
        return activeIndex !== expectedIndex;
    }
    get hasDepsChanges() {
        const activeIds = this.getActiveDeps().map(d => d.id);
        const originalIds = this.originalDeps.map(d => d.id);
        if (activeIds.length !== originalIds.length)
            return true;
        return activeIds.some((id, i) => id !== originalIds[i]);
    }
    get hasInfoChanges() {
        return this.editName !== (this.projectName || '')
            || this.editProjectURL !== (this.projectURL || '')
            || this.editProjectDriver !== (this.projectDriver || '')
            || this.editProjectDescription !== (this.projectDescription || '');
    }
    moveDepUp(index) {
        const deps = [...this.deps];
        let prev = index - 1;
        while (prev >= 0 && deps[prev].removed)
            prev--;
        if (prev < 0)
            return;
        [deps[prev], deps[index]] = [deps[index], deps[prev]];
        this.deps = deps;
    }
    moveDepDown(index) {
        const deps = [...this.deps];
        let next = index + 1;
        while (next < deps.length && deps[next].removed)
            next++;
        if (next >= deps.length)
            return;
        [deps[index], deps[next]] = [deps[next], deps[index]];
        this.deps = deps;
    }
    toggleRemoveDependency(index) {
        const dep = this.deps[index];
        if (!dep.removed && this.isDepAdded(dep)) {
            this.deps = [...this.deps.slice(0, index), ...this.deps.slice(index + 1)];
            return;
        }
        const deps = [...this.deps];
        deps[index] = { ...deps[index], removed: !deps[index].removed };
        this.deps = deps;
    }
    toggleAddDep() {
        this.isAddingDep = !this.isAddingDep;
        if (this.isAddingDep) {
            this.newDepId = null;
            this.labelErrorDeps = '';
        }
    }
    addDependency() {
        if (this.newDepId === null) {
            this.labelErrorDeps = this.msg.errorDepNull;
            return;
        }
        if (this.newDepId === this.project) {
            this.labelErrorDeps = this.msg.errorDepSame;
            return;
        }
        const existingIndex = this.deps.findIndex(dep => dep.id === this.newDepId);
        if (existingIndex !== -1) {
            if (this.deps[existingIndex].removed) {
                const deps = [...this.deps];
                deps[existingIndex] = { ...deps[existingIndex], removed: false };
                this.deps = deps;
                this.newDepId = null;
                this.isAddingDep = false;
                this.labelErrorDeps = '';
                return;
            }
            this.labelErrorDeps = this.msg.errorDepAlreadyAdded;
            return;
        }
        const depDetails = mls.l5.getProjectDetails(this.newDepId);
        if (!depDetails) {
            this.labelErrorDeps = this.msg.errorDepInvalid;
            return;
        }
        this.deps = [
            ...this.deps,
            {
                id: this.newDepId,
                name: depDetails.name,
                auth: depDetails.userAuth
            }
        ];
        this.newDepId = null;
        this.isAddingDep = false;
        this.labelErrorDeps = '';
    }
    async handleSaveDeps() {
        this.labelError = '';
        this.labelOk = '';
        this.isSavingDeps = true;
        try {
            await this.saveDeps();
            this.isSavingDeps = false;
            this.labelOk = `${this.msg.successSavingDeps}`;
            setTimeout(() => {
                this.isEditingDeps = false;
                this.isAddingDep = false;
                this.labelOk = '';
            }, 1500);
        }
        catch (error) {
            console.error('Error on update perfil:', error);
            this.labelError = error.message;
            this.isSavingDeps = false;
        }
    }
    async saveDeps() {
        if (!this.project)
            throw new Error(`Project not found`);
        if (!this.projectDetails)
            throw new Error(`Project details ${this.project} not found`);
        const finalDeps = this.getActiveDeps().map(dep => ({ id: dep.id, name: dep.name, auth: dep.auth }));
        this.projectDetails.prj_dependencies = finalDeps.map(dep => dep.id);
        await this.updateFilesDeps(this.projectDetails.prj_dependencies);
        await mls.api.cbeSavePrjSettings(this.project);
        this.deps = finalDeps;
        this.originalDeps = JSON.parse(JSON.stringify(finalDeps));
    }
    async updateFilesDeps(deps) {
        try {
            if (!mls.actualProject)
                return;
            const sett = mls.l5.getProjectSettings(mls.actualProject || 0);
            const stPck = this.getStor({ project: mls.actualProject, level: 0, folder: '', shortName: 'package', extension: '.json' });
            const stPckLib = this.getStor({ project: mls.actualProject, level: 0, folder: '', shortName: 'packagelib', extension: '.json' });
            const stTs = this.getStor({ project: mls.actualProject, level: 0, folder: '', shortName: 'tsconfig', extension: '.json' });
            const stTsLib = this.getStor({ project: mls.actualProject, level: 0, folder: '', shortName: 'tsconfiglib', extension: '.json' });
            const stConfig = this.getStor({ project: mls.actualProject, level: 0, folder: '', shortName: 'config', extension: '.json' });
            const stDeps = this.getStor({ project: mls.actualProject, level: 0, folder: '', shortName: 'mlsDep', extension: '.json' });
            if (stPck)
                await this.updateFilePck(stPck, deps, sett);
            if (stPckLib)
                await this.updateFilePck(stPckLib, deps, sett);
            if (stTs)
                await this.updateFileTsConfig(stTs, deps);
            if (stTsLib)
                await this.updateFileTsConfig(stTsLib, deps);
            if (stConfig)
                await this.updateFileConfig(stConfig, deps, sett);
            if (stDeps)
                await this.updateFileConfig(stDeps, deps, sett);
        }
        catch (e) {
            console.info(e.message);
        }
    }
    getStor(info) {
        const key = mls.stor.getKeyToFile(info);
        return mls.stor.files[key];
    }
    async updateFilePck(st, deps, sett) {
        try {
            if (!sett?.projectURL)
                return;
            const content = await st.getContent();
            const pkg = JSON.parse(content);
            // actionDependencies is a CI-only field (see scripts/buildCI/resolveDeps.mjs,
            // decision #28): when present it REPLACES `dependencies` for buildCI's closure,
            // so `dependencies` is left untouched here for `npm install`'s own purposes.
            pkg.actionDependencies ?? (pkg.actionDependencies = {});
            const actionDependencies = pkg.actionDependencies;
            const repoBase = sett.projectURL
                .replace(/\/(main|master)\//, "/")
                .replace(/\/?mls-\d+\/?$/, "/");
            const desired = new Set(deps.map(d => `mls-${d}`));
            let changed = false;
            // Remove dependências MLS que não deveriam existir
            for (const key of Object.keys(actionDependencies)) {
                if (key.startsWith("mls-") && !desired.has(key)) {
                    delete actionDependencies[key];
                    changed = true;
                }
            }
            // Adiciona as dependências que faltam
            for (const key of desired) {
                const exists = key in actionDependencies;
                if (!exists && key !== 'mls-100554') {
                    actionDependencies[key] = `git+${repoBase}${key}.git`;
                    changed = true;
                }
            }
            if (changed) {
                const fileInfo = {
                    content: JSON.stringify(pkg, null, 2),
                    contentType: 'string'
                };
                await mls.stor.localStor.setContent(st, fileInfo);
                st.status = 'changed';
                st.inLocalStorage = true;
            }
        }
        catch (e) {
            console.info(`Erro [updateFilePck] file: _${st.project}_/${st.folder ? st.folder + '/' : ''}${st.shortName}${st.extension} | ${e.message || 'Error'}`);
        }
    }
    async updateFileTsConfig(st, deps) {
        var _a;
        try {
            const content = await st.getContent();
            const cfg = JSON.parse(content);
            cfg.compilerOptions ?? (cfg.compilerOptions = {});
            (_a = cfg.compilerOptions).paths ?? (_a.paths = {});
            const paths = cfg.compilerOptions.paths;
            const desired = new Set(deps.map(d => `/_${d}_/*`));
            const currentProjectPath = `/_${mls.actualProject}_/*`;
            let changed = false;
            // Remove apenas os paths das dependências MLS
            for (const key of Object.keys(paths)) {
                if (!/^\/_\d+_\/\*$/.test(key))
                    continue;
                // Nunca remove o path do projeto atual
                if (key === currentProjectPath)
                    continue;
                if (!desired.has(key)) {
                    delete paths[key];
                    changed = true;
                }
            }
            // Adiciona os paths que estão faltando
            for (const dep of deps) {
                const key = `/_${dep}_/*`;
                if (!(key in paths)) {
                    paths[key] = [`./project/mls-${dep}/*`];
                    changed = true;
                }
            }
            if (changed) {
                const fileInfo = {
                    content: JSON.stringify(cfg, null, 2),
                    contentType: 'string'
                };
                await mls.stor.localStor.setContent(st, fileInfo);
                st.status = 'changed';
                st.inLocalStorage = true;
            }
        }
        catch (e) {
            console.info(`Erro [updateFileTsConfig] file: _${st.project}_/${st.folder ? st.folder + '/' : ''}${st.shortName}${st.extension} | ${e.message || 'Error'}`);
        }
    }
    async updateFileConfig(st, deps, sett) {
        try {
            if (!sett?.projectURL)
                return;
            const content = await st.getContent();
            const cfg = JSON.parse(content);
            cfg.workspaceDependencies ?? (cfg.workspaceDependencies = {});
            const workspaceDependencies = cfg.workspaceDependencies;
            const repoBase = sett.projectURL
                .replace(/\/(main|master)\//, "/")
                .replace(/\/?mls-\d+\/?$/, "/");
            const desired = new Set(deps.map(String));
            let changed = false;
            // Remove dependências que não deveriam existir
            for (const key of Object.keys(workspaceDependencies)) {
                if (!desired.has(key)) {
                    delete workspaceDependencies[key];
                    changed = true;
                }
            }
            // Adiciona as que estão faltando
            for (const dep of deps) {
                const key = dep.toString();
                if (!(key in workspaceDependencies)) {
                    workspaceDependencies[key] = {
                        repo: `${repoBase}mls-${dep}.git`,
                        commit: ""
                    };
                    changed = true;
                }
            }
            if (changed) {
                const fileInfo = {
                    content: JSON.stringify(cfg, null, 2),
                    contentType: 'string'
                };
                await mls.stor.localStor.setContent(st, fileInfo);
                st.status = 'changed';
                st.inLocalStorage = true;
            }
        }
        catch (e) {
            console.info(`Erro [updateFileConfig] file: _${st.project}_/${st.folder ? st.folder + '/' : ''}${st.shortName}${st.extension} | ${e.message || 'Error'}`);
        }
    }
    async init() {
        try {
            const project = this.project ? +this.project : mls.actualProject;
            if (!project)
                return;
            this.setInfos(project);
            this.deps = this.getDependencies();
        }
        catch (err) {
            console.info(err);
        }
    }
    getDependencies() {
        const project = this.project ? +this.project : mls.actualProject;
        let deps = [];
        if (project)
            deps = mls.l5.getProjectDependencies(project, false);
        const allDependencies = [];
        deps.forEach((id) => {
            const depPrjDetails = mls.l5.getProjectDetails(id);
            const objDep = {};
            if (depPrjDetails) {
                objDep.name = depPrjDetails.name;
                objDep.id = depPrjDetails.id;
                objDep.auth = depPrjDetails.userAuth;
            }
            else {
                objDep.name = `Unknown - Project don't exists or deleted`;
                objDep.id = id;
                objDep.auth = '';
                objDep.unknown = true;
            }
            allDependencies.push(objDep);
        });
        return allDependencies;
    }
    setInfos(project) {
        this.project = project;
        this.projectSettings = mls.l5.getProjectSettings(project);
        this.projectDetails = mls.l5.getProjectDetails(project);
        if (!this.projectDetails || !this.projectSettings)
            return;
        this.projectName = this.projectDetails.name;
        this.projectDriver = this.projectSettings.projectDriver;
        this.projectCreatedAt = new Date(this.projectDetails.created_at).toLocaleString();
        this.projectOwner = this.projectDetails.owner;
        this.projectDriver = this.projectSettings.projectDriver;
        this.projectURL = this.projectSettings.projectURL;
        this.projectDescription = this.projectSettings.description || '';
        if (mls.l5.actualOrg) {
            this.projectOrg = Object.keys(mls.stor.orgs)[mls.l5.actualOrg];
        }
    }
};
__decorate([
    property({ type: Boolean })
], PluginProjectInfo.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "project", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectName", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectDriver", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectOrg", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectOwner", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectCreatedAt", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectURL", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectDescription", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "forks", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "branches", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "deps", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "isSavingDeps", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "labelOk", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "labelError", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "labelErrorDeps", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "isAddingDep", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "newDepId", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "isEditingDeps", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "originalDeps", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "isEditingInfo", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "isSavingInfo", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "labelOkInfo", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "labelErrorInfo", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "editName", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "editProjectURL", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "editProjectDriver", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "editProjectDescription", void 0);
__decorate([
    query('.plugin-body')
], PluginProjectInfo.prototype, "body", void 0);
PluginProjectInfo = __decorate([
    customElement('plugin-project--plugin-project-info-100555')
], PluginProjectInfo);
export { PluginProjectInfo };
