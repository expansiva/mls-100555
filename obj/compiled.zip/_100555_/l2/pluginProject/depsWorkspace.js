/// <mls fileReference="_100555_/l2/pluginProject/depsWorkspace.ts" enhancement="_blank" />
/**
 * GitHub's repo endpoint: 200 exists, 404 does not. No token and no proxy — the response
 * carries `access-control-allow-origin: *`, so the studio can call it from the browser.
 */
export function gitHubRepoApiUrl(orgName, id) {
    return `https://api.github.com/repos/${orgName}/mls-${id}`;
}
/**
 * Accepted limit: a PRIVATE repository answers 404 without a token and is refused although
 * it exists. Refusing is the safe side — resolveDeps aborts the whole build when a clone
 * fails, so a dependency written but unreachable stops the project from building at all.
 */
export async function projectExistsOnGitHub(orgName, id, fetchImpl) {
    const response = await fetchImpl(gitHubRepoApiUrl(orgName, id));
    return response.status === 200;
}
/**
 * The gate the plugin applies before a dependency enters the list.
 *
 * The old gate refused whatever `mls.l5.getProjectDetails` did not know, which is exactly
 * what made adding a NEW dependency impossible: the host only serves what it already has.
 * A project the host does not know is now checked against GitHub instead of refused.
 */
export async function resolveAddDependency(input) {
    const { newDepId, project, deps, getProjectDetails, orgName, fetchImpl } = input;
    if (newDepId === null)
        return { status: 'errorNull', deps };
    if (newDepId === project)
        return { status: 'errorSame', deps };
    const existingIndex = deps.findIndex(dep => dep.id === newDepId);
    if (existingIndex !== -1) {
        if (!deps[existingIndex].removed)
            return { status: 'errorAlready', deps };
        const restored = [...deps];
        restored[existingIndex] = { ...restored[existingIndex], removed: false };
        return { status: 'restored', deps: restored };
    }
    const depDetails = getProjectDetails(newDepId);
    if (depDetails) {
        return {
            status: 'added',
            deps: [...deps, { id: newDepId, name: depDetails.name, auth: depDetails.userAuth }],
        };
    }
    // The host does not serve it. Ask GitHub before refusing — validating BEFORE the save is
    // the whole point: an id written and only discovered at rebuild time costs the project.
    if (!orgName)
        return { status: 'errorInvalid', deps };
    const exists = await projectExistsOnGitHub(orgName, newDepId, fetchImpl);
    if (!exists)
        return { status: 'errorInvalid', deps };
    // `unknown` is the mark getDependencies() already uses for an id the host cannot resolve.
    return {
        status: 'added',
        deps: [...deps, { id: newDepId, name: `mls-${newDepId}`, auth: '', unknown: true }],
    };
}
/**
 * Rewrites ONLY `workspaceDependencies`, preserving its shape.
 *
 * The array of strings is the real form in l5/config.json, and
 * `projectInit.missingWorkspaceDependencies` requires `Array.isArray(list)` — a project whose
 * list became an object is refused by the host. Treating the array as a key/value map (what
 * updateFileConfig does) writes numeric ids as INDEXES: one dependency turns the file into
 * ~1 MB of `null`.
 *
 * `projects` — the release fecho validated by scripts/validateClientConfig.mjs — is never
 * touched: it is an independent list and already diverges from this one on purpose.
 */
export function applyWorkspaceDependencies(content, deps) {
    const config = JSON.parse(content);
    const trailingNewline = content.endsWith('\n') ? '\n' : '';
    const desired = [];
    for (const dep of deps) {
        const id = String(dep);
        if (!/^\d+$/.test(id))
            continue;
        if (!desired.includes(id))
            desired.push(id);
    }
    const current = config.workspaceDependencies;
    const before = JSON.stringify(current ?? null);
    if (current && !Array.isArray(current) && typeof current === 'object') {
        // The original buildCI object form. Keep the shape — changing it here would be a
        // second, unasked migration; only the key set moves.
        const workspaceDependencies = current;
        for (const key of Object.keys(workspaceDependencies)) {
            if (!desired.includes(key))
                delete workspaceDependencies[key];
        }
        for (const id of desired) {
            if (!(id in workspaceDependencies))
                workspaceDependencies[id] = { repo: '', commit: '' };
        }
    }
    else {
        config.workspaceDependencies = desired;
    }
    const changed = JSON.stringify(config.workspaceDependencies) !== before;
    return { content: `${JSON.stringify(config, null, 2)}${trailingNewline}`, changed };
}
/**
 * Writes the file into the stor and hands it to `setContents`, which is the actual save:
 * DriverVm answers the fork/branch/PR ceremony with `true` without doing anything, so the
 * whole flow exists to reach `setContents` — from there the host writes to disk, commits and
 * calls scheduleRebuildOnSave on its own. Nothing is forced from here.
 *
 * `inLocalStorage = false` is what the driver's readFilePayload counts on, and it is what the
 * serviceSave loop does before saving.
 *
 * @returns whether anything was written — an unchanged file never reaches `setContents`.
 */
export async function saveWorkspaceDependencies(io) {
    const { file, deps, setContent, setContents, message } = io;
    const content = await file.getContent();
    if (typeof content !== 'string')
        return false;
    const { content: next, changed } = applyWorkspaceDependencies(content, deps);
    if (!changed)
        return false;
    await setContent(file, { content: next, contentType: 'string' });
    file.status = 'changed';
    file.inLocalStorage = false;
    await setContents([file], message);
    return true;
}
