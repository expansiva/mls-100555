/// <mls fileReference="_100555_/l2/pluginProject/pluginProjectInfo.test.ts" enhancement="_blank" />
import { mount, cleanup, compare, query, mountAndVerify } from '/_102027_/l2/plugins/pluginTestUtils.js';
import { pluginData } from '/_100555_/l2/pluginProject/pluginProjectInfo.js';
import '/_100555_/l2/pluginProject/pluginProjectInfo.js'; // side-effect import: guarantees this module's top-level registration (e.g. @customElement) always runs, regardless of whether the named imports above survive compilation (TS elides imports used only as types)
const TAG = 'plugin-project--plugin-project-info-100555';
export const tests = [
    // ---- browser: need real DOM/customElements ----
    { functionName: 'testSmoke', env: 'browser', params: [
            { expected: { registered: true, rendered: true } },
        ] },
    { functionName: 'testRenderRespectsScope', env: 'browser', params: [
            { input: { scope: 'dashboard' }, expected: { containerRendered: true } },
            { input: { scope: 'detail' }, expected: { containerRendered: false } },
        ] },
    // `addDependency()` has three early-return guards before it ever touches `mls.l5` —
    // each one is independently observable through `labelErrorDeps`.
    { functionName: 'testAddDependencyGuards', env: 'browser', params: [
            { input: { project: 5, newDepId: null, existingDeps: [] }, expected: { labelErrorDeps: 'Please enter the dependency ID.' } },
            { input: { project: 5, newDepId: 5, existingDeps: [] }, expected: { labelErrorDeps: 'You cannot add the project itself as a dependency.' } },
            { input: { project: 5, newDepId: 7, existingDeps: [{ id: 7, name: 'X', auth: 'public' }] }, expected: { labelErrorDeps: 'This dependency has already been added.' } },
        ] },
    // `moveDepUp`/`moveDepDown` guard the array boundaries (first item can't move up, last can't move down).
    { functionName: 'testMoveDep', env: 'browser', params: [
            { input: { method: 'up', index: 0, ids: [1, 2, 3] }, expected: { ids: [1, 2, 3] } },
            { input: { method: 'up', index: 1, ids: [1, 2, 3] }, expected: { ids: [2, 1, 3] } },
            { input: { method: 'down', index: 2, ids: [1, 2, 3] }, expected: { ids: [1, 2, 3] } },
            { input: { method: 'down', index: 0, ids: [1, 2, 3] }, expected: { ids: [2, 1, 3] } },
        ] },
    // ---- vscode: pure logic, no DOM involved ----
    { functionName: 'testPluginData', env: 'vscode', params: [
            { expected: { title: 'Project Settings', svgHasSvgTag: true } },
        ] },
];
export async function testSmoke(testCase) {
    try {
        const result = await mountAndVerify(TAG, { scope: 'dashboard' });
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testRenderRespectsScope(testCase) {
    try {
        const el = await mount(TAG, { scope: testCase.input.scope });
        const result = { containerRendered: !!query(el, '.plugin-container') };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testAddDependencyGuards(testCase) {
    // `this.msg` is picked from `document.documentElement.lang` at render time, and the expected
    // strings below are the English copy — pin the language for the duration of this test so the
    // assertion doesn't depend on whatever language the real IDE happens to be running in.
    const prevLang = document.documentElement.lang;
    document.documentElement.lang = 'en';
    try {
        const el = await mount(TAG, { scope: 'dashboard', project: testCase.input.project });
        el.deps = testCase.input.existingDeps;
        el.newDepId = testCase.input.newDepId;
        el.addDependency();
        const result = { labelErrorDeps: el.labelErrorDeps };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        document.documentElement.lang = prevLang;
        cleanup();
    }
}
export async function testMoveDep(testCase) {
    try {
        const el = await mount(TAG, { scope: 'dashboard' });
        el.deps = testCase.input.ids.map((id) => ({ id, name: `dep${id}`, auth: 'public' }));
        if (testCase.input.method === 'up') {
            el.moveDepUp(testCase.input.index);
        }
        else {
            el.moveDepDown(testCase.input.index);
        }
        const result = { ids: el.deps.map((d) => d.id) };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testPluginData(testCase) {
    const svg = pluginData.getSvg();
    const svgText = Array.isArray(svg?.strings) ? svg.strings.join('') : String(svg);
    const result = {
        title: pluginData.title,
        svgHasSvgTag: svgText.includes('<svg'),
    };
    compare(result, testCase.expected);
    return JSON.stringify(result);
}
