/// <mls fileReference="_100555_/l2/pluginProject/pluginProjectDetail.test.ts" enhancement="_blank" />
import { mount, cleanup, compare, query, mountAndVerify } from '/_102027_/l2/plugins/pluginTestUtils.js';
import { pluginData } from '/_100555_/l2/pluginProject/pluginProjectDetail.js';
import '/_100555_/l2/pluginProject/pluginProjectInfo.js';
const TAG = 'plugin-project--plugin-project-detail-100555';
const INFO_TAG = 'plugin-project--plugin-project-info-100555';
export const tests = [
    // ---- browser: need real DOM/customElements ----
    { functionName: 'testSmoke', env: 'browser', params: [
            { expected: { registered: true, rendered: true } },
        ] },
    // Unlike its siblings, `render()` here never checks `this.scope` — the "Project" details/summary
    // and the <contentprojectinfo> placeholder are always rendered, even with scope 'detail'.
    { functionName: 'testRendersRegardlessOfScope', env: 'browser', params: [
            { input: { scope: 'dashboard' }, expected: { hasContentProjectInfo: true, hasContentProject: true } },
            { input: { scope: 'detail' }, expected: { hasContentProjectInfo: true, hasContentProject: true } },
        ] },
    // `loadProject()` is a one-shot flow gated by `localStorage.getItem('serviceDetail')`; with no
    // key present it must bail out before touching either placeholder container.
    { functionName: 'testLoadProjectNoServiceDetail', env: 'browser', params: [
            { expected: { infoEmpty: true, projectEmpty: true } },
        ] },
    // With a 'serviceDetail' entry present (pointing at the currently open project, to avoid a real
    // `loadProjectInfoIfNeeded` network call for a different one), it injects the info plugin tag
    // and consumes/removes the localStorage entry (one-shot).
    { functionName: 'testLoadProjectFromServiceDetail', env: 'browser', params: [
            { expected: { infoTagInjected: true, projectContentSet: true, serviceDetailConsumed: true } },
        ] },
    // ---- vscode: pure logic, no DOM involved ----
    { functionName: 'testPluginData', env: 'vscode', params: [
            { expected: { title: 'Project Detail', svgHasSvgTag: true } },
        ] },
];
export async function testSmoke(testCase) {
    try {
        const result = await mountAndVerify(TAG, { scope: 'dashboard' });
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testRendersRegardlessOfScope(testCase) {
    try {
        const el = await mount(TAG, { scope: testCase.input.scope });
        const result = {
            hasContentProjectInfo: !!query(el, 'contentprojectinfo'),
            hasContentProject: !!query(el, 'contentproject'),
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testLoadProjectNoServiceDetail(testCase) {
    const prevValue = localStorage.getItem('serviceDetail');
    localStorage.removeItem('serviceDetail');
    try {
        const el = await mount(TAG);
        await el.loadProject();
        const result = {
            infoEmpty: el.contentprojectinfo?.innerHTML === '',
            projectEmpty: el.contentproject?.innerHTML === '',
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        if (prevValue !== null)
            localStorage.setItem('serviceDetail', prevValue);
        cleanup();
    }
}
export async function testLoadProjectFromServiceDetail(testCase) {
    const prevValue = localStorage.getItem('serviceDetail');
    try {
        const project = mls.actualProject;
        if (!project)
            throw new Error('No active project in the IDE — this test needs one open, same precondition the plugin runner itself relies on.');
        const el = await mount(TAG);
        localStorage.setItem('serviceDetail', JSON.stringify({ prj: project }));
        await el.loadProject();
        const result = {
            infoTagInjected: !!el.contentprojectinfo?.innerHTML.includes(INFO_TAG),
            projectContentSet: !!el.contentproject?.innerHTML,
            serviceDetailConsumed: localStorage.getItem('serviceDetail') === null,
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        localStorage.removeItem('serviceDetail');
        if (prevValue !== null)
            localStorage.setItem('serviceDetail', prevValue);
        cleanup();
    }
}
export async function testPluginData(testCase) {
    const svg = pluginData.getSvg();
    const svgText = Array.isArray(svg?.strings) ? svg.strings.join('') : String(svg);
    const result = {
        title: pluginData.title,
        svgHasSvgTag: svgText.includes('<svg'),
    };
    compare(result, testCase.expected);
    return JSON.stringify(result);
}
