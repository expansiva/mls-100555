/// <mls fileReference="_100555_/l2/pluginNewFile/widgetTextCode.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
let WidgetTextCode = class WidgetTextCode extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-file--widget-text-code-100555 {
  /*
      * Visual Studio 2015 dark style
      * Author: Nicolas LLOBERA <nllobera@gmail.com>
      */
}
plugin-new-file--widget-text-code-100555 pre {
  position: relative;
  white-space: pre-wrap;
  margin: 0;
}
plugin-new-file--widget-text-code-100555 pre select {
  position: absolute;
  top: 62px;
  left: 5px;
  border: none;
  outline: none;
}
plugin-new-file--widget-text-code-100555 pre code.hljs {
  display: block;
  overflow-x: auto;
  padding: 1em;
}
plugin-new-file--widget-text-code-100555 code.hljs {
  padding: 3px 5px;
}
plugin-new-file--widget-text-code-100555 .hljs {
  background: #fff;
  border: 1px solid var(--border-subtle);
  color: #000;
  outline: none;
}
plugin-new-file--widget-text-code-100555 .hljs-keyword,
plugin-new-file--widget-text-code-100555 .hljs-literal,
plugin-new-file--widget-text-code-100555 .hljs-symbol,
plugin-new-file--widget-text-code-100555 .hljs-name {
  color: #569CD6;
}
plugin-new-file--widget-text-code-100555 .hljs-link {
  color: #569CD6;
  text-decoration: underline;
}
plugin-new-file--widget-text-code-100555 .hljs-built_in,
plugin-new-file--widget-text-code-100555 .hljs-type {
  color: #4EC9B0;
}
plugin-new-file--widget-text-code-100555 .hljs-number,
plugin-new-file--widget-text-code-100555 .hljs-class {
  color: #B8D7A3;
}
plugin-new-file--widget-text-code-100555 .hljs-string,
plugin-new-file--widget-text-code-100555 .hljs-meta .hljs-string {
  color: #D69D85;
}
plugin-new-file--widget-text-code-100555 .hljs-regexp,
plugin-new-file--widget-text-code-100555 .hljs-template-tag {
  color: #9A5334;
}
plugin-new-file--widget-text-code-100555 .hljs-subst,
plugin-new-file--widget-text-code-100555 .hljs-function,
plugin-new-file--widget-text-code-100555 .hljs-title,
plugin-new-file--widget-text-code-100555 .hljs-params,
plugin-new-file--widget-text-code-100555 .hljs-formula {
  color: #DCDCDC;
}
plugin-new-file--widget-text-code-100555 .hljs-comment,
plugin-new-file--widget-text-code-100555 .hljs-quote {
  color: #57A64A;
  font-style: italic;
}
plugin-new-file--widget-text-code-100555 .hljs-doctag {
  color: #608B4E;
}
plugin-new-file--widget-text-code-100555 .hljs-meta,
plugin-new-file--widget-text-code-100555 .hljs-meta .hljs-keyword,
plugin-new-file--widget-text-code-100555 .hljs-tag {
  color: #9B9B9B;
}
plugin-new-file--widget-text-code-100555 .hljs-variable,
plugin-new-file--widget-text-code-100555 .hljs-template-variable {
  color: #BD63C5;
}
plugin-new-file--widget-text-code-100555 .hljs-attr,
plugin-new-file--widget-text-code-100555 .hljs-attribute {
  color: #9CDCFE;
}
plugin-new-file--widget-text-code-100555 .hljs-section {
  color: gold;
}
plugin-new-file--widget-text-code-100555 .hljs-emphasis {
  font-style: italic;
}
plugin-new-file--widget-text-code-100555 .hljs-strong {
  font-weight: bold;
}
plugin-new-file--widget-text-code-100555 .hljs-bullet,
plugin-new-file--widget-text-code-100555 .hljs-selector-tag,
plugin-new-file--widget-text-code-100555 .hljs-selector-id,
plugin-new-file--widget-text-code-100555 .hljs-selector-class,
plugin-new-file--widget-text-code-100555 .hljs-selector-attr,
plugin-new-file--widget-text-code-100555 .hljs-selector-pseudo {
  color: #D7BA7D;
}
plugin-new-file--widget-text-code-100555 .hljs-addition {
  background-color: #144212;
  display: inline-block;
  width: 100%;
}
plugin-new-file--widget-text-code-100555 .hljs-deletion {
  background-color: #600;
  display: inline-block;
  width: 100%;
}
plugin-new-file--widget-text-code-100555.hljs {
  /*!
        Theme: Default
        Description: Original highlight.js style
        Author: (c) Ivan Sagalaev <maniac@softwaremaniacs.org>
        Maintainer: @highlightjs/core-team
        Website: https://highlightjs.org/
        License: see project LICENSE
        Touched: 2021
    */
}
plugin-new-file--widget-text-code-100555.hljs pre code.hljs {
  display: block;
  overflow-x: auto;
  padding: 1em;
}
plugin-new-file--widget-text-code-100555.hljs code.hljs {
  padding: 3px 5px;
}
plugin-new-file--widget-text-code-100555.hljs .hljs {
  background: #f3f3f3;
  color: #444;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-comment {
  color: #697070;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-punctuation,
plugin-new-file--widget-text-code-100555.hljs .hljs-tag {
  color: #444a;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-tag .hljs-attr,
plugin-new-file--widget-text-code-100555.hljs .hljs-tag .hljs-name {
  color: #444;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-attribute,
plugin-new-file--widget-text-code-100555.hljs .hljs-doctag,
plugin-new-file--widget-text-code-100555.hljs .hljs-keyword,
plugin-new-file--widget-text-code-100555.hljs .hljs-meta .hljs-keyword,
plugin-new-file--widget-text-code-100555.hljs .hljs-name,
plugin-new-file--widget-text-code-100555.hljs .hljs-selector-tag {
  font-weight: 700;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-deletion,
plugin-new-file--widget-text-code-100555.hljs .hljs-number,
plugin-new-file--widget-text-code-100555.hljs .hljs-quote,
plugin-new-file--widget-text-code-100555.hljs .hljs-selector-class,
plugin-new-file--widget-text-code-100555.hljs .hljs-selector-id,
plugin-new-file--widget-text-code-100555.hljs .hljs-string,
plugin-new-file--widget-text-code-100555.hljs .hljs-template-tag,
plugin-new-file--widget-text-code-100555.hljs .hljs-type {
  color: #800;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-section,
plugin-new-file--widget-text-code-100555.hljs .hljs-title {
  color: #800;
  font-weight: 700;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-link,
plugin-new-file--widget-text-code-100555.hljs .hljs-operator,
plugin-new-file--widget-text-code-100555.hljs .hljs-regexp,
plugin-new-file--widget-text-code-100555.hljs .hljs-selector-attr,
plugin-new-file--widget-text-code-100555.hljs .hljs-selector-pseudo,
plugin-new-file--widget-text-code-100555.hljs .hljs-symbol,
plugin-new-file--widget-text-code-100555.hljs .hljs-template-variable,
plugin-new-file--widget-text-code-100555.hljs .hljs-variable {
  color: #ab5656;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-literal {
  color: #695;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-addition,
plugin-new-file--widget-text-code-100555.hljs .hljs-built_in,
plugin-new-file--widget-text-code-100555.hljs .hljs-bullet,
plugin-new-file--widget-text-code-100555.hljs .hljs-code {
  color: #397300;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-meta {
  color: #1f7199;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-meta .hljs-string {
  color: #38a;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-emphasis {
  font-style: italic;
}
plugin-new-file--widget-text-code-100555.hljs .hljs-strong {
  font-weight: 700;
}
plugin-new-file--widget-text-code-100555.github {
  /*!
    Theme: GitHub
    Description: Light theme as seen on github.com
    Author: github.com
    Maintainer: @Hirse
    Updated: 2021-05-15

    Outdated base version: https://github.com/primer/github-syntax-light
    Current colors taken from GitHub's CSS
    */
}
plugin-new-file--widget-text-code-100555.github pre code.hljs {
  display: block;
  overflow-x: auto;
  padding: 1em;
}
plugin-new-file--widget-text-code-100555.github code.hljs {
  padding: 3px 5px;
}
plugin-new-file--widget-text-code-100555.github .hljs {
  color: #24292e;
  background: #fff;
}
plugin-new-file--widget-text-code-100555.github .hljs-doctag,
plugin-new-file--widget-text-code-100555.github .hljs-keyword,
plugin-new-file--widget-text-code-100555.github .hljs-meta .hljs-keyword,
plugin-new-file--widget-text-code-100555.github .hljs-template-tag,
plugin-new-file--widget-text-code-100555.github .hljs-template-variable,
plugin-new-file--widget-text-code-100555.github .hljs-type,
plugin-new-file--widget-text-code-100555.github .hljs-variable.language_ {
  color: #d73a49;
}
plugin-new-file--widget-text-code-100555.github .hljs-title,
plugin-new-file--widget-text-code-100555.github .hljs-title.class_,
plugin-new-file--widget-text-code-100555.github .hljs-title.class_.inherited__,
plugin-new-file--widget-text-code-100555.github .hljs-title.function_ {
  color: #6f42c1;
}
plugin-new-file--widget-text-code-100555.github .hljs-attr,
plugin-new-file--widget-text-code-100555.github .hljs-attribute,
plugin-new-file--widget-text-code-100555.github .hljs-literal,
plugin-new-file--widget-text-code-100555.github .hljs-meta,
plugin-new-file--widget-text-code-100555.github .hljs-number,
plugin-new-file--widget-text-code-100555.github .hljs-operator,
plugin-new-file--widget-text-code-100555.github .hljs-selector-attr,
plugin-new-file--widget-text-code-100555.github .hljs-selector-class,
plugin-new-file--widget-text-code-100555.github .hljs-selector-id,
plugin-new-file--widget-text-code-100555.github .hljs-variable {
  color: #005cc5;
}
plugin-new-file--widget-text-code-100555.github .hljs-meta .hljs-string,
plugin-new-file--widget-text-code-100555.github .hljs-regexp,
plugin-new-file--widget-text-code-100555.github .hljs-string {
  color: #032f62;
}
plugin-new-file--widget-text-code-100555.github .hljs-built_in,
plugin-new-file--widget-text-code-100555.github .hljs-symbol {
  color: #e36209;
}
plugin-new-file--widget-text-code-100555.github .hljs-code,
plugin-new-file--widget-text-code-100555.github .hljs-comment,
plugin-new-file--widget-text-code-100555.github .hljs-formula {
  color: #6a737d;
}
plugin-new-file--widget-text-code-100555.github .hljs-name,
plugin-new-file--widget-text-code-100555.github .hljs-quote,
plugin-new-file--widget-text-code-100555.github .hljs-selector-pseudo,
plugin-new-file--widget-text-code-100555.github .hljs-selector-tag {
  color: #22863a;
}
plugin-new-file--widget-text-code-100555.github .hljs-subst {
  color: #24292e;
}
plugin-new-file--widget-text-code-100555.github .hljs-section {
  color: #005cc5;
  font-weight: 700;
}
plugin-new-file--widget-text-code-100555.github .hljs-bullet {
  color: #735c0f;
}
plugin-new-file--widget-text-code-100555.github .hljs-emphasis {
  color: #24292e;
  font-style: italic;
}
plugin-new-file--widget-text-code-100555.github .hljs-strong {
  color: #24292e;
  font-weight: 700;
}
plugin-new-file--widget-text-code-100555.github .hljs-addition {
  color: #22863a;
  background-color: #f0fff4;
}
plugin-new-file--widget-text-code-100555.github .hljs-deletion {
  color: #b31d28;
  background-color: #ffeef0;
}
`);
        this.language = 'typescript';
        this.languages = [];
        this.text = '';
    }
    updated(changedProperties) {
        if (changedProperties.has('language')) {
            if (!window.hljsLoaded) {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js';
                script.onload = () => {
                    window.hljsLoaded = true;
                    this.setCode();
                };
                document.head.appendChild(script);
            }
            else {
                this.setCode();
            }
        }
        if (changedProperties.has('text')) {
            if (!this.codeBlock)
                return;
            this.waitForLoadIfNeeded(() => {
                this.setCode();
            });
        }
        if (changedProperties.has('languages')) {
            if (this.select)
                this.select.value = this.language;
        }
    }
    waitForLoadIfNeeded(callback, timeout = 10000, interval = 100) {
        let elapsedTime = 0;
        const checkVariable = () => {
            if (window.hljsLoaded) {
                callback();
            }
            else if (elapsedTime < timeout) {
                elapsedTime += interval;
                setTimeout(checkVariable, interval);
            }
            else {
                console.error(`Error on load highlight.js. please try again`);
            }
        };
        checkVariable();
    }
    unescapeHtml(str) {
        const map = {
            '&lt;': '<',
            '&gt;': '>',
            '&quot;': '"',
            '&#039;': "'",
            '&amp;': '&',
        };
        let result = str;
        let changed = true;
        while (changed) {
            changed = false;
            result = result.replace(/&(lt|gt|quot|#039|amp);/g, (match) => {
                changed = true;
                return map[match] ?? match;
            });
        }
        return result;
    }
    setCode() {
        if (!this.codeBlock)
            return;
        this.codeBlock.innerHTML = '';
        this.codeBlock.removeAttribute('data-highlighted');
        this.codeBlock.classList.add('language-' + this.language);
        const that = this;
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            window.hljs.configure({ ignoreUnescapedHTML: true });
            if (!that.languages || that.languages.length === 0)
                that.languages = window.hljs.listLanguages();
            const res = window.hljs.highlight(this.unescapeHtml(this.text), { language: that.language });
            that.codeBlock.removeAttribute("data-highlighted");
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            that.codeBlock.innerHTML = res.value;
        });
    }
    firstUpdated() {
        this.setCode();
    }
    render() {
        return html `
       <pre>
            <code class="code" spellcheck="false"></code>
       </pre>
    `;
    }
    onChangeText(e) {
        const target = e.target;
        const val = target.textContent;
        const that = this;
        function setCursorToEnd(el) {
            const range = document.createRange();
            const selection = window.getSelection();
            range.selectNodeContents(el);
            range.collapse(false);
            if (!selection)
                return;
            selection.removeAllRanges();
            selection.addRange(range);
        }
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            const res = window.hljs.highlight(val, { language: that.language });
            that.codeBlock.removeAttribute("data-highlighted");
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            that.codeBlock.innerHTML = res.value;
            setCursorToEnd(that.codeBlock);
        });
    }
};
__decorate([
    property({ type: String })
], WidgetTextCode.prototype, "config", void 0);
__decorate([
    property({ type: String, reflect: true, attribute: true })
], WidgetTextCode.prototype, "language", void 0);
__decorate([
    property({ type: Array })
], WidgetTextCode.prototype, "languages", void 0);
__decorate([
    property({ type: String, reflect: true })
], WidgetTextCode.prototype, "text", void 0);
__decorate([
    query('.code')
], WidgetTextCode.prototype, "codeBlock", void 0);
__decorate([
    query('select')
], WidgetTextCode.prototype, "select", void 0);
WidgetTextCode = __decorate([
    customElement('plugin-new-file--widget-text-code-100555')
], WidgetTextCode);
export { WidgetTextCode };
