/// <mls fileReference="_100555_/l2/pluginNewFile/pluginNewFileMd.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getMessageKey } from "/_102029_/l2/collabLitElement.js";
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { createStorFile } from "/_102027_/l2/libStor.js";
import { createModelAnyFile } from "/_102027_/l2/libModel.js";
import '/_100555_/l2/pluginNewFile/widgetTextCode.js';
/// **collab_i18n_start**
const message_pt = {
    title: "Criar um arquivo MD em branco.",
    desc: "Criar um arquivo em branco md.",
    project: "Projeto",
    shortName: "Nome",
    header: "Arquivo em branco",
    btnCreate: 'Criar arquivo',
    loading: 'Criando arquivo...',
    error: 'Nome do arquivo em branco ou invalido'
};
const message_en = {
    title: "Create a MD blank file.",
    desc: "Create a blank file md.",
    project: "Project",
    shortName: "ShortName",
    header: "Blank File",
    btnCreate: 'Create file',
    loading: 'Creating File...',
    error: 'Blank or invalid file name'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
let msg = messages[lang];
export const details = {
    title: msg.title,
    description: msg.desc,
    tags: ["md"],
};
let PluginNewFileMd = class PluginNewFileMd extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-file--plugin-new-file-md-100555 {
  width: 100%;
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
}
plugin-new-file--plugin-new-file-md-100555 plugin-new-file--widget-text-code-100555 {
  font-size: var(--font-size-12);
}
plugin-new-file--plugin-new-file-md-100555 button {
  background-color: var(--active-color);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: #fff;
  cursor: pointer;
}
plugin-new-file--plugin-new-file-md-100555 button:hover {
  background-color: var(--active-color-hover);
}
`);
        this.position = 'left';
        this.loading = false;
        this.service = this.closest('service-detail-100554');
        this.template = ``;
        this.enhancement = `_100554_enhancementLit`;
        this.groupName = `other`;
    }
    getTemplate() {
        const enhancement = '_blank';
        const folder = this.folder ? `${this.folder}/` : '';
        const name = `_${this.project}_/l2/${folder}${this.shortName}.md`;
        return `/// <mls fileReference="${name}" enhancement="${enhancement}"/>\n${this.template}\n`;
    }
    async handleAddFile() {
        if (!this.project || !this.shortName) {
            this.service.setError(msg.error);
            return;
        }
        ;
        this.loading = true;
        const param = {
            project: this.project,
            shortName: this.shortName,
            folder: this.folder || '',
            extension: '.md',
            level: 2,
            source: this.getTemplate(),
            status: 'new'
        };
        try {
            const sf = await createStorFile(param, false, false);
            await createModelAnyFile(sf);
            if (this.service) {
                this.service.openService('_100554_serviceSource', 'left', 2);
                this.service.openService('_100554_serviceUnit', 'left', 2);
            }
            const key = mls.stor.getKeyToFile(sf);
            const options = {
                shortName: undefined,
                project: undefined,
                htmlText: '<plugin-view-file-100554 nameFile="' + key + '"></plugin-view-file-100554>'
            };
            mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
        }
        catch (e) {
            this.loading = false;
        }
    }
    render() {
        return html `
            ${this.loading ?
            html `<div>${msg.loading}</div>`
            :
                html `   
                <div>
                    <h2>${msg.header} </h2>
                    <hr>
                    <div>
                        <span> <b>${msg.project}:</b> ${this.project}</span>
                        <span> <b>${msg.shortName}:</b> ${this.shortName}</span>    
                    </div>
                    <div style="margin-top:1rem;">
                        <button @click=${this.handleAddFile}>${msg.btnCreate}</button>
                    </div>
                    <plugin-new-file--widget-text-code-100555 language="typescript" text="${this.getTemplate()}"></plugin-new-file--widget-text-code-100555>
                </div>`}
        `;
    }
};
__decorate([
    propertyDataSource()
], PluginNewFileMd.prototype, "shortName", void 0);
__decorate([
    propertyDataSource()
], PluginNewFileMd.prototype, "folder", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFileMd.prototype, "project", void 0);
__decorate([
    property()
], PluginNewFileMd.prototype, "position", void 0);
__decorate([
    property()
], PluginNewFileMd.prototype, "loading", void 0);
PluginNewFileMd = __decorate([
    customElement('plugin-new-file--plugin-new-file-md-100555')
], PluginNewFileMd);
export { PluginNewFileMd };
