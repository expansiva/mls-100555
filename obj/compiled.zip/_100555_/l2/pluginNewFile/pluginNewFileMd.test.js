/// <mls fileReference="_100555_/l2/pluginNewFile/pluginNewFileMd.test.ts" enhancement="_blank" />
import { mount, cleanup, compare, mountAndVerify } from '/_102027_/l2/plugins/pluginTestUtils.js';
import '/_100555_/l2/pluginNewFile/pluginNewFileMd.js'; // side-effect import: guarantees this module's top-level registration (e.g. @customElement) always runs, regardless of whether the named imports above survive compilation (TS elides imports used only as types)
const TAG = 'plugin-new-file--plugin-new-file-md-100555';
export const tests = [
    // ---- browser: need real DOM/customElements ----
    { functionName: 'testSmoke', env: 'browser', params: [
            { expected: { registered: true, rendered: true } },
        ] },
    // Same as pluginNewFileBlank: `template` is the empty string, so getTemplate() only ever
    // produces the fileReference header line (here with a `.md` extension instead of `.ts`).
    { functionName: 'testGetTemplateBodyAlwaysEmpty', env: 'browser', params: [
            { input: { project: 100555, shortName: 'myNote' },
                expected: { trimmed: '/// <mls fileReference="_100555_/l2/myNote.md" enhancement="_blank"/>' } },
            { input: { project: 100555, shortName: 'myNote', folder: 'sub' },
                expected: { trimmed: '/// <mls fileReference="_100555_/l2/sub/myNote.md" enhancement="_blank"/>' } },
        ] },
    // handleAddFile() here goes through createStorFile()/createModelAnyFile() instead of
    // createNewFile(), but shares the same missing-service bug: `service` is resolved via
    // `this.closest(...)` in the constructor, before the element is attached anywhere, so it is
    // always null under mount() and the guard throws instead of showing a friendly error.
    { functionName: 'testHandleAddFileGuardThrows', env: 'browser', params: [
            { expected: { threw: true } },
        ] },
];
export async function testSmoke(testCase) {
    try {
        const result = await mountAndVerify(TAG);
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testGetTemplateBodyAlwaysEmpty(testCase) {
    try {
        const el = await mount(TAG, { project: testCase.input.project, shortName: testCase.input.shortName, folder: testCase.input.folder });
        const template = el.getTemplate();
        const result = { trimmed: template.trim() };
        compare(result, testCase.expected);
        return template;
    }
    finally {
        cleanup();
    }
}
export async function testHandleAddFileGuardThrows(testCase) {
    try {
        const el = await mount(TAG);
        let threw = false;
        try {
            await el.handleAddFile();
        }
        catch (e) {
            threw = true;
        }
        const result = { threw };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
