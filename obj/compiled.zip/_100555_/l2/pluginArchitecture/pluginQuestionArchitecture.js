/// <mls fileReference="_100555_/l2/pluginArchitecture/pluginQuestionArchitecture.ts" enhancement="_102027_/l2/enhancementLit" /> 
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
import { loadAgent, executeBeforePrompt } from '/_102027_/l2/aiAgentOrchestration.js';
import { getTemporaryContext } from '/_102027_/l2/aiAgentHelper.js';
import { getThreadByName } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { getUserId, createThread } from '/_102025_/l2/collabMessagesHelper.js';
/// **collab_i18n_start**
const message_pt = {
    asktheArchitect: 'Perguntar ao Arquiteto',
    consulting: 'Consultando...',
    placeHolder: 'Pergunte algo sobre o sistema... Ex: onde se encontra ...?'
};
const message_en = {
    asktheArchitect: 'Ask the Architect',
    consulting: 'Consulting...',
    placeHolder: 'Ask something about the system... For example: where is... located?'
};
const messages = {
    'pt': message_pt,
    'en': message_en
};
/// **collab_i18n_end**
let PluginQuestionArchitecture = class PluginQuestionArchitecture extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-architecture--plugin-question-architecture-100555 {
  display: block;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
  color: var(--text-primary-color);
}
plugin-architecture--plugin-question-architecture-100555 .svg-container {
  width: 22px;
  margin: 4px;
  display: inline-flex;
  fill: var(--text-primary-color);
}
plugin-architecture--plugin-question-architecture-100555 header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 24px;
  border-bottom: 1px solid #ececec;
  padding-bottom: 12px;
}
plugin-architecture--plugin-question-architecture-100555 header span {
  font-size: 20px;
  font-weight: 600;
  margin: 0;
}
plugin-architecture--plugin-question-architecture-100555 icon svg {
  width: 22px;
  height: 22px;
  color: var(--text-primary-color);
  fill: var(--text-primary-color);
}
plugin-architecture--plugin-question-architecture-100555 .agent-box {
  max-width: 820px;
  margin: 10px auto;
  padding: 0.3rem;
  border-radius: 18px;
}
plugin-architecture--plugin-question-architecture-100555 .input-area {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
plugin-architecture--plugin-question-architecture-100555 .input-area textarea {
  flex: 1;
  min-height: 90px;
  resize: vertical;
  padding: 16px 18px;
  border-radius: 14px;
  border: 1px solid #E2E2E2;
  font-size: 14px;
  line-height: 1.6;
  outline: none;
  transition: all 0.2s ease;
  background: #FAFAFA;
}
plugin-architecture--plugin-question-architecture-100555 .input-area textarea:focus {
  border-color: var(--active-color);
  background: #FFFFFF;
  box-shadow: 0 0 0 4px rgba(191, 175, 159, 0.15);
}
plugin-architecture--plugin-question-architecture-100555 .input-area button {
  height: 52px;
  padding: 0 22px;
  border: none;
  width: 200px;
  border-radius: 14px;
  background: var(--active-color);
  color: #FFFFFF;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.2s ease;
  box-shadow: 0 6px 18px rgba(74, 63, 53, 0.25);
}
plugin-architecture--plugin-question-architecture-100555 .input-area button:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 24px rgba(74, 63, 53, 0.35);
}
plugin-architecture--plugin-question-architecture-100555 .input-area button:active {
  transform: translateY(0);
}
plugin-architecture--plugin-question-architecture-100555 .input-area button:disabled {
  transform: translateY(0);
  opacity: 0.5;
  cursor: not-allowed;
  box-shadow: none;
  pointer-events: none;
}
plugin-architecture--plugin-question-architecture-100555 .result-area {
  margin-top: 32px;
}
plugin-architecture--plugin-question-architecture-100555 .result-area h3 {
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.6px;
  text-transform: uppercase;
  color: #7A7A7A;
  margin-bottom: 16px;
}
plugin-architecture--plugin-question-architecture-100555 .result-area ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
plugin-architecture--plugin-question-architecture-100555 .file-item {
  padding: 18px 20px;
  border-radius: 14px;
  border: 1px solid #EAEAEA;
  background: #FBFBFB;
  transition: all 0.2s ease;
  cursor: pointer;
}
plugin-architecture--plugin-question-architecture-100555 .file-item:hover {
  border-color: var(--active-color);
  background: #FFFFFF;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
}
plugin-architecture--plugin-question-architecture-100555 .file-name {
  font-size: 14px;
  font-weight: 600;
  color: #4A3F35;
  margin-bottom: 6px;
  word-break: break-all;
}
plugin-architecture--plugin-question-architecture-100555 .file-desc {
  font-size: 13px;
  line-height: 1.6;
  color: #555555;
}
`);
        this.msg = messages['en'];
        this.question = '';
        this.loading = false;
        this.error = '';
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        const propMode = changedProperties.get('mode');
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        
        <div class="agent-box">
            ${this.renderHeader()}
            <div class="input-area">
                <textarea
                    placeholder="${this.msg.placeHolder}"
                    .value=${this.question}
                    @input=${(e) => this.question = e.target.value}
                ></textarea>

                <button @click=${this.askAgent} ?disabled=${this.loading}>
                    ${this.loading ? this.msg.consulting : this.msg.asktheArchitect}
                </button>
            </div>

            ${this.result ? html `
                <div class="result-area">
                    <h3>Arquivos encontrados</h3>
                    <ul>
                        ${this.result.files.map(f => html `
                            <li class="file-item" @click="${this.openFile}">
                                <div class="file-name">${f.file.replace('.defs', '')}</div>
                                <div class="file-desc">${f.description}</div>
                            </li>
                        `)}
                    </ul>
                </div>
            ` : ''} 
        </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <span class="svg-container">${pluginData.getSvg()}</span>
                <span>${pluginData.title}</span>
            </header>
        `;
    }
    //-------IMPLEMENTATION-------
    async askAgent() {
        if (!this.question.trim())
            return;
        this.loading = true;
        this.result = undefined;
        try {
            const json = await this._callAgent('_100554_/l2/agentArchitectMind.ts', this.question, '');
            if (!json) {
                this.result = undefined;
                return;
            }
            const obj = this.findFlexibleNodes(json);
            if (!obj || obj.length < 1 || !obj[0].result)
                throw new Error("Not found step flexible");
            this.result = obj[0].result;
        }
        catch (err) {
            console.error(err);
        }
        this.loading = false;
    }
    async _callAgent(agentName, message, group) {
        let pageName = mls.actual[mls.actualLevel].getFullName();
        if (!pageName)
            pageName = agentName;
        let thread = await getThreadByName(pageName);
        if (!thread) {
            thread = await createThread(pageName, [], 'company');
        }
        if (!thread)
            return `Agent "${agentName}" error: Not found thread: ${pageName}`;
        const userId = getUserId();
        const threadId = thread.threadId;
        if (!userId)
            return `Agent "${agentName}" error: Not found userID`;
        let context;
        try {
            context = getTemporaryContext(threadId, userId, '@@' + agentName + ' ' + message);
        }
        catch (e) {
            this.error = `[pluginAgentPlayground] [getTemporaryContext] Agent "${agentName}" error: ${e.message}\n\n${JSON.stringify(context, null, 2)}`;
        }
        try {
            const agent = await loadAgent(agentName);
            if (!agent)
                throw new Error('Not found agent:' + agentName);
            await executeBeforePrompt(agent, context);
            return context;
        }
        catch (e) {
            this.error = `[pluginAgentPlayground] Agent "${agentName}" error: ${e.message}\n\n${JSON.stringify(context, null, 2)}`;
            return '';
        }
    }
    findFlexibleNodes(obj) {
        const results = [];
        function walk(node) {
            if (!node || typeof node !== 'object')
                return;
            // Se achou o flexible
            if (node.type === 'flexible') {
                results.push(node);
            }
            // Continua percorrendo tudo
            for (const key in node) {
                walk(node[key]);
            }
        }
        walk(obj);
        return results;
    }
    openFile(e) {
        const el = e.target;
        if (!el)
            return;
        const li = el.closest('li');
        if (!li)
            return;
        const span = li.querySelector('.file-name');
        if (!span)
            return;
        const key = span.innerText;
        const f = mls.stor.files[key];
        if (!f)
            return;
        this.fireEvents('open', f);
    }
    async fireEvents(action, file, timeout = 0) {
        try {
            const params = {};
            await file.getOrCreateModel();
            params.action = action;
            params.level = file.level;
            params.project = file.project;
            params.shortName = file.shortName;
            params.extension = file.extension;
            params.folder = file.folder;
            params.position = 'left';
            if (['open'].includes(action)) {
                let name = `_${file.project}_${file.shortName}`;
                if (file.folder)
                    name = `_${file.project}_${file.folder}/${file.shortName}`;
                mls.actual[2].setFullName(name);
                mls.actual[2]['left'] = file;
            }
            mls.events.fire([mls.actualLevel], ['FileAction'], JSON.stringify(params), timeout);
        }
        catch (err) {
        }
    }
};
__decorate([
    state()
], PluginQuestionArchitecture.prototype, "question", void 0);
__decorate([
    state()
], PluginQuestionArchitecture.prototype, "loading", void 0);
__decorate([
    state()
], PluginQuestionArchitecture.prototype, "result", void 0);
__decorate([
    state()
], PluginQuestionArchitecture.prototype, "error", void 0);
PluginQuestionArchitecture = __decorate([
    customElement('plugin-architecture--plugin-question-architecture-100555')
], PluginQuestionArchitecture);
export { PluginQuestionArchitecture };
export const pluginData = {
    title: "Question architecture",
    getSvg() {
        return svg `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M96 96C78.3 96 64 110.3 64 128C64 145.7 78.3 160 96 160L544 160C561.7 160 576 145.7 576 128C576 110.3 561.7 96 544 96L96 96zM96 480C78.3 480 64 494.3 64 512C64 529.7 78.3 544 96 544L224 544L224 416C224 363 267 320 320 320C373 320 416 363 416 416L416 544L544 544C561.7 544 576 529.7 576 512C576 494.3 561.7 480 544 480L544 208L96 208L96 480z"/></svg>
    `;
    }
};
