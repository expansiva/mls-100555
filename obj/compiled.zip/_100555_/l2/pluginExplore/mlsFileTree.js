/// <mls fileReference="_100555_/l2/pluginExplore/mlsFileTree.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { undoFile, deleteFile, createStorFile } from '/_102027_/l2/libStor.js';
import { getBaseTemplate } from '/_102027_/l2/libCommom.js';
import { createModel } from '/_102027_/l2/libModel.js';
let MlsFileTree = class MlsFileTree extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-explore--mls-file-tree-100555 {
  display: block;
  background: var(--surface-bg);
  color: var(--text-muted-disabled);
  font-family: 'Segoe UI', sans-serif;
  font-size: 13px;
  min-height: 200px;
  user-select: none;
}
plugin-explore--mls-file-tree-100555 .tree-root {
  padding: 4px 0;
}
plugin-explore--mls-file-tree-100555 .tree-item {
  display: flex;
  align-items: center;
  height: 22px;
  padding-left: calc(var(--depth, 0) * 16px + 8px);
  cursor: pointer;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  gap: 4px;
}
plugin-explore--mls-file-tree-100555 .tree-item:hover {
  background: var(--surface-alt-bg-disabled);
}
plugin-explore--mls-file-tree-100555 .tree-item.selected {
  background: var(--button-primary-bg);
  color: #ffffff;
}
plugin-explore--mls-file-tree-100555 .arrow {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  flex-shrink: 0;
  color: #bbbbbb;
  font-size: 10px;
  transition: transform 0.1s;
}
plugin-explore--mls-file-tree-100555 .arrow.open {
  transform: rotate(90deg);
}
plugin-explore--mls-file-tree-100555 .arrow-spacer {
  width: 16px;
  flex-shrink: 0;
}
plugin-explore--mls-file-tree-100555 .icon {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
}
plugin-explore--mls-file-tree-100555 .label {
  overflow: hidden;
  text-overflow: ellipsis;
}
plugin-explore--mls-file-tree-100555 .ext-ts {
  color: #3178c6;
}
plugin-explore--mls-file-tree-100555 .ext-json {
  color: #cbcb41;
}
plugin-explore--mls-file-tree-100555 .ext-js {
  color: #e8c84e;
}
plugin-explore--mls-file-tree-100555 .ext-html {
  color: #e44d26;
}
plugin-explore--mls-file-tree-100555 .ext-css {
  color: #42a5f5;
}
plugin-explore--mls-file-tree-100555 .ext-other {
  color: #cccccc;
}
plugin-explore--mls-file-tree-100555 .test-item {
  padding: 0.5rem;
  cursor: pointer;
  position: relative;
  font-size: 0.95rem;
  z-index: 1;
  padding-left: calc(var(--depth, 0) * 16px + 8px) !important;
}
plugin-explore--mls-file-tree-100555 .test-item svg {
  fill: var(--text-default);
}
plugin-explore--mls-file-tree-100555 .test-item .fileDeleted {
  text-decoration: line-through;
  color: var(--status-error-text);
}
plugin-explore--mls-file-tree-100555 .test-item .elContent {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  user-select: none;
}
plugin-explore--mls-file-tree-100555 .test-item .elContent .spanFileName {
  margin-left: 30px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
plugin-explore--mls-file-tree-100555 .test-item .elContentAux {
  display: flex;
  margin-top: 1.5rem;
  flex-direction: column;
}
plugin-explore--mls-file-tree-100555 .test-item .elContentAux .elContentAux2 {
  display: flex;
  gap: 0.5rem;
}
plugin-explore--mls-file-tree-100555 .test-item .elContentAux input {
  border: 1px solid var(--border-subtle);
  border-radius: 5px;
  padding-left: 0.3rem;
  font-size: 13px;
  outline: none;
  height: 20px;
  z-index: 10;
}
plugin-explore--mls-file-tree-100555 .test-item .elContentAux button {
  border: none;
  border-radius: 5px;
  width: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10;
  cursor: pointer;
  background: none;
}
plugin-explore--mls-file-tree-100555 .test-item .elContentAux button:hover {
  filter: sepia(100%) hue-rotate(190deg) saturate(500%);
}
plugin-explore--mls-file-tree-100555 .test-item .elContentAux .spanPrj {
  position: relative;
}
plugin-explore--mls-file-tree-100555 .test-item .elContentAux .spanPrj::before {
  content: 'New project:';
  position: absolute;
  color: black;
  width: 100px;
  top: -15px;
  left: 0px;
  z-index: 8;
  font-size: 12px;
}
plugin-explore--mls-file-tree-100555 .test-item .elContentAux .spanName {
  position: relative;
}
plugin-explore--mls-file-tree-100555 .test-item .elContentAux .spanName::before {
  content: 'New short name:';
  position: absolute;
  color: black;
  width: 100px;
  top: -15px;
  left: 0px;
  z-index: 8;
  font-size: 12px;
}
plugin-explore--mls-file-tree-100555 .test-item::after {
  content: ' ';
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><path d='M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z' fill='rgb(66,65,65,1)'/></svg>");
  background-repeat: no-repeat;
  width: 12px;
  height: 12px;
  background-position-y: center;
  position: absolute;
  right: 7px;
  top: 10px;
}
plugin-explore--mls-file-tree-100555 .test-item.folder::after {
  background-image: none;
}
plugin-explore--mls-file-tree-100555 .test-item.headerTitle {
  padding: 0.3em 1em;
  list-style-type: none;
  background: #f7f7f7;
  color: #000;
  font-weight: 600;
  cursor: default;
  font-size: 1rem !important;
}
plugin-explore--mls-file-tree-100555 .test-item.headerTitle::after {
  content: "";
  background: none;
}
plugin-explore--mls-file-tree-100555 .test-item:hover:not(.headerTitle) {
  background: var(--border-default);
}
plugin-explore--mls-file-tree-100555 .test-item .classClick {
  position: absolute;
  height: 37px;
  width: 33px;
  display: flex;
  align-items: center;
  justify-content: center;
  left: auto !important;
}
plugin-explore--mls-file-tree-100555 .test-item .groupHiddenListIcon {
  width: 8px;
  height: 21px;
  display: block;
}
plugin-explore--mls-file-tree-100555 .test-item .groupHiddenList {
  padding: 0.3rem;
  transition: all 0.5s;
  cursor: pointer;
  display: none;
  z-index: 9;
  border-top: 1px solid #c4c4c4;
}
plugin-explore--mls-file-tree-100555 .test-item .mls-gpbtnslider-item {
  color: var(--text-default);
}
plugin-explore--mls-file-tree-100555 .test-item .groupHiddenList .mls-gpbtnslider-item {
  display: block;
  transition: 0.5s;
  z-index: 10;
  color: var(--text-default);
  border-bottom: 1px solid #c7c4c4;
  padding: 0.2rem;
  font-size: 13px;
}
plugin-explore--mls-file-tree-100555 .test-item .groupHiddenList .mls-gpbtnslider-item:hover {
  background: #2f2f2f17;
  color: var(--selected-text);
}
plugin-explore--mls-file-tree-100555 .test-item .groupHiddenList.activegpbtnslider {
  display: flex;
  flex-direction: column;
}
plugin-explore--mls-file-tree-100555 .test-item info-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  transition: width 2s;
}
`);
        this.filter = '';
        this.files = {};
        this.expanded = new Set();
        this.selected = '';
        this._loading = false;
        this._loadingMsg = '';
        this.dataDifBaseTemplate = {};
    }
    firstUpdated() {
        this.project = this.project ? this.project : (mls.actualProject || 0).toString();
    }
    render() {
        const src = Object.keys(this.files).length > 0 ? this.files : mls.stor.files ?? {};
        if (Object.keys(src).length === 0) {
            this.files = src;
            return html `
                ${this._renderOverlay()}
                <div style="padding:8px;color:#888">Nenhum arquivo encontrado em mls.stor.files</div>
            `;
        }
        if (this.files !== src)
            this.files = src;
        const content = this.filter
            ? this.renderFiltered(src)
            : html `<ul class="tree-root">${this.buildTree().children.map(c => this.renderNode(c, 0))}</ul>`;
        return html `<div style="position:relative;height:100%">${this._renderOverlay()}${content}</div>`;
    }
    _renderOverlay() {
        if (!this._loading)
            return nothing;
        return html `
            <style>@keyframes mft-spin{100%{transform:rotate(360deg)}}</style>
            <div style="position:absolute;inset:0;background:rgba(0,0,0,.55);z-index:99999;display:flex;align-items:center;justify-content:center">
                <div style="background:var(--surface-alt-bg,#252526);border-radius:10px;padding:1.75rem 2.5rem;display:flex;flex-direction:column;align-items:center;gap:1rem;min-width:240px;box-shadow:0 8px 32px rgba(0,0,0,.6)">
                    <div style="width:38px;height:38px;border:4px solid rgba(255,255,255,.15);border-top-color:#4fa3e0;border-radius:50%;animation:mft-spin .75s linear infinite"></div>
                    <span style="color:var(--text-default,#ccc);font-size:.9rem;text-align:center;white-space:pre-wrap">${this._loadingMsg}</span>
                </div>
            </div>
        `;
    }
    renderFiltered(src) {
        const project = +(this.project || '0');
        const term = this.filter.toLowerCase();
        const matches = Object.values(src)
            .filter(f => f.project === project && (f.shortName.toLowerCase().includes(term) ||
            (f.folder && f.folder.toLowerCase().includes(term)) ||
            (f.extension && f.extension.toLowerCase().includes(term))))
            .sort((a, b) => a.shortName.localeCompare(b.shortName));
        if (matches.length === 0) {
            return html `<div style="padding:8px;color:#888">Sem resultados para "<strong>${this.filter}</strong>"</div>`;
        }
        return html `<ul class="tree-root">${matches.map(file => {
            const key = mls.stor.getKeyToFile(file);
            const fullName = (file.folder ? file.folder + '/' : '') + file.shortName + file.extension;
            const highlighted = this.highlightText(fullName, term);
            return html `
                <li class="test-item ${this.selected === key ? 'selected' : ''}"
                    style="--depth:0"
                    .myFile=${file}
                    @click=${() => this.selectFile(key, file)}>
                    <div class="elContent">
                        <info-item>
                            <span class="spanFileName" .innerHTML="${highlighted}"></span>
                        </info-item>
                    </div>
                </li>
            `;
        })}</ul>`;
    }
    highlightText(text, term) {
        const idx = text.toLowerCase().indexOf(term);
        if (idx < 0)
            return text;
        return (text.slice(0, idx) +
            `<mark style="background:rgba(255,200,0,.4);border-radius:2px;font-weight:600;padding:0 1px">${text.slice(idx, idx + term.length)}</mark>` +
            text.slice(idx + term.length));
    }
    renderNode(node, depth) {
        if (node.isFolder) {
            const isOpen = this.expanded.has(node.fullPath);
            return html `
                <li class="test-item folder" style="--depth: ${depth}" @click=${() => this.toggleFolder(node.fullPath)} >
                    <div class="elContent">
                        <info-item>
                            <span class="arrow ${isOpen ? 'open' : ''}">▶</span>
                            <span class="icon">📁</span>
                            <div style="display:flex; gap:.5rem" .innerHTML="${node.name}"></div>
                        
                        <span style="cursor:pointer;z-index: 99;display: flex; position: absolute; right: 25px;" title="undo all this folder" @click=${(e) => { e.stopPropagation(); e.preventDefault(); this.undoAllByFolders(node); }}><span class="fa fa-undo" style="pointer-events:none;"></span></span>

                        <span style="cursor:pointer;z-index: 99;display: flex; position: absolute; right: 5px;" title="delete all this folder" @click=${(e) => { e.stopPropagation(); e.preventDefault(); this.delAllByFolders(node); }}><svg xmlns="http://www.w3.org/2000/svg" style="width:15px; pointer-events:none;" viewBox="0 0 640 640"><!--!Font Awesome Free v7.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M232.7 69.9L224 96L128 96C110.3 96 96 110.3 96 128C96 145.7 110.3 160 128 160L512 160C529.7 160 544 145.7 544 128C544 110.3 529.7 96 512 96L416 96L407.3 69.9C402.9 56.8 390.7 48 376.9 48L263.1 48C249.3 48 237.1 56.8 232.7 69.9zM512 208L128 208L149.1 531.1C150.7 556.4 171.7 576 197 576L443 576C468.3 576 489.3 556.4 490.9 531.1L512 208z"/></svg></span>
                        </info-item>
                    </div>
                </li>
                ${isOpen ? node.children.map(c => this.renderNode(c, depth + 1)) : nothing}
            `;
        }
        else {
            return this.renderItem(node, depth);
        }
    }
    renderItem(node, depth) {
        const isSelected = this.selected === node.fileKey;
        const file = node.file;
        let auxVersion = '';
        let auxStorage = '';
        let auxBug = '';
        let auxHtml = '';
        const titleLocalStorage = this.getTitleInLocalStorage(file);
        if (titleLocalStorage) {
            auxStorage = `<span title=" ${titleLocalStorage} in localstorage" class="fa fa-location-dot" style="color:lightskyblue; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        if (file.hasError) {
            auxBug = `<span title="bug" class="fa fa-bug" style="color:rgb(169, 3, 3); height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        if (file.isLocalVersionOutdated) {
            auxVersion = `<span title="need conciliation" class="fa fa-unbalanced" style="color:orange; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        return html ` 
                <li  .myFile=${node.file} class="test-item ${isSelected ? 'selected' : ''}" @click=${() => this.selectFile(node.fileKey, node.file)} style="--depth: ${depth}" .nameFilter="${node.file.shortName.toLocaleLowerCase()}">
                    <div class="elContent">
                        <info-item>
                            <span class="classClick" @click="${this.clickGroupHidden}">
                                <span class="groupHiddenListIcon" >
                                    <svg xmlns='http://www.w3.org/2000/svg' style='height: 21px;' viewBox='0 0 128 512' ><path style='fill:var(--text-default)' d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>
                                </span>
                            </span>
                            </span>
                            <span class="spanFileName ${node.file.status === 'deleted' ? 'fileDeleted' : ''}">${node.name}</span>
                            <div style="display:flex; gap:.5rem" .innerHTML="${auxStorage + auxBug + auxVersion + auxHtml}"></div>
                        </info-item>
                        <div class="groupHiddenList">
                            <span class="mls-gpbtnslider-item" title="Undo" @click=${(e) => { e.stopPropagation(); this.undoFile(node.file); }}><span class="fa fa-undo"></span> Undo</span>
                            <span class="mls-gpbtnslider-item" title="Delete" @click=${(e) => { e.stopPropagation(); this.deleteFile(node.file); }}><span class=" fa fa-trash"></span> Delete</span>
                        </div>
                    </div>
                </li>
            `;
    }
    async deleteFile(file) {
        await deleteFile(file);
        this.requestUpdate();
    }
    async undoFile(file) {
        if (!window.confirm(`Undo: ${file.shortName}?`))
            return;
        await undoFile(file);
        this.requestUpdate();
    }
    getTitleInLocalStorage(file) {
        const fileLocal = file && file.inLocalStorage && this.verifyDifBaseTemplate(file);
        return fileLocal ? file.extension : '';
    }
    verifyDifBaseTemplate(file) {
        const { folder, shortName, project, extension } = file;
        const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, extension);
        if (this.dataDifBaseTemplate[key] === undefined)
            return file.inLocalStorage;
        return this.dataDifBaseTemplate[key];
    }
    buildTree() {
        const root = { name: '', fullPath: '', isFolder: true, children: [], file: {} };
        /*const getOrCreateFolder = (parent: TreeNode, name: string, path: string): TreeNode => {
            console.info(parent, name)
            let node = parent.children.find(c => c.isFolder && c.name === name);
            if (!node) {
                node = { name, fullPath: path, isFolder: true, children: [], file: {} as mls.stor.IFileInfo };
                parent.children.push(node);
            }
            return node;
        };*/
        const getOrCreateFolder = (parent, name, path) => {
            const parts = name.split('/');
            let current = parent;
            let currentPath = '';
            for (const part of parts) {
                currentPath = currentPath ? `${currentPath}/${part}` : part;
                let node = current.children.find(c => c.isFolder && c.name === part);
                if (!node) {
                    node = {
                        name: part,
                        fullPath: currentPath,
                        isFolder: true,
                        children: [],
                        file: {}
                    };
                    current.children.push(node);
                }
                current = node;
            }
            return current;
        };
        for (const [key, file] of Object.entries(this.files)) {
            if (file.project !== +(this.project || '0') || isNaN(file.level))
                continue;
            const segments = [];
            if (file.level > 0)
                segments.push(`l${file.level}`);
            if (file.folder)
                segments.push(file.folder);
            let current = root;
            let pathSoFar = '';
            for (const seg of segments) {
                pathSoFar += '/' + seg;
                current = getOrCreateFolder(current, seg, pathSoFar);
            }
            const fileName = file.shortName + file.extension;
            current.children.push({
                name: fileName,
                fullPath: key,
                isFolder: false,
                children: [],
                fileKey: key,
                extension: file.extension,
                file: file
            });
        }
        // sort: folders first, then files, alphabetically
        const sortNode = (node) => {
            node.children.sort((a, b) => {
                if (a.isFolder !== b.isFolder)
                    return a.isFolder ? -1 : 1;
                return a.name.localeCompare(b.name);
            });
            node.children.forEach(sortNode);
        };
        sortNode(root);
        return root;
    }
    toggleFolder(path) {
        const next = new Set(this.expanded);
        next.has(path) ? next.delete(path) : next.add(path);
        this.expanded = next;
    }
    selectFile(key, file) {
        this.selected = key;
        if (['.ts'].includes(file.extension) && [1, 2].includes(file.level) && mls.actualLevel === file.level) {
            this.fireEvents(file);
        }
        else {
            this.fireEventsDetails(file);
        }
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        const father = el.closest('div');
        if (!father)
            return;
        const target = father.querySelector('.groupHiddenList');
        if (!target)
            return;
        target.classList.toggle('activegpbtnslider');
    }
    // Collect all file descendants under a tree node (recurses subfolders).
    // Robust against path-parsing edge cases (level groups, nested folders).
    collectFilesFromNode(node) {
        const out = [];
        const walk = (n) => {
            for (const child of n.children) {
                if (child.isFolder)
                    walk(child);
                else if (child.file)
                    out.push(child.file);
            }
        };
        walk(node);
        return out;
    }
    async delAllByFolders(node) {
        const files = this.collectFilesFromNode(node);
        console.log('[mlsFileTree] delAllByFolders', {
            folder: node.fullPath,
            project: this.project,
            count: files.length,
            files: files.map((f) => `${f.folder ? f.folder + '/' : ''}${f.shortName}${f.extension}`)
        });
        if (files.length === 0)
            return;
        const label = node.fullPath || 'root';
        if (!window.confirm(`delete: ${label} (${files.length})?`))
            return;
        this._loading = true;
        this._loadingMsg = `Deleting ${label}\n0 / ${files.length}`;
        await this.updateComplete;
        try {
            for (let i = 0; i < files.length; i++) {
                if (!files[i])
                    continue;
                this._loadingMsg = `Deleting ${label}\n${i + 1} / ${files.length}`;
                await deleteFile(files[i]);
            }
        }
        finally {
            this._loading = false;
            this._loadingMsg = '';
        }
        this.requestUpdate();
    }
    async undoAllByFolders(node) {
        const files = this.collectFilesFromNode(node);
        if (files.length === 0)
            return;
        const label = node.fullPath || 'root';
        if (!window.confirm(`undo: ${label} (${files.length})?`))
            return;
        this._loading = true;
        this._loadingMsg = `Undoing ${label}\n0 / ${files.length}`;
        await this.updateComplete;
        try {
            for (let i = 0; i < files.length; i++) {
                if (!files[i])
                    continue;
                this._loadingMsg = `Undoing ${label}\n${i + 1} / ${files.length}`;
                await undoFile(files[i]);
            }
        }
        finally {
            this._loading = false;
            this._loadingMsg = '';
        }
        this.requestUpdate();
    }
    getLevel(str) {
        const match = str.match(/\/l(\d+)\//);
        return match ? Number(match[1]) : null;
    }
    clearPath(str) {
        let path = str.replace(/^\/l\d+\//, '/').replace(/\/$/, '');
        if (path.startsWith('/'))
            path = path.replace(/^\/+/, '');
        return path;
    }
    fireEventsDetails(stor) {
        const key = mls.stor.getKeyToFile(stor);
        const options = {
            shortName: undefined,
            project: undefined,
            htmlText: '<plugin-view--plugin-view-file-100555 nameFile="' + key + '"></plugin-view--plugin-view-file-100555>'
        };
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
    }
    async fireEvents(file, timeout = 0) {
        try {
            const params = {};
            //const files = await createAllModels(file, true);
            if ([1, 2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.ts');
            if ([2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.less');
            if ([2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.html');
            params.action = 'open';
            params.level = file.level;
            params.project = file.project;
            params.shortName = file.shortName;
            params.extension = file.extension;
            params.folder = file.folder;
            params.position = this.position;
            const lv = mls.actualLevel;
            let name = `_${file.project}_${file.shortName}`;
            if (file.folder)
                name = `_${file.project}_${file.folder}/${file.shortName}`;
            mls.actual[lv].setFullName(name);
            mls.actual[lv][this.position] = file;
            mls.events.fire([mls.actualLevel], ['FileAction'], JSON.stringify(params), timeout);
        }
        catch (err) {
            console.info(err.message || '[fireEvents]: erro open');
        }
    }
    async createModel(base, ext) {
        if (ext === '.ts') {
            return await createModel(base, true, false);
        }
        const { project, shortName, folder, level } = base;
        const key = mls.stor.getKeyToFiles(project, base.level, shortName, folder, ext);
        let stor = mls.stor.files[key];
        if (!stor) {
            const param = {
                project,
                shortName,
                folder,
                level,
                extension: '.ts',
                source: '',
                status: 'new'
            };
            if (ext === '.less') {
                const templateLess = await getBaseTemplate({ folder, shortName, project, extension: '.less' }, 'enhancementStyle');
                return createStorFile({ ...param, extension: '.less', source: templateLess }, true, true, false);
            }
            if (ext === '.html') {
                const templateHTML = await getBaseTemplate({ folder, shortName, project, extension: '.html' });
                return createStorFile({ ...param, extension: '.html', source: templateHTML }, true, true, false);
            }
        }
        else {
            await createModel(stor, true, false);
        }
    }
};
__decorate([
    property()
], MlsFileTree.prototype, "position", void 0);
__decorate([
    property()
], MlsFileTree.prototype, "project", void 0);
__decorate([
    property()
], MlsFileTree.prototype, "filter", void 0);
__decorate([
    property({ type: Object })
], MlsFileTree.prototype, "files", void 0);
__decorate([
    state()
], MlsFileTree.prototype, "expanded", void 0);
__decorate([
    state()
], MlsFileTree.prototype, "selected", void 0);
__decorate([
    state()
], MlsFileTree.prototype, "_loading", void 0);
__decorate([
    state()
], MlsFileTree.prototype, "_loadingMsg", void 0);
MlsFileTree = __decorate([
    customElement('plugin-explore--mls-file-tree-100555')
], MlsFileTree);
export { MlsFileTree };
