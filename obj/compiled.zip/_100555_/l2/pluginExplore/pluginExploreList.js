/// <mls fileReference="_100555_/l2/pluginExplore/pluginExploreList.ts" enhancement="_102027_/l2/enhancementLit" /> 
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, queryAll, state } from 'lit/decorators.js';
import { selectLevel, forceServiceInstance, getBaseTemplate, getInstanceByFile, saveOpenedFile } from '/_102027_/l2/libCommom.js';
import { cloneAllFiles, deleteAllFiles, renameAllFiles, undoAllFiles, undoFile, createStorFile } from '/_102027_/l2/libStor.js';
import { createAllModels, createModel, readProjectTypescriptAndCompile } from '/_102027_/l2/libModel.js';
import { addInHistory, getHistory } from '/_102027_/l2/libHistoriesRecents.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
import { isNameValid } from '/_102027_/l2/libCommom.js';
import '/_100555_/l2/pluginExplore/collabInputSearch.js';
import '/_100555_/l2/pluginExplore/mlsFileTree2.js';
/// **collab_i18n_start**
const message_pt = {
    updateListVerify: "atualizar lista/verificar",
    update: "atualizar",
    addNewFile: "adicionar novo arquivo",
    filter: "Filtrar",
    localProject: "Todos",
    projectFolder: "Pasta",
    totalFiles: "arquivos totais",
    filesWithErrors: "arquivos com erros",
    filesInLocalStorage: "arquivos no armazenamento local",
    filesChangedOnTheServer: "arquivos alterados no servidor",
    history: "Histórico",
    undo: "desfazer",
    clone: "clonar",
    rename: "renomear",
    delete: "excluir",
    security: 'segurança',
    components: 'Filtrar por Componente',
    others: 'Filtrar por Outros arquivos',
    orderName: 'Ordenar por nome',
    orderFolder: 'Ordenar por pasta',
    allFiles: 'Todos os arquivos',
    root: 'Raiz',
    upFolder: 'Voltar para a pasta anterior',
    filesInFolder: 'arquivos nesta pasta',
    deleteFolder: 'excluir todos os arquivos desta pasta',
    pinTask: 'fixar tarefa',
    pinTaskDesc: 'Escreva aqui sua task',
    pinColor: 'Clique para mudar a cor',
    save: 'Salvar',
    remove: 'Remover',
    cancel: 'Cancelar',
    close: 'Fechar'
};
const message_en = {
    updateListVerify: 'update list/ verify',
    update: 'update',
    addNewFile: 'add new file',
    filter: 'Filter',
    projectFolder: "Folder",
    localProject: 'All',
    totalFiles: 'total files',
    filesWithErrors: 'files with errors',
    filesInLocalStorage: 'file in local storage',
    filesChangedOnTheServer: 'files changed on the server',
    history: 'History',
    undo: 'undo',
    clone: 'clone',
    rename: 'rename',
    delete: "delete",
    security: 'security',
    components: 'Filter by Component',
    others: 'Filter by Other Files',
    orderName: 'Sort by name',
    orderFolder: 'Sort by folder',
    allFiles: 'All files',
    root: 'Root',
    upFolder: 'Back to parent folder',
    filesInFolder: 'files in this folder',
    deleteFolder: 'delete all files in this folder',
    pinTask: 'pin task',
    pinTaskDesc: 'Write your task here',
    pinColor: 'Click to change the color',
    save: 'Save',
    remove: 'Remove',
    cancel: 'Cancel',
    close: 'Close'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "List",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>
    `;
    }
};
let PluginExploreList = class PluginExploreList extends PluginBaseModule {
    async createModels(stor) {
        await createAllModels(stor, true, false, false);
    }
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-explore--plugin-explore-list-100555 {
  overflow-y: auto;
  width: 100%;
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-20);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-default);
  background-color: var(--surface-bg);
}
plugin-explore--plugin-explore-list-100555 .contentServiceList {
  padding: 1rem;
  position: relative;
  background-color: var(--surface-bg);
}
plugin-explore--plugin-explore-list-100555.breakContent .groupInfo,
plugin-explore--plugin-explore-list-100555.breakContent .groupFilter {
  flex-direction: column;
  align-items: baseline !important;
}
plugin-explore--plugin-explore-list-100555.breakContent .groupFilter input[type="text"] {
  width: 90% !important;
}
plugin-explore--plugin-explore-list-100555.breakContent .toolbar {
  flex-direction: column;
  align-items: stretch;
}
plugin-explore--plugin-explore-list-100555.breakContent .toolbar__left,
plugin-explore--plugin-explore-list-100555.breakContent .toolbar__center,
plugin-explore--plugin-explore-list-100555.breakContent .toolbar__right {
  width: 100%;
  justify-content: flex-start;
}
plugin-explore--plugin-explore-list-100555.breakContent .toolbar__search {
  width: 100%;
}
plugin-explore--plugin-explore-list-100555.breakContent .toolbar__center {
  justify-content: flex-start;
  flex-wrap: wrap;
}
plugin-explore--plugin-explore-list-100555 .groupHeader {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 0.1rem;
  border-bottom: 1px solid #e0e0e0;
  margin-bottom: 1rem;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0rem 0rem;
  background-color: var(--surface-bg);
  gap: 1rem;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__left {
  flex: 1;
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__search {
  flex: 1;
  padding: 0.4rem 0.8rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 0.9rem;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__search:focus {
  outline: none;
  box-shadow: 0 0 0 2px rgba(0, 119, 255, 0.2);
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__center {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__radio-group {
  display: flex;
  gap: 0.3rem;
  flex-wrap: wrap;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__radio-group label {
  position: relative;
  /*input[type="radio"]:checked+span {
                        background-color: var(--border-default);
                        color: var(--text-default);
                        border-color: var(--border-default-disabled);
                        font-weight: 600;
                    }*/
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__radio-group label input[type="radio"],
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__radio-group label input[type="checkbox"] {
  display: none;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__radio-group label span {
  display: inline-block;
  padding: 0.3rem 0.6rem;
  border: 1px solid var(--border-subtle);
  border-radius: 4px;
  background: var(--surface-bg);
  cursor: pointer;
  font-size: 0.8rem;
  line-height: 1;
  transition: all 0.2s ease;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__radio-group label span svg {
  fill: var(--text-default);
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__radio-group label span:hover {
  background-color: var(--surface-alt-bg);
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__radio-group label span.checked {
  background-color: var(--border-default);
  color: var(--text-default);
  border-color: var(--border-default-disabled);
  font-weight: 600;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__radio-group select {
  display: inline-block;
  padding: 0.3rem 0.3rem;
  border: 1px solid var(--border-subtle);
  border-radius: 4px;
  background: var(--surface-bg);
  cursor: pointer;
  font-size: 0.8rem;
  line-height: 1;
  transition: all 0.2s ease;
  color: var(--text-default);
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__right {
  display: flex;
  align-items: center;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__add-button {
  padding: 0.4rem 0.6rem;
  font-size: 0.9rem;
  border: none;
  border-radius: 6px;
  background-color: var(--surface-bg-disabled);
  color: var(--text-default);
  cursor: pointer;
  transition: background-color 0.2s ease;
}
plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__add-button:hover {
  background-color: var(--border-default);
}
@media (max-width: 600px) {
  plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar {
    flex-direction: column;
    align-items: stretch;
  }
  plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__left,
  plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__center,
  plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__right {
    width: 100%;
    justify-content: flex-start;
  }
  plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__search {
    width: 100%;
  }
  plugin-explore--plugin-explore-list-100555 .groupHeader .toolbar__center {
    justify-content: flex-start;
    flex-wrap: wrap;
  }
}
plugin-explore--plugin-explore-list-100555 .groupHeader .groupInfo {
  display: flex;
  justify-content: start;
  align-items: center;
  gap: 0.4rem;
  margin-bottom: 1rem;
  color: var(--text-default);
}
plugin-explore--plugin-explore-list-100555 .groupHeader .groupInfo span {
  font-size: 0.78rem;
  display: flex !important;
  justify-content: center;
  align-items: center !important;
  gap: 3px !important;
}
plugin-explore--plugin-explore-list-100555 .classClick {
  position: absolute;
  left: 0px;
  height: 37px;
  width: 33px;
  display: flex;
  align-items: center;
  justify-content: center;
}
plugin-explore--plugin-explore-list-100555 .groupHiddenListIcon {
  width: 8px;
  height: 21px;
  display: block;
}
plugin-explore--plugin-explore-list-100555 .groupHiddenList {
  padding: 0.3rem;
  transition: all 0.5s;
  cursor: pointer;
  display: none;
  z-index: 9;
  border-top: 1px solid #c4c4c4;
}
plugin-explore--plugin-explore-list-100555 .mls-gpbtnslider-item {
  color: var(--text-default);
}
plugin-explore--plugin-explore-list-100555 .groupHiddenList .mls-gpbtnslider-item {
  display: block;
  transition: 0.5s;
  z-index: 10;
  color: var(--text-default);
  border-bottom: 1px solid #c7c4c4;
  padding: 0.2rem;
  font-size: 13px;
}
plugin-explore--plugin-explore-list-100555 .groupHiddenList .mls-gpbtnslider-item:hover {
  background: #2f2f2f17;
  color: var(--selected-text);
}
plugin-explore--plugin-explore-list-100555 .groupHiddenList.activegpbtnslider {
  display: flex;
  flex-direction: column;
}
plugin-explore--plugin-explore-list-100555 info-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  transition: width 2s;
}
plugin-explore--plugin-explore-list-100555 ul {
  display: flex;
  -ms-flex-direction: column;
  flex-direction: column;
  padding-left: 0;
  margin: 0px;
  list-style: none;
}
plugin-explore--plugin-explore-list-100555 ul li.selected {
  background: var(--border-default);
}
plugin-explore--plugin-explore-list-100555 ul li {
  padding: 0.3rem !important;
  cursor: pointer;
  position: relative;
  font-size: 0.95rem;
  z-index: 1;
}
plugin-explore--plugin-explore-list-100555 ul li .fileDeleted {
  text-decoration: line-through;
  color: var(--status-error-text);
}
plugin-explore--plugin-explore-list-100555 ul li .elContent {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  user-select: none;
}
plugin-explore--plugin-explore-list-100555 ul li .elContent .spanFileName {
  margin-left: 30px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
plugin-explore--plugin-explore-list-100555 ul li .elContentAux {
  display: flex;
  margin-top: 1.5rem;
  flex-direction: column;
}
plugin-explore--plugin-explore-list-100555 ul li .elContentAux .elContentAux2 {
  display: flex;
  gap: 0.5rem;
}
plugin-explore--plugin-explore-list-100555 ul li .elContentAux input {
  border: 1px solid var(--border-subtle);
  border-radius: 5px;
  padding-left: 0.3rem;
  font-size: 13px;
  outline: none;
  height: 20px;
  z-index: 10;
}
plugin-explore--plugin-explore-list-100555 ul li .elContentAux button {
  border: none;
  border-radius: 5px;
  width: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10;
  cursor: pointer;
  background: none;
}
plugin-explore--plugin-explore-list-100555 ul li .elContentAux button:hover {
  filter: sepia(100%) hue-rotate(190deg) saturate(500%);
}
plugin-explore--plugin-explore-list-100555 ul li .elContentAux .spanPrj {
  position: relative;
}
plugin-explore--plugin-explore-list-100555 ul li .elContentAux .spanPrj::before {
  content: 'New project:';
  position: absolute;
  color: black;
  width: 100px;
  top: -15px;
  left: 0px;
  z-index: 8;
  font-size: 12px;
}
plugin-explore--plugin-explore-list-100555 ul li .elContentAux .spanName {
  position: relative;
}
plugin-explore--plugin-explore-list-100555 ul li .elContentAux .spanName::before {
  content: 'New short name:';
  position: absolute;
  color: black;
  width: 100px;
  top: -15px;
  left: 0px;
  z-index: 8;
  font-size: 12px;
}
plugin-explore--plugin-explore-list-100555 ul li::after {
  content: ' ';
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><path d='M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z' fill='rgb(66,65,65,1)'/></svg>");
  background-repeat: no-repeat;
  width: 12px;
  height: 12px;
  background-position-y: center;
  position: absolute;
  right: 7px;
  top: 10px;
}
plugin-explore--plugin-explore-list-100555 ul li.headerTitle {
  padding: 0.3em 1em;
  list-style-type: none;
  background: #f7f7f7;
  color: #000;
  font-weight: 600;
  cursor: default;
  font-size: 1rem !important;
  display: flex;
}
plugin-explore--plugin-explore-list-100555 ul li.headerTitle::after {
  content: "";
  background: none;
}
plugin-explore--plugin-explore-list-100555 ul li.folderBreadcrumb {
  flex-wrap: wrap;
  gap: 0.25rem;
}
plugin-explore--plugin-explore-list-100555 ul li.folderBreadcrumb .folderCrumb {
  cursor: pointer;
}
plugin-explore--plugin-explore-list-100555 ul li.folderBreadcrumb .folderCrumb:hover {
  text-decoration: underline;
}
plugin-explore--plugin-explore-list-100555 ul li.fileInFolder .classClick {
  position: static;
  order: 10;
  margin-left: auto;
  flex-shrink: 0;
  width: 24px;
  height: auto;
  align-self: stretch;
}
plugin-explore--plugin-explore-list-100555 ul li.fileInFolder .fileIcon {
  display: flex;
  flex-shrink: 0;
}
plugin-explore--plugin-explore-list-100555 ul li.fileInFolder .fileIcon svg {
  width: 13px;
  fill: #8a8f98;
}
plugin-explore--plugin-explore-list-100555 ul li.fileInFolder .spanFileName {
  margin-left: 4px;
}
plugin-explore--plugin-explore-list-100555 ul li.fileInFolder::after {
  display: none;
}
plugin-explore--plugin-explore-list-100555 ul li.folderItem {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding-right: 25px !important;
  user-select: none;
}
plugin-explore--plugin-explore-list-100555 ul li.folderItem .folderIcon {
  display: flex;
}
plugin-explore--plugin-explore-list-100555 ul li.folderItem .folderIcon svg {
  width: 16px;
  fill: #e8b84a;
}
plugin-explore--plugin-explore-list-100555 ul li.folderItem .folderName {
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
plugin-explore--plugin-explore-list-100555 ul li.folderItem .folderCount {
  font-size: 0.8rem;
  opacity: 0.6;
}
plugin-explore--plugin-explore-list-100555 ul li.folderItem .folderDel {
  display: flex;
  opacity: 0.5;
}
plugin-explore--plugin-explore-list-100555 ul li.folderItem .folderDel svg {
  width: 13px;
  fill: currentColor;
  pointer-events: none;
}
plugin-explore--plugin-explore-list-100555 ul li.folderItem .folderDel:hover {
  opacity: 1;
}
plugin-explore--plugin-explore-list-100555 ul li:hover:not(.headerTitle) {
  background: var(--border-default);
}
`);
        this.myDep = [];
        this.msg = messages['en'];
        this.filterByLevel = {};
        this.autoPrepare = false;
        this.mode = 'list';
        this.refresh = '';
        this.position = 'left';
        this.levelFiles = 2;
        this.project = -1;
        this.projectLabel = '1';
        this.filterProject = -1; // -1: noFilter; 0: all project
        this.modeView = 0; // 0: alphabetical; 1: folder
        this.hiddenFiles = false;
        this.errorAux = '';
        this.files = [];
        this.history = [];
        this.currentFolder = []; // folder navigation path (modeView 1)
        this.pinTasks = [];
        this.pinEditKey = ''; // li whose pin form is open
        this.pinViewKey = ''; // li whose pin task is visible
        this.pinViewDirty = false; // desc changed in the open pin task
        this.pinNewColor = '#e53935'; // color chosen in the add pin form
        this.info = {
            tot: 0,
            version: 0,
            storage: 0,
            error: 0,
        };
        this.filesInLocal = [];
        this.onMLSEvents = async (ev) => {
            if (![1, 2, 3, 4, 5].includes(ev.level) || (ev.type !== 'FileAction'))
                return;
            const fileAction = JSON.parse(ev.desc);
            if (!['statusOrErrorChanged', 'projectListChanged', 'new'].includes(fileAction.action) ||
                fileAction.project === 0)
                return;
            setTimeout(() => {
                this.init();
            }, 1000);
        };
        this.fireEventThisProject = 0;
        this.changeListTimeout = 0;
        //------------ IMPLEMENTS -----------------
        this.extensionLevel = {
            1: '.ts',
            2: '.ts',
            3: '.ts',
            4: '.ts'
        };
        this.levelByLevel = {
            1: 1,
            2: 2,
            3: 2,
            4: 2
        };
        this.inFilter = false;
        this.timeFilterChange = 0;
        this.searchTerm = '';
        this.dataDifBaseTemplate = {};
        this.setEvents();
    }
    async prepare() {
        this.init();
    }
    async showAdd() {
        this.inFilter = false;
        switch (mls.actualLevel) {
            case (1):
                await import('/_100555_/l2/pluginExplore/pluginExploreListAddL1.js');
                this.mode = 'addL1';
                break;
            case (2):
                await import('/_100555_/l2/pluginExplore/pluginExploreListAddL2.js');
                this.mode = 'addL2';
                break;
            case (3):
                await import('/_100555_/l2/pluginExplore/pluginExploreListAddL3.js');
                this.mode = 'addL3';
                break;
            case (4):
                await import('/_100555_/l2/pluginExplore/pluginExploreListAddL4.js');
                this.mode = 'addL4';
                break;
        }
    }
    //--------EVENTS----------
    setEvents() {
        mls.events.addEventListener([2, 5], ['ProjectSelected'], (ev) => {
            if (this.project === mls.actualProject)
                return;
            this.init();
        });
        mls.events.addListener(5, 'FileAction', (ev) => {
            if ((ev.type !== 'FileAction'))
                return;
            // if (this.visible === undefined || this.visible === null || (this.visible && this.visible === 'false')) return;
            const fileAction = JSON.parse(ev.desc);
            if (!['projectListChanged'].includes(fileAction.action))
                return;
            this.init();
        });
        mls.events.addListener(2, 'FileAction', this.onMLSEvents.bind(this));
        mls.events.addListener(2, 'styleChanged', (ev) => {
            this.changeList();
        });
        mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ['ToolBarSelected'], (ev) => this.onlevelChange(ev));
    }
    onlevelChange(ev) {
        this.changeList();
        this.showLoading(false);
    }
    //---------COMPONENT-------------
    connectedCallback() {
        super.connectedCallback();
        this.initObserverResize();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
        forceServiceInstance(2, '_100554_serviceSource');
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        const propMode = changedProperties.get('mode');
        if (propMode && this.mode === 'list') {
            this.init();
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        switch (this.mode) {
            case ('list'):
                return this.renderModeList();
            case ('addL1'):
                return this.renderAddL1();
            case ('addL2'):
                return this.renderAddL2();
            case ('addL3'):
                return this.renderAddL3();
            case ('addL4'):
                return this.renderAddL4();
        }
    }
    renderModeList() {
        return html `
            <div class="contentServiceList scroll-custom">
                ${this.renderHeader()}
                <ul>
                    ${this.renderHistory()}
                    ${this.modeView === 1 ? this.renderFolder() : this.renderList()}
                </ul>
            </div>
        `;
    }
    renderHeader() {
        let auxV = '';
        let auxE = '';
        let auxS = '';
        if (this.info.version > 0) {
            auxV = `<b>[${this.info.version}]</b> <span class="fa fa-unbalanced"></span> <b>${this.msg.filesChangedOnTheServer}, </b>`;
        }
        if (this.info.error > 0) {
            auxE = `<b>[${this.info.error}]</b> <span class="fa fa-bug"></span><b>${this.msg.filesWithErrors},</b>`;
        }
        if (this.info.storage > 0) {
            auxS = `<b>[${this.info.storage}]</b> <span class="fa fa-location-dot"></span> <b>${this.msg.filesInLocalStorage}.</b>`;
        }
        return html `
        <div class="groupHeader">
            <header class="toolbar"> 
                <div class="toolbar__left">
                    <plugin-explore--collab-input-search-100555 @input="${this.filterLiChange}"> </plugin-explore--collab-input-search-100555>
                    <div class="toolbar__radio-group">
                        <select @change=${this.changeSelectProject} .value="${this.filterProject}">
                            ${this.myDep.map((p) => html `<option value="${p}" ?selected=${this.filterProject === p}>${p}</option>`)}
                            <option value="0">${this.msg.localProject}</option>
                        </select>
                        <select @change=${this.changeHiddenFiles} .value="${this.modeFilter}">
                            <option value="comp">${this.msg.components}</option>
                            <option value="other">${this.msg.others}</option>
                            <option value="all">${this.msg.allFiles}</option>
                        </select>
                        <select @change=${this.changeModeOrder} .value="${this.modeView}">
                            <option value="0">${this.msg.orderName}</option>
                            <option value="1">${this.msg.orderFolder}</option>
                        </select>

                        <button class="toolbar__add-button" title="new file" @click="${this.showAdd}">+</button>
                        
                    </div>

                </div>

                <div class="toolbar__center">
                    
                </div>
            </header>
            <div class="groupInfo">
                <span style="margin-right:10px">
                    [${this.info.tot}]
				    <span class="fa fa-file"></span> 
                    ${this.msg.totalFiles}
                </span>
                ${auxV ? html `<span .innerHTML="${auxV}" style="margin-right:10px"></span>` : ''}
                ${auxE ? html `<span .innerHTML="${auxE}" style="margin-right:10px"></span>` : ''}
                ${auxS ? html `<span .innerHTML="${auxS}" style="margin-right:10px"></span>` : ''}
            </div>
        </div>
        `;
    }
    renderHistory() {
        if (this.modeFilter === 'all' && this.filterProject > 0) {
            return html ``;
        }
        return html `
            ${this.history.length <= 0 ? '' :
            html `
                    <li class="headerTitle">
                        ${+this.filterProject === 0 ? `${this.msg.history} (All Projects)` : `${this.msg.history}`}
                    </li>
                    ${repeat(this.history, ((item) => 'h_' + item.project + '_' + item.shortName + '_' + item.folder), ((file, index) => this.renderLiItem(file, index, true)))}
                `}
        `;
    }
    renderList() {
        if (this.modeFilter === 'all' && this.filterProject > 0) {
            return html `<plugin-explore--mls-file-tree2-100555 project="${this.filterProject}" position="${this.position}" filter="${this.searchTerm}"></plugin-explore--mls-file-tree2-100555>`;
        }
        let letterInit = '';
        return html `
            ${this.files.length <= 0 ? '' :
            html `
                    ${repeat(this.files, ((item) => item.project + '_' + item.shortName + '_' + item.folder), ((file, index) => {
                if (letterInit !== file.shortName.charAt(0).toUpperCase()) {
                    letterInit = file.shortName.charAt(0).toUpperCase();
                    return html `
                                    <li class="headerTitle">${letterInit} </li>
                                    ${this.renderLiItem(file, index, false)}
                                `;
                }
                return this.renderLiItem(file, index, false);
            }))}
                `}
        `;
    }
    renderFolder() {
        if (this.files.length <= 0)
            return html ``;
        const entries = this.files.map((file) => ({ file, path: this.getFolderPath(file) }));
        // if the current folder no longer exists (delete, rename, filter change), fall back to the nearest existing parent
        let cur = this.currentFolder;
        while (cur.length > 0 && !entries.some((e) => this.isInFolder(e.path, cur)))
            cur = cur.slice(0, -1);
        const subFolders = {};
        const filesHere = [];
        entries.forEach(({ file, path }) => {
            if (!this.isInFolder(path, cur))
                return;
            if (path.length === cur.length) {
                filesHere.push(file);
                return;
            }
            const name = path[cur.length];
            if (subFolders[name])
                subFolders[name].push(file);
            else
                subFolders[name] = [file];
        });
        const folderNames = Object.keys(subFolders).sort((a, b) => a.localeCompare(b));
        filesHere.sort((a, b) => a.shortName.localeCompare(b.shortName));
        return html `
            <li class="headerTitle folder folderBreadcrumb">
                <span class="folderCrumb" @click=${() => this.openFolder([])}>${this.msg.root}</span>
                ${cur.map((seg, i) => html `<span>/</span><span class="folderCrumb" @click=${() => this.openFolder(cur.slice(0, i + 1))}>${seg}</span>`)}
            </li>
            ${cur.length <= 0 ? '' : html `
                <li class="folder folderItem" title="${this.msg.upFolder}" @click=${() => this.openFolder(cur.slice(0, -1))}>
                    <span class="folderIcon">${this.folderSvg()}</span>
                    <span class="folderName">..</span>
                </li>
            `}
            ${repeat(folderNames, ((item) => 'f_' + item), ((name) => html `
                <li class="folder folderItem" @click=${() => this.openFolder([...cur, name])}>
                    <span class="folderIcon">${this.folderSvg()}</span>
                    <span class="folderName">${name}</span>
                    <span class="folderCount" title="${this.msg.filesInFolder}">${subFolders[name].length}</span>
                    <span class="folderDel" title="${this.msg.deleteFolder}" @click=${(e) => { e.stopPropagation(); e.preventDefault(); this.delAllByFolders(subFolders[name], [...cur, name].join('/')); }}><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M232.7 69.9L224 96L128 96C110.3 96 96 110.3 96 128C96 145.7 110.3 160 128 160L512 160C529.7 160 544 145.7 544 128C544 110.3 529.7 96 512 96L416 96L407.3 69.9C402.9 56.8 390.7 48 376.9 48L263.1 48C249.3 48 237.1 56.8 232.7 69.9zM512 208L128 208L149.1 531.1C150.7 556.4 171.7 576 197 576L443 576C468.3 576 489.3 556.4 490.9 531.1L512 208z"/></svg></span>
                </li>
            `))}
            ${repeat(filesHere, ((item) => item.project + '_' + item.shortName + '_' + item.folder), ((file, index) => this.renderLiItem(file, index, false)))}
        `;
    }
    folderSvg() {
        return html `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 480H448c35.3 0 64-28.7 64-64V160c0-35.3-28.7-64-64-64H288c-10.1 0-19.6-4.7-25.6-12.8L243.2 57.6C231.1 41.5 212.1 32 192 32H64C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64z"/></svg>`;
    }
    fileSvg() {
        return html `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M0 64C0 28.7 28.7 0 64 0H224V128c0 17.7 14.3 32 32 32H384V448c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V64zm384 64H256V0L384 128z"/></svg>`;
    }
    getFolderPath(file) {
        const segs = file.folder ? file.folder.split('/').filter((s) => s) : [];
        return this.filterProject === 0 ? [file.project.toString(), ...segs] : segs;
    }
    isInFolder(path, folder) {
        return folder.every((seg, i) => path[i] === seg);
    }
    async openFolder(path) {
        this.currentFolder = path;
        this.closeAllMenus();
        await this.updateComplete;
        if (this.inFilter)
            this.applyLiFilter();
    }
    getTitleInLocalStorage(ts, html, less, test, defs) {
        const tsLocal = ts && ts.inLocalStorage && this.verifyDifBaseTemplate(ts);
        const htmlLocal = html && html.inLocalStorage && this.verifyDifBaseTemplate(html);
        const styleLocal = less && less.inLocalStorage && this.verifyDifBaseTemplate(less);
        const testLocal = test && test.inLocalStorage && this.verifyDifBaseTemplate(test);
        const defsLocal = defs && defs.inLocalStorage && this.verifyDifBaseTemplate(defs);
        let rc = '';
        if (tsLocal)
            rc = rc + '.ts ';
        if (htmlLocal)
            rc = rc + '.html ';
        if (styleLocal)
            rc = rc + '.less ';
        if (testLocal)
            rc = rc + '.test.ts ';
        if (defsLocal)
            rc = rc + '.defs.ts ';
        return rc;
    }
    renderLiItem(file, index, inHistory) {
        const name = this.getAllName(file, inHistory);
        const nameFilter = inHistory
            ? '*******'
            : `${file.folder ? file.folder + '/' : ''}${file.shortName}${file.extension}`.toLocaleLowerCase();
        let auxVersion = '';
        let auxStorage = '';
        let auxBug = '';
        let auxHtml = '';
        const keyHtml = mls.stor.getKeyToFiles(file.project, file.level, file.shortName, file.folder, '.html');
        const keyStyle = mls.stor.getKeyToFiles(file.project, file.level, file.shortName, file.folder, '.less');
        const keyTest = mls.stor.getKeyToFiles(file.project, file.level, file.shortName, file.folder, '.test.ts');
        const defsTest = mls.stor.getKeyToFiles(file.project, file.level, file.shortName, file.folder, '.defs.ts');
        const styleFile = mls.stor.files[keyStyle];
        const htmlFile = mls.stor.files[keyHtml];
        const testFile = mls.stor.files[keyTest];
        const defsFile = mls.stor.files[defsTest];
        const htmlError = htmlFile && htmlFile.hasError;
        const styleError = styleFile && styleFile.hasError;
        const testError = testFile && testFile.hasError;
        const defsError = defsFile && defsFile.hasError;
        const titleLocalStorage = this.getTitleInLocalStorage(file, htmlFile, styleFile, testFile, defsFile);
        if (titleLocalStorage) {
            auxStorage = `<span title=" ${titleLocalStorage} in localstorage" class="fa fa-location-dot" style="color:lightskyblue; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        if (file.hasError || styleError || htmlError || testError || defsError) {
            auxBug = `<span title="bug" class="fa fa-bug" style="color:rgb(169, 3, 3); height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        if (file.isLocalVersionOutdated) {
            auxVersion = `<span title="need conciliation" class="fa fa-unbalanced" style="color:orange; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        const style = this.inFilter && inHistory ? 'display:none' : '';
        const actualL2 = mls.actual[2][this.position]?.shortName;
        const actualL2Folder = mls.actual[2][this.position]?.folder;
        const validProject = this.filterProject === 0 && mls.actualProject !== file.project && file.project !== 0 ? false : true;
        let auxValidProject = '';
        const inFolderView = this.modeView === 1 && !inHistory;
        const liClass = (file.shortName === actualL2 && file.folder === actualL2Folder ? 'selected' : '') + (inFolderView ? ' fileInFolder' : '');
        const pin = this.pinTasks.find((p) => this.isSamePin(p, file));
        const keyPin = (inHistory ? 'h_' : '') + file.project + '_' + file.folder + '_' + file.shortName;
        return html `
            <li @click="${this.clickOptOpen}" class="${liClass}" style="${style}${auxValidProject}" .myFile=${file} .nameFilter="${nameFilter}" ?disabled=${!validProject}>
                <div class="elContent">
                    <info-item>
                        ${inFolderView ? html `<span class="fileIcon">${this.fileSvg()}</span>` : ''}
                        <span class="classClick" @click="${this.clickGroupHidden}">
                           <span class="groupHiddenListIcon" >
                               <svg xmlns='http://www.w3.org/2000/svg' style='height: 21px;' viewBox='0 0 128 512' ><path style='fill:var(--text-default)' d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>
                           </span>
                       </span>
                        </span>
                        <span class="spanFileName ${file.status === 'deleted' ? 'fileDeleted' : ''}">${name}</span>
                        <div style="display:flex; gap:.5rem" .innerHTML="${auxStorage + auxBug + auxVersion + auxHtml}"></div>
                        ${pin ? html `<span class="pinTaskIcon" title="${pin.desc.length > 50 ? pin.desc.slice(0, 50) + '...' : pin.desc}" style="display:flex; align-items:center; cursor:pointer" @click=${(e) => this.clickPinIcon(e, keyPin)}>${this.pinSvg(pin.color)}</span>` : ''}
                    </info-item>
                    ${pin && this.pinViewKey === keyPin ? this.renderPinView(file, pin) : ''}
                    ${!pin && this.pinEditKey === keyPin ? this.renderPinForm(file) : ''}
                    <div class="groupHiddenList" @click=${(e) => e.stopPropagation()}>
                        <span class="mls-gpbtnslider-item" title="${this.msg.undo}" @click="${this.clickOptUndo}"><span class="fa fa-undo"></span> Undo</span>
                        <span class="mls-gpbtnslider-item" title="${this.msg.clone}" @click="${this.clickOptClone}" style="display:${this.hiddenFiles ? 'none' : ''}"><span class=" fa fa-clone"></span> Clone</span>
                        <span class="mls-gpbtnslider-item" title="${this.msg.rename}" @click="${this.clickOptRename}" style="display:${this.hiddenFiles ? 'none' : ''}"><span class=" fa fa-file-pen"></span> Rename</span>
                        <span class="mls-gpbtnslider-item" title="${this.msg.delete}" @click="${this.clickOptDel}"><span class=" fa fa-trash"></span> Delete</span>
                        <span class="mls-gpbtnslider-item" title="${this.msg.security}" @click="${this.clickOptOpenSecurity}" style="display:${this.hiddenFiles ? 'none' : ''}"><span class=" fa-solid fa-shield-halved"></span> Security</span>
                        <span class="mls-gpbtnslider-item" title="${this.msg.pinTask}" @click=${(e) => this.clickOptPinTask(e, keyPin, pin)}><span class=" fa fa-thumbtack"></span> PinTask</span>
                    </div>
                    
                </div>
            </li>
        `;
    }
    renderPinForm(file) {
        const textColor = this.getContrastColor(this.pinNewColor);
        return html `
            <div class="pinTaskForm" style="margin:.25rem 0; border:1px solid ${this.pinNewColor}; border-radius:4px; overflow:hidden" @click=${(e) => e.stopPropagation()}>
                <div class="pinTaskHeader" style="display:flex; align-items:center; gap:.5rem; padding:.25rem .5rem; background:${this.pinNewColor}; color:${textColor}">
                    <div title="${this.msg.pinColor}" style="flex:1; position:relative; display:flex; align-items:center; gap:.5rem; cursor:pointer">
                        <span class="fa fa-palette"></span>
                        <span>PinTask</span>
                        <input type="color" .value=${this.pinNewColor} style="position:absolute; inset:0; width:100%; height:100%; opacity:0; cursor:pointer; border:0; padding:0" @input=${(e) => { this.pinNewColor = e.target.value; }}>
                    </div>
                    <span class="fa fa-xmark" title="${this.msg.cancel}" style="cursor:pointer" @click=${() => { this.pinEditKey = ''; }}></span>
                </div>
                <div style="display:flex; flex-direction:column; gap:.25rem; padding:.5rem">
                    <textarea class="pinTaskDesc" rows="3" placeholder="${this.msg.pinTaskDesc}" style="resize:vertical; width:100%; box-sizing:border-box"></textarea>
                    <button style="align-self:flex-end" @click=${(e) => this.clickPinSave(e, file)}>${this.msg.save}</button>
                </div>
            </div>
        `;
    }
    renderPinView(file, pin) {
        const textColor = this.getContrastColor(pin.color);
        return html `
            <div class="pinTaskView" style="margin:.25rem 0; border:1px solid ${pin.color}; border-radius:4px; overflow:hidden" @click=${(e) => e.stopPropagation()}>
                <div class="pinTaskHeader" style="display:flex; align-items:center; gap:.5rem; padding:.25rem .5rem; background:${pin.color}; color:${textColor}">
                    <span style="flex:1">PinTask</span>
                    <span class="fa fa-trash" title="${this.msg.remove}" style="cursor:pointer" @click=${() => this.clickPinRemove(file)}></span>
                    <span class="fa fa-xmark" title="${this.msg.close}" style="cursor:pointer" @click=${() => { this.pinViewKey = ''; this.pinViewDirty = false; }}></span>
                </div>
                <div style="display:flex; flex-direction:column; gap:.25rem; padding:.5rem">
                    <textarea class="pinTaskViewDesc" rows="3" style="resize:vertical; width:100%; box-sizing:border-box" .value=${pin.desc} @input=${(e) => { this.pinViewDirty = e.target.value.trim() !== pin.desc; }}></textarea>
                    ${this.pinViewDirty ? html `<button style="align-self:flex-end" @click=${(e) => this.clickPinViewSave(e, file, pin)}>${this.msg.save}</button>` : ''}
                </div>
            </div>
        `;
    }
    getContrastColor(hex) {
        const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex);
        if (!m)
            return '#000';
        const [r, g, b] = [m[1], m[2], m[3]].map((c) => parseInt(c, 16));
        return (r * 299 + g * 587 + b * 114) / 1000 > 140 ? '#000' : '#fff';
    }
    pinSvg(color) {
        return html `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" style="height:14px; fill:${color}"><path d="M32 32C32 14.3 46.3 0 64 0L320 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-29.5 0 11.4 148.2c36.7 19.9 65.7 53.2 79.5 94.7l1 3c3.3 9.8 1.6 20.5-4.4 28.8s-15.7 13.3-26 13.3L32 352c-10.3 0-19.9-4.9-26-13.3s-7.7-19.1-4.4-28.8l1-3c13.8-41.5 42.8-74.8 79.5-94.7L93.5 64 64 64C46.3 64 32 49.7 32 32zM160 384l64 0 0 96c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-96z"/></svg>`;
    }
    renderAddL1() {
        return html `<plugin-explore--plugin-explore-list-add-l1-100555 autoprepare='ss' position="${this.position}" .father="${this}" .service="${this.service}" level="1"></plugin-explore--plugin-explore-list-add-l1-100555>`;
    }
    renderAddL2() {
        return html `<plugin-explore--plugin-explore-list-add-l2-100555 level="${this.levelFiles}" position="${this.position}" .father="${this}"></plugin-explore--plugin-explore-list-add-l2-100555>`;
    }
    renderAddL3() {
        return html `<plugin-explore--plugin-explore-list-add-l3-100555 autoprepare='ss' position="${this.position}" .father="${this}" .service="${this.service}"></plugin-explore--plugin-explore-list-add-l3-100555>`;
    }
    renderAddL4() {
        return html `<plugin-explore--plugin-explore-list-add-l4-100555 autoprepare='ss' position="${this.position}" .father="${this}" .service="${this.service}"></plugin-explore--plugin-explore-list-add-l4-100555>`;
    }
    //------------ ACTIONS -----------------
    getAllName(file, isHistory = false) {
        let name = '';
        const folder = file.folder ? file.folder : '';
        if (this.modeView === 0 && this.filterProject === 0) {
            name = '_' + file.project + '_' + folder + '/' + file.shortName;
        }
        else if (this.modeView === 0 && this.filterProject === mls.actualProject) {
            name = folder ? folder + '/' + file.shortName : file.shortName;
        }
        else if (this.filterProject !== mls.actualProject) {
            name = file.project + '_' + (folder ? folder + '/' + file.shortName : file.shortName);
        }
        else {
            name = file.shortName;
        }
        if (this.modeView === 1 && !isHistory)
            name = file.shortName; // the folder is already shown by the navigation
        if (isHistory && folder)
            name = folder + '/' + file.shortName;
        if (isHistory && this.filterProject === 0)
            name = file.project + '_' + folder + '/' + file.shortName;
        if (this.modeFilter === 'other')
            name = name + file.extension;
        return name;
    }
    showLoading(show) {
        if (this.service)
            this.service.loading = show;
    }
    showError(error) {
        if (this.service)
            this.service.setError(error);
    }
    closeAllMenus() {
        const all = this.querySelectorAll('.activegpbtnslider');
        Array.from(all).forEach((i) => i.classList.remove('activegpbtnslider'));
    }
    async clickOptUndo(e) {
        try {
            e.stopPropagation();
            const mfile = this.getMyFileInElement(e.target);
            if (!mfile)
                return;
            if (['project', 'designSystem'].includes(mfile.shortName) && mfile.folder === '' && mfile.status === 'new') {
                throw new Error(`This action cannot be performed on this file at this time.`);
            }
            if (!window.confirm(`${this.msg.undo}: ${mfile.shortName}?`))
                return;
            if (this.hiddenFiles) {
                await undoFile(mfile);
            }
            else
                await undoAllFiles(mfile);
            this.closeAllMenus();
            this.changeList();
        }
        catch (err) {
            this.showError(err.message);
        }
    }
    async clickOptDel(e) {
        try {
            e.stopPropagation();
            const mfile = this.getMyFileInElement(e.target);
            if (!mfile)
                throw new Error('[clickOptDel] Not found file');
            if (['project', 'designSystem'].includes(mfile.shortName) && mfile.folder === '') {
                throw new Error(`The file ${mfile.shortName} cannot be deleted.`);
            }
            if (this.hiddenFiles) {
                mfile.status = 'deleted';
            }
            else
                await deleteAllFiles(mfile);
            this.closeAllMenus();
            this.changeList();
        }
        catch (err) {
            this.showError(err.message);
        }
    }
    async clickOptOpen(e) {
        e.stopPropagation();
        const target = e.target;
        const li = target.closest('li');
        if (li && li.querySelector('*[contenteditable]'))
            return;
        this.lis?.forEach((l) => l.classList.remove('selected'));
        if (li)
            li.classList.add('selected');
        const mfile = this.getMyFileInElement(e.target);
        if (!mfile)
            return;
        if (this.hiddenFiles) {
            this.fireEventsDetails(mfile);
            return;
        }
        addInHistory(mfile);
        this.fireEvents('open', mfile, {});
    }
    async clickOptOpenSecurity(e) {
        e.stopPropagation();
        const target = e.target;
        const li = target.closest('li');
        this.lis?.forEach((l) => l.classList.remove('selected'));
        if (li)
            li.classList.add('selected');
        const mfile = this.getMyFileInElement(e.target);
        if (!mfile)
            return;
        addInHistory(mfile);
        if (mls.actualLevel != 1)
            selectLevel(2);
        window.securityMode = true;
        this.fireEvents('open', mfile, {});
        this.closeAllMenus();
    }
    clickOptPinTask(e, keyPin, pin) {
        e.stopPropagation();
        this.closeAllMenus();
        if (pin) {
            this.pinViewKey = keyPin;
            this.pinViewDirty = false;
            return;
        }
        this.pinNewColor = '#e53935';
        this.pinEditKey = this.pinEditKey === keyPin ? '' : keyPin;
    }
    clickPinIcon(e, keyPin) {
        e.stopPropagation();
        this.pinViewKey = this.pinViewKey === keyPin ? '' : keyPin;
        this.pinViewDirty = false;
    }
    clickPinViewSave(e, file, pin) {
        const view = e.target.closest('.pinTaskView');
        if (!view)
            return;
        const desc = view.querySelector('.pinTaskViewDesc').value.trim();
        const pins = this.getPinTasks().filter((p) => !this.isSamePin(p, file));
        pins.push({ ...pin, desc });
        this.savePinTasks(pins);
        this.pinViewDirty = false;
    }
    clickPinSave(e, file) {
        const form = e.target.closest('.pinTaskForm');
        if (!form)
            return;
        const desc = form.querySelector('.pinTaskDesc').value.trim();
        const pins = this.getPinTasks().filter((p) => !this.isSamePin(p, file));
        pins.push({ project: file.project, file: file.shortName, folder: file.folder || '', desc, color: this.pinNewColor });
        this.savePinTasks(pins);
        this.pinEditKey = '';
    }
    clickPinRemove(file) {
        this.savePinTasks(this.getPinTasks().filter((p) => !this.isSamePin(p, file)));
        this.pinEditKey = '';
        this.pinViewKey = '';
        this.pinViewDirty = false;
    }
    isSamePin(pin, file) {
        return pin.project === file.project && pin.file === file.shortName && pin.folder === (file.folder || '');
    }
    clickOptRename(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const li = el.closest('li');
        if (!li) {
            this.showError('[clickOptRename] Not found element');
            return;
        }
        const spanFileName = li.querySelector('.spanFileName');
        const mfile = this.getMyFileInElement(e.target);
        if (!mfile || !spanFileName) {
            this.showError('[clickOptRename] Not found element rename');
            return;
        }
        if (['project', 'designSystem'].includes(mfile.shortName) && mfile.folder === '') {
            this.showError(`This file cannot be renamed.`);
            return;
        }
        spanFileName.setAttribute('contentEditable', 'true');
        const oldValue = spanFileName.innerText;
        if (this.modeView === 1)
            spanFileName.innerText = mfile.folder ? mfile.folder + '/' + mfile.shortName : mfile.shortName;
        li.onclick = () => { };
        spanFileName.onkeydown = (event) => {
            if (event.key === "Enter") {
                event.preventDefault();
                let name = spanFileName.innerText.trim();
                let folder = '';
                if (name.indexOf('/') >= 0) {
                    const split1 = name.split('/');
                    name = split1.pop() || '';
                    folder = split1.join('/');
                }
                if (name === mfile.shortName && folder === mfile.folder) {
                    spanFileName.removeAttribute('contentEditable');
                    this.changeList();
                    return;
                }
                const param = { project: mfile.project.toString(), name, folder, mode: 'rename' };
                if (!this.isValidNewName(mfile, param)) {
                    this.showError('[rename] invalid name');
                    return;
                }
                ;
                this.renameFile(mfile, param);
            }
        };
        spanFileName.onblur = () => {
            spanFileName.innerText = oldValue;
            spanFileName.removeAttribute('contentEditable');
            this.changeList();
        };
        spanFileName.focus();
        this.closeAllMenus();
    }
    clickOptClone(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const myfile = this.getMyFileInElement(el);
        if (!myfile) {
            this.showError('[clickOptClone] Not found file!');
            return;
        }
        this.cloneFile(myfile);
        this.closeAllMenus();
    }
    async cloneFile(storFile) {
        try {
            this.showLoading(true);
            let idx = 2;
            let isvalidName = false;
            let name = '';
            while (!isvalidName) {
                name = storFile.shortName + idx;
                const ret = this.isValidNewName(storFile, { project: storFile.project.toString(), name: name, folder: storFile.folder, mode: 'clone' });
                if (!ret) {
                    idx++;
                }
                else {
                    isvalidName = true;
                }
            }
            const file = await cloneAllFiles(storFile, storFile.project, name);
            if (!file.ts || file.ts instanceof Error)
                return;
            addInHistory(file.ts);
            if (mls.actualLevel != 1)
                selectLevel(2);
            this.changeList(100);
        }
        catch (e) {
            this.showError(e.message);
            setTimeout(() => this.showLoading(false), 500);
        }
    }
    async renameFile(storFile, info) {
        try {
            this.showLoading(true);
            const file = await renameAllFiles(storFile, +info.project, info.name, info.folder);
            if (!file.ts || file.ts instanceof Error)
                return;
            addInHistory(file.ts);
            if (mls.actualLevel != 1)
                selectLevel(2);
            this.changeList(100);
        }
        catch (e) {
            this.showError(e.message);
            setTimeout(() => this.showLoading(false), 500);
        }
    }
    fireEventsDetails(stor) {
        const key = mls.stor.getKeyToFile(stor);
        const options = {
            shortName: undefined,
            project: undefined,
            htmlText: '<plugin-view--plugin-view-file-100555 nameFile="' + key + '"></plugin-view--plugin-view-file-100555>'
        };
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
    }
    async fireEvents(action, file, info, timeout = 0) {
        try {
            this.showLoading(true);
            const params = {};
            //const files = await createAllModels(file, true);
            const storFiles = await mls.stor.getFiles({ project: file.project, shortName: file.shortName, folder: file.folder, loadContent: false });
            if ([1, 2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.ts');
            if ([2, 3, 4].includes(mls.actualLevel) && storFiles.less)
                await this.createModel(file, '.less');
            if ([2, 3, 4].includes(mls.actualLevel) && storFiles.html)
                await this.createModel(file, '.html');
            params.action = action;
            params.level = file.level;
            params.project = file.project;
            params.shortName = file.shortName;
            params.extension = file.extension;
            params.folder = file.folder;
            params.position = this.position;
            if (info && info.shortName) {
                params.newshortName = info.shortName;
                params.newProject = info.project;
                params.newfolder = file.folder;
            }
            if (['open'].includes(action)) {
                const lv = mls.actualLevel;
                let name = `_${file.project}_${file.shortName}`;
                if (file.folder)
                    name = `_${file.project}_${file.folder}/${file.shortName}`;
                mls.actual[lv].setFullName(name);
                mls.actual[lv][this.position] = file;
            }
            if (action === 'open') {
                this.saveLocalStorageLastOpen(file, this.position);
            }
            mls.events.fire([mls.actualLevel], ['FileAction'], JSON.stringify(params), timeout);
            if (['open'].includes(action) && mls.actualLevel === 2) {
                return;
            }
            this.showLoading(false);
            this.changeList(100);
        }
        catch (err) {
            this.showError('false');
            this.showError(err.message || '[fireEvents]: erro open');
            this.showLoading(false);
        }
    }
    async createModel(base, ext) {
        if (ext === '.ts') {
            return await createModel(base, true, false);
        }
        const { project, shortName, folder, level } = base;
        const key = mls.stor.getKeyToFiles(project, base.level, shortName, folder, ext);
        let stor = mls.stor.files[key];
        if (!stor) {
            const param = {
                project,
                shortName,
                folder,
                level,
                extension: '.ts',
                source: '',
                status: 'new'
            };
            if (ext === '.less') {
                const templateLess = await getBaseTemplate({ folder, shortName, project, extension: '.less' }, 'enhancementStyle');
                return createStorFile({ ...param, extension: '.less', source: templateLess }, true, true, false);
            }
            if (ext === '.html') {
                const templateHTML = await getBaseTemplate({ folder, shortName, project, extension: '.html' });
                return createStorFile({ ...param, extension: '.html', source: templateHTML }, true, true, false);
            }
        }
        else {
            await createModel(stor, true, false);
        }
    }
    fireEventLoadProject() {
        if (this.fireEventThisProject === mls.actualProject)
            return;
        this.fireEventThisProject = mls.actualProject;
        readProjectTypescriptAndCompile(mls.actualProject, '', false);
        //readProjectTypescriptAndCompileL1(mls.actualProject as number, '', true);
    }
    changeList(time = 500) {
        this.showLoading(false);
        clearTimeout(this.changeListTimeout);
        this.changeListTimeout = window.setTimeout(async () => {
            await this.init();
        }, time);
    }
    async init() {
        this.info.tot = 0;
        this.info.version = 0;
        this.info.storage = 0;
        this.info.error = 0;
        this.setLastFilter();
        const prjs = mls.l5.getProjectDetails(this.project)?.prj_dependencies || [];
        this.myDep = [this.project, ...prjs];
        this.projectLabel = this.project.toString();
        this.pinTasks = this.getPinTasks();
        this.fireEventLoadProject();
        await this.getFiles();
    }
    setLastFilter() {
        this.project = this.project === -1 ? mls.actualProject || 0 : this.project;
        if (this.filterByLevel[mls.actualLevel]) {
            this.filterProject = this.filterByLevel[mls.actualLevel].prj;
            this.modeView = this.filterByLevel[mls.actualLevel].group;
        }
        else {
            this.filterProject = this.filterProject === -1 ? mls.actualProject || 0 : this.filterProject;
        }
        this.loadLastPreference();
    }
    getMyFileInElement(el) {
        el = el.closest('li');
        if (!el || !el['myFile'])
            return;
        const mfile = el['myFile'];
        return mfile;
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        const father = el.closest('li');
        if (!father)
            return;
        const target = father.querySelector('.groupHiddenList');
        if (!target)
            return;
        target.classList.toggle('activegpbtnslider');
    }
    async changeSelectProject(e) {
        this.info.tot = 0;
        this.info.version = 0;
        this.info.storage = 0;
        this.info.error = 0;
        this.filterProject = +e.target.value;
        this.currentFolder = [];
        this.filterByLevel[mls.actualLevel] = { prj: this.filterProject, group: this.modeView };
        await this.getFiles();
    }
    async changeHiddenFiles(e) {
        this.info.tot = 0;
        this.info.version = 0;
        this.info.storage = 0;
        this.info.error = 0;
        this.hiddenFiles = ['other', 'all'].includes(e.target.value);
        this.modeFilter = e.target.value;
        if (this.modeFilter === 'all' && this.modeView !== 0)
            this.modeView = 0;
        this.filterByLevel[mls.actualLevel] = { prj: this.filterProject, group: this.modeView };
        this.setLastPreference();
        await this.getFiles();
    }
    async changeModeOrder(e) {
        this.modeView = e.target.value === '0' ? 0 : 1;
        this.filterByLevel[mls.actualLevel] = { prj: this.filterProject, group: this.modeView };
    }
    filterLiChange(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        clearTimeout(this.timeFilterChange);
        this.timeFilterChange = window.setTimeout(() => {
            this.searchTerm = el.value;
            this.inFilter = el.value.length > 0;
            // In tree mode, push filter into the shadow-DOM tree component directly
            if (this.modeFilter === 'all' && this.filterProject > 0) {
                const tree = this.querySelector('plugin-explore--mls-file-tree2-100555');
                if (tree)
                    tree.filter = this.searchTerm;
                return;
            }
            this.applyLiFilter();
        }, 500);
    }
    applyLiFilter() {
        const contentServiceList = this.querySelector('.contentServiceList');
        if (!contentServiceList)
            return;
        const inp = this.searchTerm.toLocaleLowerCase();
        const all = contentServiceList.querySelectorAll('li');
        all.forEach((li) => {
            const name = li.nameFilter ? li.nameFilter : '******';
            if (name.indexOf(inp) >= 0 || li.classList.contains('folder')) {
                li.style.display = '';
            }
            else {
                li.style.display = 'none';
            }
        });
    }
    async getFiles() {
        try {
            const arraySf = await this.getFilesProject();
            const arraySfHistory = await this.getFileHistory();
            this.files = [...arraySf];
            this.history = this.filterArrayHistory([...arraySfHistory], this.files);
        }
        catch (e) {
            console.info(e);
        }
    }
    filterArrayHistory(arrayAlvo, arrayBase) {
        return arrayAlvo.filter(itemAlvo => arrayBase.some(itemBase => itemBase.folder === itemAlvo.folder &&
            itemBase.shortName === itemAlvo.shortName &&
            itemBase.extension === itemAlvo.extension &&
            itemBase.project === itemAlvo.project));
    }
    validFileByLevel(sf) {
        const ext = this.extensionLevel[mls.actualLevel];
        const lv = mls.actualLevel === 1 ? 1 : this.levelFiles;
        if (!this.myDep.includes(sf.project) ||
            sf.level !== lv ||
            (sf.extension !== ext && !this.hiddenFiles))
            return false;
        if (this.filterProject !== 0 && this.filterProject !== sf.project)
            return false;
        const keyTs = mls.stor.getKeyToFile({ ...sf, extension: '.ts' });
        if (this.hiddenFiles && mls.stor.files[keyTs])
            return false;
        if (mls.actualLevel === 1 && sf.level !== 1) {
            return false;
        }
        if ([4, 5, 6, 7].includes(mls.actualLevel) && sf.shortName.startsWith('be')) {
            return false;
        }
        return true;
    }
    async getFilesProject() {
        if (!window['mls'])
            return [];
        this.filesInLocal = [];
        const arraySf = [];
        const ext = this.extensionLevel[mls.actualLevel];
        for (const i of Object.keys(mls.stor.files)) {
            const sf = mls.stor.files[i];
            if (!this.validFileByLevel(sf))
                continue;
            const keyHtml = mls.stor.getKeyToFiles(sf.project, sf.level, sf.shortName, sf.folder, '.html');
            const keyStyle = mls.stor.getKeyToFiles(sf.project, sf.level, sf.shortName, sf.folder, '.less');
            const keyTestFile = mls.stor.getKeyToFiles(sf.project, sf.level, sf.shortName, sf.folder, '.test.ts');
            const keyDefsFile = mls.stor.getKeyToFiles(sf.project, sf.level, sf.shortName, sf.folder, '.defs.ts');
            const styleFile = mls.stor.files[keyStyle];
            const htmlFile = mls.stor.files[keyHtml];
            const testFile = mls.stor.files[keyTestFile];
            const defsFile = mls.stor.files[keyDefsFile];
            if (mls.actualLevel === 3 && !defsFile) {
                continue;
            }
            else if (mls.actualLevel === 3 && defsFile) {
                const m = await getInstanceByFile(defsFile);
                if (!m || !m.defs ||
                    !m.defs.meta || !m.defs.meta.type ||
                    m.defs.meta.type !== 'organism')
                    continue;
                if (mls.actualModule && mls.actualModule !== sf.folder)
                    continue;
            }
            if (mls.actualLevel === 4 && !defsFile) {
                continue;
            }
            else if (mls.actualLevel === 4 && defsFile) {
                const m = await getInstanceByFile(defsFile);
                if (!m || !m.defs ||
                    !m.defs.meta || !m.defs.meta.type ||
                    m.defs.meta.type !== 'page')
                    continue;
                if (mls.actualModule && mls.actualModule !== sf.folder)
                    continue;
            }
            const htmlLocal = htmlFile && htmlFile.inLocalStorage; //&& await this.isDifBaseTemplate(htmlFile);
            const styleLocal = styleFile && styleFile.inLocalStorage; //&& await this.isDifBaseTemplate(styleFile);
            const testLocal = testFile && testFile.inLocalStorage; //&& await this.isDifBaseTemplate(testFile);
            const defsLocal = defsFile && defsFile.inLocalStorage; //&& await this.isDifBaseTemplate(defsFile);
            const htmlError = htmlFile && htmlFile.hasError;
            const styleError = styleFile && styleFile.hasError;
            const testError = testFile && testFile.hasError;
            const defsError = defsFile && defsFile.hasError;
            this.info.tot++;
            if (sf.isLocalVersionOutdated)
                this.info.version++;
            if (sf.inLocalStorage || htmlLocal || styleLocal || testLocal || defsLocal) {
                this.filesInLocal.push(sf);
                this.info.storage++;
            }
            if (sf.hasError || htmlError || styleError || testError || defsError)
                this.info.error++;
            arraySf.push(sf);
        }
        arraySf.sort((a, b) => a.shortName.localeCompare(b.shortName));
        return arraySf;
    }
    verifyDifBaseTemplate(file) {
        const { folder, shortName, project, extension } = file;
        const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, extension);
        if (this.dataDifBaseTemplate[key] === undefined)
            return file.inLocalStorage;
        return this.dataDifBaseTemplate[key];
    }
    async getFileHistory() {
        try {
            if (!window['mls'])
                return [];
            let arraySfHistory = [];
            const lh = getHistory();
            if (lh.length <= 0 || !window['mls']) {
                const diff = this.filesInLocal.filter(a => !arraySfHistory.some(b => b.shortName === a.shortName && b.folder === a.folder));
                arraySfHistory = [...arraySfHistory, ...diff];
                return arraySfHistory;
            }
            for await (const i of lh) {
                const lv = mls.actualLevel === 1 ? 1 : this.levelFiles;
                let key = mls.stor.getKeyToFiles(i.project, lv, i.shortName, i.folder, i.extension);
                if (!mls.stor.files[key] && +this.filterProject === 0) {
                    await mls.stor.server.loadProjectInfoIfNeeded(i.project);
                    key = mls.stor.getKeyToFiles(i.project, lv, i.shortName, i.folder, i.extension);
                }
                if (!mls.stor.files[key] || !this.validFileByLevel(mls.stor.files[key]))
                    continue;
                arraySfHistory.push(mls.stor.files[key]);
            }
            const diff = this.filesInLocal.filter(a => !arraySfHistory.some(b => b.shortName === a.shortName && b.folder === a.folder));
            arraySfHistory = [...arraySfHistory, ...diff];
            return arraySfHistory.filter((obj, index, self) => index === self.findIndex(o => o.project === obj.project &&
                o.shortName === obj.shortName &&
                o.folder === obj.folder));
        }
        catch (e) {
            console.info('[pluginExploreList getFileHistory]', e);
            return [];
        }
    }
    isValidNewName(file, action) {
        if (action.project === '' || action.name === '')
            return false;
        if (action.name.length === 0 || action.name.length > 255)
            return false;
        //const invalidCharacters = /[_\{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        //if (invalidCharacters.test(action.name) || invalidCharacters.test(action.folder)) return false;
        const lv = mls.actualLevel === 1 ? 1 : this.levelFiles;
        const ret = isNameValid(+action.project, action.name, action.folder, lv, file.extension);
        if (!ret)
            return false;
        const key = mls.stor.getKeyToFiles(+action.project, lv, action.name, action.folder, file.extension);
        return !mls.stor.files[key];
    }
    initObserverResize() {
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
        this.resizeObserver = new ResizeObserver(entries => {
            for (let entry of entries) {
                if (entry.contentRect.width < 515) {
                    this.classList.add('breakContent');
                }
                else {
                    this.classList.remove('breakContent');
                }
            }
        });
        this.resizeObserver.observe(this);
    }
    saveLocalStorageLastOpen(storFile, position) {
        let data = '';
        if (mls.actualLevel === 2) {
            data = {};
            if (storFile.folder)
                data[position] = `_${storFile.project}_${storFile.folder}/${storFile.shortName}`;
            else
                data[position] = `_${storFile.project}_${storFile.shortName}`;
        }
        else {
            if (storFile.folder)
                data = `_${storFile.project}_${storFile.folder}/${storFile.shortName}`;
            else
                data = `_${storFile.project}_${storFile.shortName}`;
        }
        saveOpenedFile(storFile.project, mls.actualLevel, data);
    }
    async delAllByFolders(files, label) {
        // Delete exactly the files shown for this folder group. Using the
        // displayed IFileInfo objects avoids re-matching by folder/project,
        // which failed when the display key carried a project prefix
        // (e.g. "100554/myFolder") or when filterProject !== actualProject.
        const all = (files || []).filter((f) => this.hiddenFiles ? true : f.extension === '.ts');
        if (all.length === 0)
            return;
        if (!window.confirm(`${this.msg.delete}: ${label} (${all.length})?`))
            return;
        for await (const mfile of all) {
            if (!mfile)
                continue;
            if (this.hiddenFiles) {
                mfile.status = 'deleted';
            }
            else
                await deleteAllFiles(mfile);
        }
        this.closeAllMenus();
        this.changeList();
    }
    loadLastPreference() {
        const m = this.getLastModeFilter();
        if (m)
            this.modeFilter = m;
    }
    getLastModeFilter() {
        const js = localStorage.getItem('_100555_/l2/pluginExplore/pluginExploreList');
        let m = '';
        if (js) {
            try {
                const j = JSON.parse(js);
                m = j.modeFilter;
            }
            catch (e) {
            }
        }
        return m;
    }
    setLastPreference() {
        const js = localStorage.getItem('_100555_/l2/pluginExplore/pluginExploreList');
        let j = {};
        if (js) {
            try {
                j = JSON.parse(js);
            }
            catch (e) {
            }
        }
        j.modeFilter = this.modeFilter;
        localStorage.setItem('_100555_/l2/pluginExplore/pluginExploreList', JSON.stringify(j));
    }
    getPinTasks() {
        const js = localStorage.getItem('_100555_/l2/pluginExplore/pluginExploreList');
        if (!js)
            return [];
        try {
            const j = JSON.parse(js);
            return Array.isArray(j.pinTask) ? j.pinTask : [];
        }
        catch (e) {
            return [];
        }
    }
    savePinTasks(pins) {
        const js = localStorage.getItem('_100555_/l2/pluginExplore/pluginExploreList');
        let j = {};
        if (js) {
            try {
                j = JSON.parse(js);
            }
            catch (e) {
            }
        }
        j.pinTask = pins;
        localStorage.setItem('_100555_/l2/pluginExplore/pluginExploreList', JSON.stringify(j));
        this.pinTasks = pins;
    }
};
__decorate([
    property({ type: Boolean })
], PluginExploreList.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "mode", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "refresh", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "position", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "levelFiles", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "project", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "projectLabel", void 0);
__decorate([
    state()
], PluginExploreList.prototype, "filterProject", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "modeView", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "hiddenFiles", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "errorAux", void 0);
__decorate([
    property({ type: Array })
], PluginExploreList.prototype, "files", void 0);
__decorate([
    property({ type: Array })
], PluginExploreList.prototype, "history", void 0);
__decorate([
    state()
], PluginExploreList.prototype, "modeFilter", void 0);
__decorate([
    state()
], PluginExploreList.prototype, "currentFolder", void 0);
__decorate([
    state()
], PluginExploreList.prototype, "pinTasks", void 0);
__decorate([
    state()
], PluginExploreList.prototype, "pinEditKey", void 0);
__decorate([
    state()
], PluginExploreList.prototype, "pinViewKey", void 0);
__decorate([
    state()
], PluginExploreList.prototype, "pinViewDirty", void 0);
__decorate([
    state()
], PluginExploreList.prototype, "pinNewColor", void 0);
__decorate([
    queryAll('li')
], PluginExploreList.prototype, "lis", void 0);
PluginExploreList = __decorate([
    customElement('plugin-explore--plugin-explore-list-100555')
], PluginExploreList);
export { PluginExploreList };
