/// <mls fileReference="_100555_/l2/pluginExplore/mlsFileTree2.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { undoFile, deleteFile, createStorFile } from '/_102027_/l2/libStor.js';
import { getBaseTemplate } from '/_102027_/l2/libCommom.js';
import { createModel } from '/_102027_/l2/libModel.js';
const ICON_CHEVRON = html `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16"><path fill="currentColor" d="M5.7 13.7 5 13l4.6-4.6L5 3.7l.7-.7 5.3 5.4-5.3 5.3z"/></svg>`;
const ICON_UNDO = html `<svg xmlns="http://www.w3.org/2000/svg" style="width:13px; pointer-events:none;" viewBox="0 0 512 512"><path d="M125.7 160H176c17.7 0 32 14.3 32 32s-14.3 32-32 32H48c-17.7 0-32-14.3-32-32V64c0-17.7 14.3-32 32-32s32 14.3 32 32v51.2L97.6 97.6c87.5-87.5 229.3-87.5 316.8 0s87.5 229.3 0 316.8s-229.3 87.5-316.8 0c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0c62.5 62.5 163.8 62.5 226.3 0s62.5-163.8 0-226.3s-163.8-62.5-226.3 0L125.7 160z"/></svg>`;
const ICON_TRASH = html `<svg xmlns="http://www.w3.org/2000/svg" style="width:13px; pointer-events:none;" viewBox="0 0 640 640"><path d="M232.7 69.9L224 96L128 96C110.3 96 96 110.3 96 128C96 145.7 110.3 160 128 160L512 160C529.7 160 544 145.7 544 128C544 110.3 529.7 96 512 96L416 96L407.3 69.9C402.9 56.8 390.7 48 376.9 48L263.1 48C249.3 48 237.1 56.8 232.7 69.9zM512 208L128 208L149.1 531.1C150.7 556.4 171.7 576 197 576L443 576C468.3 576 489.3 556.4 490.9 531.1L512 208z"/></svg>`;
const ICON_FOLDER_CLOSED = html `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16"><path fill="#dcb67a" d="M14.5 4H7.7l-1-1H1.5l-.5.5v9l.5.5h13l.5-.5v-8l-.5-.5zM14 12H2V4h4.3l1 1H14v7z"/></svg>`;
const ICON_FOLDER_OPEN = html `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16"><path fill="#dcb67a" d="M1.5 13h11l.48-.37 2.63-7-.48-.63H14V4l-.5-.5H7.71l-.86-1L6.5 2h-5l-.5.5v10l.5.5zM2 3h4.29l.86 1 .35.5H13v.5H8.5l-.35.15-.86.85H3.5l-.47.34-1.03 3V3zm10.13 9H2.19l1.67-5H14.4l-2.27 5z"/></svg>`;
let MlsFileTree2 = class MlsFileTree2 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-explore--mls-file-tree2-100555 {
  display: block;
  background: var(--surface-bg);
  color: var(--text-default);
  font-family: 'Segoe UI', 'Helvetica Neue', sans-serif;
  font-size: 13px;
  min-height: 200px;
  user-select: none;
}
plugin-explore--mls-file-tree2-100555 .tree-root {
  padding: 4px 0;
  overflow-x: hidden;
}
plugin-explore--mls-file-tree2-100555 .empty-msg {
  padding: 8px 12px;
  color: #888;
}
plugin-explore--mls-file-tree2-100555 .row {
  display: flex;
  align-items: center;
  height: 22px;
  line-height: 22px;
  padding-right: 4px;
  cursor: pointer;
  white-space: nowrap;
  position: relative;
}
plugin-explore--mls-file-tree2-100555 .row:hover {
  background: var(--surface-alt-bg-disabled);
}
plugin-explore--mls-file-tree2-100555 .row:hover .actions {
  display: flex;
}
plugin-explore--mls-file-tree2-100555 .row.selected {
  background: var(--button-primary-bg);
  color: #ffffff;
}
plugin-explore--mls-file-tree2-100555 .row.selected .label,
plugin-explore--mls-file-tree2-100555 .row.selected .indent::before {
  color: #ffffff;
}
plugin-explore--mls-file-tree2-100555 .indent {
  display: inline-block;
  width: 10px;
  height: 22px;
  flex-shrink: 0;
  position: relative;
}
plugin-explore--mls-file-tree2-100555 .indent::before {
  content: '';
  position: absolute;
  left: 4px;
  top: 0;
  bottom: 0;
  border-left: 1px solid rgba(128, 128, 128, 0.25);
}
plugin-explore--mls-file-tree2-100555 .twistie {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: transform 0.1s ease;
}
plugin-explore--mls-file-tree2-100555 .twistie svg {
  fill: currentColor;
  opacity: 0.8;
}
plugin-explore--mls-file-tree2-100555 .twistie.open {
  transform: rotate(90deg);
}
plugin-explore--mls-file-tree2-100555 .twistie.hidden {
  visibility: hidden;
}
plugin-explore--mls-file-tree2-100555 .icon {
  width: 16px;
  height: 16px;
  margin: 0 5px 0 2px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}
plugin-explore--mls-file-tree2-100555 .icon::before {
  font-weight: 700;
  font-size: 9px;
  letter-spacing: -0.5px;
}
plugin-explore--mls-file-tree2-100555 .ext-ts::before {
  content: 'TS';
  color: #3178c6;
}
plugin-explore--mls-file-tree2-100555 .ext-js::before {
  content: 'JS';
  color: #e8c84e;
}
plugin-explore--mls-file-tree2-100555 .ext-json::before {
  content: '{}';
  color: #cbcb41;
}
plugin-explore--mls-file-tree2-100555 .ext-html::before {
  content: '<>';
  color: #e44d26;
}
plugin-explore--mls-file-tree2-100555 .ext-less::before {
  content: '{}';
  color: #a074c4;
}
plugin-explore--mls-file-tree2-100555 .ext-css::before {
  content: '#';
  color: #42a5f5;
  font-size: 11px;
}
plugin-explore--mls-file-tree2-100555 .ext-md::before {
  content: 'M↓';
  color: #519aba;
}
plugin-explore--mls-file-tree2-100555 .ext-other::before {
  content: '≡';
  color: #8a8a8a;
  font-size: 12px;
}
plugin-explore--mls-file-tree2-100555 .label {
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 1;
}
plugin-explore--mls-file-tree2-100555 .label mark.filter-mark,
plugin-explore--mls-file-tree2-100555 .label .filter-mark {
  background: rgba(255, 200, 0, 0.4);
  color: inherit;
  border-radius: 2px;
  font-weight: 600;
  padding: 0 1px;
}
plugin-explore--mls-file-tree2-100555 .label.deleted {
  text-decoration: line-through;
  color: var(--status-error-text);
}
plugin-explore--mls-file-tree2-100555 .badges {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-left: 6px;
  flex-shrink: 0;
}
plugin-explore--mls-file-tree2-100555 .badges .badge {
  height: 14px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 11px;
}
plugin-explore--mls-file-tree2-100555 .badges .badge-storage {
  color: lightskyblue;
}
plugin-explore--mls-file-tree2-100555 .badges .badge-bug {
  color: #a90303;
}
plugin-explore--mls-file-tree2-100555 .badges .badge-version {
  color: orange;
}
plugin-explore--mls-file-tree2-100555 .folder-action {
  cursor: pointer;
  z-index: 9;
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
}
plugin-explore--mls-file-tree2-100555 .folder-action.folder-action-undo {
  right: 25px;
}
plugin-explore--mls-file-tree2-100555 .folder-action.folder-action-del {
  right: 5px;
}
plugin-explore--mls-file-tree2-100555 .folder-action svg {
  fill: var(--text-default);
}
plugin-explore--mls-file-tree2-100555 .row.folder {
  padding-right: 48px;
}
plugin-explore--mls-file-tree2-100555 .actions {
  display: none;
  align-items: center;
  gap: 2px;
  margin-left: auto;
  padding-left: 6px;
  flex-shrink: 0;
}
plugin-explore--mls-file-tree2-100555 .actions .action {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  font-size: 12px;
  color: var(--text-default);
}
plugin-explore--mls-file-tree2-100555 .actions .action svg {
  fill: var(--text-default);
}
plugin-explore--mls-file-tree2-100555 .actions .action:hover {
  background: rgba(128, 128, 128, 0.35);
}
plugin-explore--mls-file-tree2-100555 .row.selected .actions .action {
  color: #ffffff;
}
plugin-explore--mls-file-tree2-100555 .row.selected .actions .action svg {
  fill: #ffffff;
}
`);
        this.filter = '';
        this.files = {};
        this.expanded = new Set();
        this.selected = '';
        this._loading = false;
        this._loadingMsg = '';
        this.dataDifBaseTemplate = {};
    }
    firstUpdated() {
        this.project = this.project ? this.project : (mls.actualProject || 0).toString();
    }
    render() {
        const src = Object.keys(this.files).length > 0 ? this.files : mls.stor.files ?? {};
        if (Object.keys(src).length === 0) {
            this.files = src;
            return html `
                ${this._renderOverlay()}
                <div class="empty-msg">Nenhum arquivo encontrado em mls.stor.files</div>
            `;
        }
        if (this.files !== src)
            this.files = src;
        const content = this.filter
            ? this.renderFiltered(src)
            : html `<div class="tree-root">${this.buildTree().children.map(c => this.renderNode(c, 0))}</div>`;
        return html `<div style="position:relative;height:100%">${this._renderOverlay()}${content}</div>`;
    }
    _renderOverlay() {
        if (!this._loading)
            return nothing;
        return html `
            <style>@keyframes mft2-spin{100%{transform:rotate(360deg)}}</style>
            <div style="position:absolute;inset:0;background:rgba(0,0,0,.55);z-index:99999;display:flex;align-items:center;justify-content:center">
                <div style="background:var(--surface-alt-bg,#252526);border-radius:10px;padding:1.75rem 2.5rem;display:flex;flex-direction:column;align-items:center;gap:1rem;min-width:240px;box-shadow:0 8px 32px rgba(0,0,0,.6)">
                    <div style="width:38px;height:38px;border:4px solid rgba(255,255,255,.15);border-top-color:#4fa3e0;border-radius:50%;animation:mft2-spin .75s linear infinite"></div>
                    <span style="color:var(--text-default,#ccc);font-size:.9rem;text-align:center;white-space:pre-wrap">${this._loadingMsg}</span>
                </div>
            </div>
        `;
    }
    // ------------------------------------------------------------------ filter
    renderFiltered(src) {
        const project = +(this.project || '0');
        const term = this.filter.toLowerCase();
        const matches = Object.values(src)
            .filter(f => f.project === project && (f.shortName.toLowerCase().includes(term) ||
            (f.folder && f.folder.toLowerCase().includes(term)) ||
            (f.extension && f.extension.toLowerCase().includes(term))))
            .sort((a, b) => a.shortName.localeCompare(b.shortName));
        if (matches.length === 0) {
            return html `<div class="empty-msg">Sem resultados para "<strong>${this.filter}</strong>"</div>`;
        }
        return html `<div class="tree-root">${matches.map(file => {
            const key = mls.stor.getKeyToFile(file);
            const fullName = (file.folder ? file.folder + '/' : '') + file.shortName + file.extension;
            const highlighted = this.highlightText(fullName, term);
            return html `
                <div class="row file ${this.selected === key ? 'selected' : ''}"
                    .myFile=${file}
                    @click=${() => this.selectFile(key, file)}>
                    <span class="twistie hidden"></span>
                    <span class="icon ${this.extClass(file.extension)}"></span>
                    <span class="label" .innerHTML=${highlighted}></span>
                </div>
            `;
        })}</div>`;
    }
    highlightText(text, term) {
        const idx = text.toLowerCase().indexOf(term);
        if (idx < 0)
            return text;
        return (text.slice(0, idx) +
            `<mark class="filter-mark">${text.slice(idx, idx + term.length)}</mark>` +
            text.slice(idx + term.length));
    }
    // ------------------------------------------------------------------ tree render
    renderIndent(depth) {
        return Array.from({ length: depth }, () => html `<span class="indent"></span>`);
    }
    renderNode(node, depth) {
        if (!node.isFolder)
            return this.renderFile(node, depth);
        const isOpen = this.expanded.has(node.fullPath);
        return html `
            <div class="row folder" @click=${() => this.toggleExpand(node.fullPath)}>
                ${this.renderIndent(depth)}
                <span class="twistie ${isOpen ? 'open' : ''}">${ICON_CHEVRON}</span>
                <span class="icon folder-icon">${isOpen ? ICON_FOLDER_OPEN : ICON_FOLDER_CLOSED}</span>
                <span class="label">${node.name}</span>
                <span class="folder-action folder-action-undo" title="undo all this folder" @click=${(e) => { e.stopPropagation(); e.preventDefault(); this.undoAllByFolders(node); }}>${ICON_UNDO}</span>
                <span class="folder-action folder-action-del" title="delete all this folder" @click=${(e) => { e.stopPropagation(); e.preventDefault(); this.delAllByFolders(node); }}>${ICON_TRASH}</span>
            </div>
            ${isOpen ? node.children.map(c => this.renderNode(c, depth + 1)) : nothing}
        `;
    }
    renderFile(node, depth) {
        const file = node.file;
        const isSelected = this.selected === node.fileKey;
        let badges = '';
        const titleLocalStorage = this.getTitleInLocalStorage(file);
        if (titleLocalStorage) {
            badges += `<span title=" ${titleLocalStorage} in localstorage" class="fa fa-location-dot badge badge-storage"></span>`;
        }
        if (file.hasError) {
            badges += `<span title="bug" class="fa fa-bug badge badge-bug"></span>`;
        }
        if (file.isLocalVersionOutdated) {
            badges += `<span title="need conciliation" class="fa fa-unbalanced badge badge-version"></span>`;
        }
        return html `
            <div class="row file ${isSelected ? 'selected' : ''}"
                .myFile=${file}
                @click=${() => this.selectFile(node.fileKey, file)}>
                ${this.renderIndent(depth)}
                <span class="twistie hidden"></span>
                <span class="icon ${this.extClass(file.extension)}"></span>
                <span class="label ${file.status === 'deleted' ? 'deleted' : ''}">${node.name}</span>
                ${badges ? html `<span class="badges" .innerHTML=${badges}></span>` : nothing}
                <span class="actions">
                    <span class="action" title="Undo" @click=${(e) => { e.stopPropagation(); this.undoFile(file); }}>${ICON_UNDO}</span>
                    <span class="action" title="Delete" @click=${(e) => { e.stopPropagation(); this.deleteFile(file); }}>${ICON_TRASH}</span>
                </span>
            </div>
        `;
    }
    extClass(ext) {
        switch ((ext || '').toLowerCase()) {
            case '.ts': return 'ext-ts';
            case '.js': return 'ext-js';
            case '.json': return 'ext-json';
            case '.html': return 'ext-html';
            case '.less': return 'ext-less';
            case '.css': return 'ext-css';
            case '.md': return 'ext-md';
            default: return 'ext-other';
        }
    }
    // ------------------------------------------------------------------ actions
    async deleteFile(file) {
        if (!window.confirm(`Delete: ${file.shortName}${file.extension}?`))
            return;
        await deleteFile(file);
        this.requestUpdate();
    }
    async undoFile(file) {
        if (!window.confirm(`Undo: ${file.shortName}?`))
            return;
        await undoFile(file);
        this.requestUpdate();
    }
    getTitleInLocalStorage(file) {
        const fileLocal = file && file.inLocalStorage && this.verifyDifBaseTemplate(file);
        return fileLocal ? file.extension : '';
    }
    verifyDifBaseTemplate(file) {
        const { folder, shortName, project, extension } = file;
        const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, extension);
        if (this.dataDifBaseTemplate[key] === undefined)
            return file.inLocalStorage;
        return this.dataDifBaseTemplate[key];
    }
    // ------------------------------------------------------------------ tree build
    buildTree() {
        const root = { name: '', fullPath: '', isFolder: true, children: [], file: {} };
        const getOrCreateFolder = (parent, name, path) => {
            const parts = name.split('/');
            let current = parent;
            let currentPath = '';
            for (const part of parts) {
                currentPath = currentPath ? `${currentPath}/${part}` : part;
                let node = current.children.find(c => c.isFolder && c.name === part);
                if (!node) {
                    node = {
                        name: part,
                        fullPath: currentPath,
                        isFolder: true,
                        children: [],
                        file: {}
                    };
                    current.children.push(node);
                }
                current = node;
            }
            return current;
        };
        for (const [key, file] of Object.entries(this.files)) {
            if (file.project !== +(this.project || '0') || isNaN(file.level))
                continue;
            const segments = [];
            if (file.level > 0)
                segments.push(`l${file.level}`);
            if (file.folder)
                segments.push(file.folder);
            let current = root;
            let pathSoFar = '';
            for (const seg of segments) {
                pathSoFar += '/' + seg;
                current = getOrCreateFolder(current, seg, pathSoFar);
            }
            const fileName = file.shortName + file.extension;
            current.children.push({
                name: fileName,
                fullPath: key,
                isFolder: false,
                children: [],
                fileKey: key,
                extension: file.extension,
                file: file
            });
        }
        // sort: folders first, then files, alphabetically
        const sortNode = (node) => {
            node.children.sort((a, b) => {
                if (a.isFolder !== b.isFolder)
                    return a.isFolder ? -1 : 1;
                return a.name.localeCompare(b.name);
            });
            node.children.forEach(sortNode);
        };
        sortNode(root);
        return root;
    }
    toggleExpand(path) {
        const next = new Set(this.expanded);
        next.has(path) ? next.delete(path) : next.add(path);
        this.expanded = next;
    }
    selectFile(key, file) {
        this.selected = key;
        if (['.ts'].includes(file.extension) && [1, 2].includes(file.level) && mls.actualLevel === file.level) {
            this.fireEvents(file);
        }
        else {
            this.fireEventsDetails(file);
        }
    }
    // ------------------------------------------------------------------ folder batch actions
    // Collect all file descendants under a tree node (recurses subfolders).
    collectFilesFromNode(node) {
        const out = [];
        const walk = (n) => {
            for (const child of n.children) {
                if (child.isFolder)
                    walk(child);
                else if (child.file)
                    out.push(child.file);
            }
        };
        walk(node);
        return out;
    }
    async delAllByFolders(node) {
        const files = this.collectFilesFromNode(node);
        if (files.length === 0)
            return;
        const label = node.fullPath || 'root';
        if (!window.confirm(`delete: ${label} (${files.length})?`))
            return;
        this._loading = true;
        this._loadingMsg = `Deleting ${label}\n0 / ${files.length}`;
        await this.updateComplete;
        try {
            for (let i = 0; i < files.length; i++) {
                if (!files[i])
                    continue;
                this._loadingMsg = `Deleting ${label}\n${i + 1} / ${files.length}`;
                await deleteFile(files[i]);
            }
        }
        finally {
            this._loading = false;
            this._loadingMsg = '';
        }
        this.requestUpdate();
    }
    async undoAllByFolders(node) {
        const files = this.collectFilesFromNode(node);
        if (files.length === 0)
            return;
        const label = node.fullPath || 'root';
        if (!window.confirm(`undo: ${label} (${files.length})?`))
            return;
        this._loading = true;
        this._loadingMsg = `Undoing ${label}\n0 / ${files.length}`;
        await this.updateComplete;
        try {
            for (let i = 0; i < files.length; i++) {
                if (!files[i])
                    continue;
                this._loadingMsg = `Undoing ${label}\n${i + 1} / ${files.length}`;
                await undoFile(files[i]);
            }
        }
        finally {
            this._loading = false;
            this._loadingMsg = '';
        }
        this.requestUpdate();
    }
    // ------------------------------------------------------------------ open / events
    fireEventsDetails(stor) {
        const key = mls.stor.getKeyToFile(stor);
        const options = {
            shortName: undefined,
            project: undefined,
            htmlText: '<plugin-view--plugin-view-file-100555 nameFile="' + key + '"></plugin-view--plugin-view-file-100555>'
        };
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
    }
    async fireEvents(file, timeout = 0) {
        try {
            const params = {};
            if ([1, 2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.ts');
            if ([2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.less');
            if ([2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.html');
            params.action = 'open';
            params.level = file.level;
            params.project = file.project;
            params.shortName = file.shortName;
            params.extension = file.extension;
            params.folder = file.folder;
            params.position = this.position;
            const lv = mls.actualLevel;
            let name = `_${file.project}_${file.shortName}`;
            if (file.folder)
                name = `_${file.project}_${file.folder}/${file.shortName}`;
            mls.actual[lv].setFullName(name);
            mls.actual[lv][this.position] = file;
            mls.events.fire([mls.actualLevel], ['FileAction'], JSON.stringify(params), timeout);
        }
        catch (err) {
            console.info(err.message || '[fireEvents]: erro open');
        }
    }
    async createModel(base, ext) {
        if (ext === '.ts') {
            return await createModel(base, true, false);
        }
        const { project, shortName, folder, level } = base;
        const key = mls.stor.getKeyToFiles(project, base.level, shortName, folder, ext);
        let stor = mls.stor.files[key];
        if (!stor) {
            const param = {
                project,
                shortName,
                folder,
                level,
                extension: '.ts',
                source: '',
                status: 'new'
            };
            if (ext === '.less') {
                const templateLess = await getBaseTemplate({ folder, shortName, project, extension: '.less' }, 'enhancementStyle');
                return createStorFile({ ...param, extension: '.less', source: templateLess }, true, true, false);
            }
            if (ext === '.html') {
                const templateHTML = await getBaseTemplate({ folder, shortName, project, extension: '.html' });
                return createStorFile({ ...param, extension: '.html', source: templateHTML }, true, true, false);
            }
        }
        else {
            await createModel(stor, true, false);
        }
    }
};
__decorate([
    property()
], MlsFileTree2.prototype, "position", void 0);
__decorate([
    property()
], MlsFileTree2.prototype, "project", void 0);
__decorate([
    property()
], MlsFileTree2.prototype, "filter", void 0);
__decorate([
    property({ type: Object })
], MlsFileTree2.prototype, "files", void 0);
__decorate([
    state()
], MlsFileTree2.prototype, "expanded", void 0);
__decorate([
    state()
], MlsFileTree2.prototype, "selected", void 0);
__decorate([
    state()
], MlsFileTree2.prototype, "_loading", void 0);
__decorate([
    state()
], MlsFileTree2.prototype, "_loadingMsg", void 0);
MlsFileTree2 = __decorate([
    customElement('plugin-explore--mls-file-tree2-100555')
], MlsFileTree2);
export { MlsFileTree2 };
