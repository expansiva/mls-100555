/// <mls fileReference="_100555_/l2/pluginGit/pluginPullrequest.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
import { getMyKeysBranch } from '/_102027_/l2/libCommom.js';
/// **collab_i18n_start**
const message_pt = {
    openPullrequest: 'Pull request Abertos',
    noItens: "Nenhum pull request aberto",
};
const message_en = {
    openPullrequest: 'Open pull requests',
    noItens: 'No open pull requests',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginPullrequest = class PluginPullrequest extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-git--plugin-pullrequest-100555 {
  display: block;
  margin-bottom: 1rem;
}
plugin-git--plugin-pullrequest-100555 a {
  color: var(--link-color);
}
plugin-git--plugin-pullrequest-100555 h3 {
  border-bottom: 1px solid var(--bg-primary-color-focus);
}
`);
        this.msg = messages['en'];
        this.itens = [];
        this.owner = '';
        this.repo = '';
        this.branch = '';
        this.error = '';
        this.autoPrepare = false;
    }
    //-----COMPONENT---------
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        this.initInfoProject();
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.error !== '') {
            setTimeout(() => this.error = '', 9900);
            return html `
                ${this.renderHeader()}
                <h4 style="color:red">${this.error}</h4>
            `;
        }
        if (this.itens.length <= 0)
            return this.renderNoItens();
        return this.renderListPull();
    }
    renderHeader() {
        return html `
            <h3>${this.msg.openPullrequest}</h3>
        `;
    }
    renderNoItens() {
        return html `
            ${this.renderHeader()}
            <h4>${this.msg.noItens}</h4>
        `;
    }
    renderListPull() {
        return html `
            ${this.renderHeader()}
            <ul style="list-style: decimal;">
                ${repeat(this.itens, ((key) => key.id), ((k, index) => { return this.renderItemListPull(k, index); }))}
            </ul>
        `;
    }
    renderItemListPull(i, index) {
        return html `
        <li>
            <a href="${i.url}" style="text-decoration: underline; cursor: pointer;" target="_blank">${i.title} (${i.author.login})</a>
        </li>`;
    }
    //------IMPLEMENTS--------
    async prepare() {
        this.loadListPullRequest();
    }
    async loadListPullRequest() {
        try {
            const prj = mls.actualProject;
            if (prj === mls.stor.LOCALPROJECTNUMBER)
                return;
            if (!prj)
                throw new Error('Not found project actual');
            const driver = mls.stor.others.getDefaultDriver(prj);
            //this.showLoader(true);
            const ret = await driver.listPullRequests(this.owner, this.repo);
            this.itens = ret;
            this.requestUpdate();
            //this.showLoader(false);
        }
        catch (err) {
            this.error = err.message;
            this.requestUpdate();
            //this.showLoader(false);
        }
    }
    async initInfoProject() {
        const prj = mls.actualProject;
        if (!prj || prj === mls.stor.LOCALPROJECTNUMBER)
            return;
        const info = getMyKeysBranch(prj);
        if (!info)
            return;
        this.branch = info.branch;
        this.owner = info.owner;
        this.repo = info.repo;
    }
};
__decorate([
    property()
], PluginPullrequest.prototype, "error", void 0);
__decorate([
    property()
], PluginPullrequest.prototype, "autoPrepare", void 0);
PluginPullrequest = __decorate([
    customElement('plugin-git--plugin-pullrequest-100555')
], PluginPullrequest);
export { PluginPullrequest };
