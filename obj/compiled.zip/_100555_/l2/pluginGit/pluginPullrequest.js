/// <mls fileReference="_100555_/l2/pluginGit/pluginPullrequest.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
import { listGitProjects, getGitDriver, getGitRepoKeys } from '/_102029_/l2/libGitProject.js';
/// **collab_i18n_start**
const message_pt = {
    openPullrequest: 'Pull request Abertos',
    noItens: "Nenhum pull request aberto",
    loading: 'Carregando pull requests...',
};
const message_en = {
    openPullrequest: 'Open pull requests',
    noItens: 'No open pull requests',
    loading: 'Loading pull requests...',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
let PluginPullrequest = class PluginPullrequest extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-git--plugin-pullrequest-100555 {
  display: block;
  margin-bottom: 1rem;
}
plugin-git--plugin-pullrequest-100555 a {
  color: var(--link-text);
}
plugin-git--plugin-pullrequest-100555 h3 {
  border-bottom: 1px solid var(--border-subtle-focus);
}
`);
        this.msg = messages['en'];
        //Pull requests abertos de cada projeto GitHub/GitLab.
        this.projects = [];
        this.loading = false;
        this.error = '';
        this.autoPrepare = false;
    }
    //-----COMPONENT---------
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.error !== '') {
            setTimeout(() => this.error = '', 9900);
            return html `
                ${this.renderHeader()}
                <h4 style="color:red">${this.error}</h4>
            `;
        }
        if (this.loading)
            return html `
                ${this.renderHeader()}
                <h4>${this.msg.loading}</h4>
            `;
        const shown = this.projects.filter((p) => p.itens.length > 0 || p.error);
        if (shown.length <= 0)
            return this.renderNoItens();
        return html `
            ${this.renderHeader()}
            ${repeat(shown, ((p) => p.project), ((p) => this.renderProject(p)))}
        `;
    }
    renderHeader() {
        return html `
            <h3>${this.msg.openPullrequest}</h3>
        `;
    }
    renderNoItens() {
        return html `
            ${this.renderHeader()}
            <h4>${this.msg.noItens}</h4>
        `;
    }
    renderProject(p) {
        return html `
            <h4>${p.project}${p.repo ? ` (${p.repo})` : ''}</h4>
            ${p.error ? html `<p style="color:red">${p.error}</p>` : this.renderListPull(p.itens)}
        `;
    }
    renderListPull(itens) {
        return html `
            <ul style="list-style: decimal;">
                ${repeat(itens, ((key) => key.id), ((k, index) => { return this.renderItemListPull(k, index); }))}
            </ul>
        `;
    }
    renderItemListPull(i, index) {
        return html `
        <li>
            <a href="${i.url}" style="text-decoration: underline; cursor: pointer;" target="_blank">${i.title} (${i.author.login})</a>
        </li>`;
    }
    //------IMPLEMENTS--------
    async prepare() {
        this.loadListPullRequest();
    }
    async loadListPullRequest() {
        this.loading = true;
        this.requestUpdate();
        try {
            this.projects = await Promise.all(listGitProjects().map((prj) => this.loadProject(prj)));
        }
        catch (err) {
            this.error = err.message;
        }
        this.loading = false;
        this.requestUpdate();
    }
    //Erro de um projeto fica no grupo dele e não esconde os outros.
    async loadProject(project) {
        const ret = { project, repo: '', itens: [], error: '' };
        try {
            const keys = await getGitRepoKeys(project);
            ret.repo = `${keys.owner}/${keys.repo}`;
            const driver = await getGitDriver(project);
            ret.itens = await driver.listPullRequests(keys.owner, keys.repo);
        }
        catch (err) {
            ret.error = err.message;
        }
        return ret;
    }
};
__decorate([
    property()
], PluginPullrequest.prototype, "error", void 0);
__decorate([
    property()
], PluginPullrequest.prototype, "autoPrepare", void 0);
PluginPullrequest = __decorate([
    customElement('plugin-git--plugin-pullrequest-100555')
], PluginPullrequest);
export { PluginPullrequest };
