/// <mls fileReference="_100555_/l2/pluginGit/pluginPullrequest.test.ts" enhancement="_blank" />
import '/_100555_/l2/pluginGit/pluginPullrequest.js'; // side-effect import: guarantees this module's top-level registration (e.g. @customElement) always runs, regardless of whether the named imports above survive compilation (TS elides imports used only as types)
const TAG = 'plugin-git--plugin-pullrequest-100555';
// Fake project number, different from mls.stor.LOCALPROJECTNUMBER, used only after mount
// (never during firstUpdated) so we never hit the real getMyKeysBranch() dependency.
const FAKE_PROJECT = 999123;
function fakeDriver(itens = [], errorMessage) {
    return {
        listPullRequests: async (_owner, _repo) => {
            if (errorMessage)
                throw new Error(errorMessage);
            return itens;
        },
    };
}
export const tests = [];
