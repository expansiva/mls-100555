/// <mls fileReference="_100555_/l2/pluginView/pluginViewFile.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, state, property, query } from 'lit/decorators.js';
import { PluginBaseModule } from '/_102027_/l2/pluginBaseModule.js';
import { createModelAnyFile } from '/_102027_/l2/libModel.js';
import '/_102027_/l2/collabMonacoEditor.js';
/// **collab_i18n_start** 
const message_pt = {
    msg1: 'Este arquivo não é visual nem de áudio',
    msg2: 'Não é possível mostrar o conteúdo deste tipo de arquivo.',
    msg3: 'Nenhum arquivo selecionado.'
};
const message_en = {
    msg1: 'This file is neither visual nor audio.',
    msg2: 'It is not possible to display the contents of this type of file.',
    msg3: 'No file selected.'
};
const messages = {
    'pt': message_pt,
    'en': message_en
};
/// **collab_i18n_end**
let PluginViewFile = class PluginViewFile extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-view--plugin-view-file-100555 {
  display: flex;
  flex-direction: column;
  height: 100%;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
  color: var(--text-primary-color);
}
plugin-view--plugin-view-file-100555 .agent-box {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0.3rem;
  border-radius: 18px;
}
plugin-view--plugin-view-file-100555 header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 24px;
  border-bottom: 1px solid #ececec;
  padding-bottom: 12px;
}
plugin-view--plugin-view-file-100555 header span {
  font-size: 20px;
  font-weight: 600;
  margin: 0;
}
plugin-view--plugin-view-file-100555 header .svg-container {
  width: 22px;
  margin: 4px;
  display: inline-flex;
  fill: var(--text-primary-color);
}
plugin-view--plugin-view-file-100555 icon svg {
  width: 22px;
  height: 22px;
  color: var(--text-primary-color);
  fill: var(--text-primary-color);
}
plugin-view--plugin-view-file-100555 .svg-container svg {
  width: 18px;
  height: 18px;
}
plugin-view--plugin-view-file-100555 .mode-tabs {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 10px;
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary-color);
  background: var(--bg-primary-color-darker);
  border-bottom: 1px solid #ececec;
}
plugin-view--plugin-view-file-100555 .mode-tabs button {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  font-size: 13px;
  border: none;
  background: transparent;
  cursor: pointer;
  color: var(--text-primary-color);
  border-bottom: 2px solid transparent;
  transition: all 0.2s ease;
}
plugin-view--plugin-view-file-100555 .mode-tabs button:hover {
  opacity: 0.5;
}
plugin-view--plugin-view-file-100555 .mode-tabs button.active {
  color: var(--active-color);
  border-bottom: 2px solid var(--active-color);
  font-weight: 600;
}
plugin-view--plugin-view-file-100555 .mode-tabs button svg {
  width: 14px;
  height: 14px;
  opacity: 0.8;
}
plugin-view--plugin-view-file-100555 .viewer-container {
  flex: 1;
  min-height: 0;
  background: var(--bg-primary-color-darker);
  padding: 1rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  overflow: auto;
}
plugin-view--plugin-view-file-100555 .viewer-container img,
plugin-view--plugin-view-file-100555 .viewer-container video {
  max-width: 100%;
  max-height: 600px;
  border-radius: 8px;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
  margin: auto;
}
plugin-view--plugin-view-file-100555 .viewer-container audio {
  width: 100%;
  max-width: 500px;
  margin: auto;
}
plugin-view--plugin-view-file-100555 .viewer-container iframe {
  width: 100%;
  height: 100%;
  border-radius: 8px;
  border: 1px solid var(--bg-primary-color);
}
plugin-view--plugin-view-file-100555 .viewer-textarea {
  width: 100%;
  height: 600px;
  border-radius: 8px;
  border: 1px solid #d1d5db;
  padding: 14px;
  font-family: "Fira Code", monospace;
  font-size: 13px;
  resize: none;
  background: #0f172a;
  color: #e2e8f0;
  line-height: 1.5;
}
plugin-view--plugin-view-file-100555 .viewer-message {
  font-size: 14px;
  color: #6b7280;
  text-align: center;
}
`);
        this.msg = messages['en'];
        this.nameFile = '';
        this.current = 1;
        this.contentText = '';
        this.contentUrl = '';
        this.extension = '';
        this.msize = '';
        this.conf = {
            "contextmenu": true,
            "autoIndent": "full",
            "wordWrap": "on",
            "wrappingIndent": "indent",
            "tabCompletion": "on",
            "renderControlCharacters": false,
            "showUnused": true,
            "glyphMargin": true,
            "minimap": {
                "enabled": false
            },
            "useTabStops": true,
            "scrollBeyondLastColumn": 2,
            "scrollBeyondLastLine": false,
            "formatOnType": true,
            "fixedOverflowWidgets": true,
            "codeLens": true,
            "showFoldingControls": "mouseover",
            "suggestSelection": "first",
            "stickyScroll": {
                "enabled": false,
                "maxLineCount": 3
            },
            "stickyTabStops": true,
            "fontSize": 14,
            "automaticLayout": true,
        };
    }
    get confE() { return `l2_left`; }
    firstUpdated() {
        this.createEditor();
        this.init();
    }
    updated(changedProps) {
        if (changedProps.has('current') && this.current === 2) {
            this.updateEditorContent();
        }
        if (changedProps.has('msize')) {
            this.editor?.setAttribute('msize', this.msize);
            window.elEditorDetailsView?.setAttribute('msize', this.msize);
        }
    }
    async updateEditorContent() {
        this.createEditor();
        if (!this._ed1)
            return;
        this._ed1.updateOptions({ readOnly: false });
        if (this.file && ['.html', '.ts', '.defs.ts', '.test.ts', '.less'].includes(this.file.extension)) {
            const m = await this.file.getOrCreateModel();
            this._ed1.setModel(m.model);
        }
        else if (this.file) {
            const m = await createModelAnyFile(this.file);
            this._ed1.setModel(m.model);
            if (!m.pluginViewEventsWired) {
                m.pluginViewEventsWired = true;
                const file = this.file;
                let timeout = 0;
                m.model.onDidChangeContent(() => {
                    clearTimeout(timeout);
                    timeout = window.setTimeout(() => {
                        mls.events.fireFileAction('statusOrErrorChanged', file, 'left', 0);
                        mls.events.fireFileAction('editorEvents', file, 'left');
                    }, 400);
                });
            }
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="agent-box">
            ${this.renderHeader()}

            <div class="viewer-container">
                ${this.renderViewMode()}
                ${this.renderInfoMode()}
            </div>
        </div> 
        `;
    }
    renderHeader() {
        return html ` 
            <header>
                <span class="svg-container">${pluginData.getSvg()}</span>
                <span>${this.file ? mls.stor.convertFileToFileReference(this.file) : ''}</span>

                
            </header>

            <div class="mode-tabs">
                <button class=${this.current === 1 ? 'active' : ''} @click=${() => this.current = 1} >
                    <svg viewBox="0 0 24 24">
                        <path fill="currentColor"
                        d="M12 5c-7 0-10 7-10 7s3 7 10 7s10-7 10-7s-3-7-10-7Zm0 11a4 4 0 1 1 0-8a4 4 0 0 1 0 8Z"/>
                    </svg>
                </button>

                <button class=${this.current === 2 ? 'active' : ''} @click=${() => this.current = 2} >
                    <svg viewBox="0 0 24 24">
                        <path fill="currentColor"
                        d="M11 9h2V7h-2m1 13c-5.5 0-10-4.5-10-10S6.5 0 12 0s10 4.5 10 10s-4.5 10-10 10Zm-1-6h2v-6h-2v6Z"/>
                    </svg>
                </button>
            </div>

            
        `;
    }
    renderViewMode() {
        if (!this.file) {
            return html `<p>${this.msg.msg3}</p>`;
        }
        if (this.isImage()) {
            return html `
                <img src="${this.contentUrl}" style="max-width:100%; display:${this.current === 1 ? 'block' : 'none'}" />
            `;
        }
        if (this.isAudio()) {
            return html `
                <audio controls src="${this.contentUrl}" style=" display:${this.current === 1 ? 'block' : 'none'}"></audio>
            `;
        }
        if (this.isVideo()) {
            return html `
            <video
                controls
                src="${this.contentUrl}"
                style="max-width:100%; max-height:600px; display:${this.current === 1 ? 'block' : 'none'}"
            ></video>
        `;
        }
        if (this.extension === '.html') {
            return html `
                <iframe
                    srcdoc="${this.contentText}"
                    style="width:100%;height:600px;border:none; display:${this.current === 1 ? 'block' : 'none'}"
                ></iframe>
            `;
        }
        return html `
            <p style=" display:${this.current === 1 ? 'block' : 'none'}">${this.msg.msg1}</p>
        `;
    }
    renderInfoMode() {
        return html `<div id="elEditor" style="width:100%; flex:1; min-height:0; align-self:stretch; display:${this.current === 2 ? 'flex' : 'none'}; flex-direction:column;"></div>`;
    }
    // -------------------------
    // INIT
    // -------------------------
    createModel() {
        const uri = monaco.Uri.parse(`file://server/detailsViewModel.ts`);
        let src = '';
        let model1 = monaco.editor.getModel(uri);
        if (!model1)
            model1 = monaco.editor.createModel(src, 'html', uri);
        return model1;
    }
    createEditor() {
        if (!this.elEditor || this._ed1)
            return;
        if (window.editorTaskView && window.elEditorDetailsView) {
            this.editor = window.elEditorDetailsView;
            this._ed1 = window.editorTaskView;
            this._ed1?.setModel(this.createModel());
        }
        else {
            const model = this.createModel();
            window.elEditorDetailsView = document.createElement('collab-monaco-editor-102027');
            window.elEditorDetailsView.style.cssText = 'display:block; width:100%; flex:1; min-height:0;';
            this.editor = window.elEditorDetailsView;
            window.editorTaskView = monaco.editor.create(this.editor, this.conf);
            this._ed1 = window.editorTaskView;
            monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
                noImplicitAny: true
            });
            this.editor.mlsEditor = this._ed1;
            this._ed1.setModel(model);
        }
        this.elEditor.appendChild(this.editor);
    }
    async init() {
        this.file = mls.stor.files[this.nameFile];
        if (!this.file)
            return;
        this.extension = this.file.extension;
        const data = await this.file.getContent();
        if (typeof data === 'string') {
            this.contentText = data;
            this.current = 2;
        }
        else {
            this.contentUrl = await mls.stor.cache.getURL(this.file.project, this.file.folder, this.file.shortName, this.file.extension, this.file.versionRef) || '';
            this.current = 1;
        }
    }
    isImage() {
        return ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.avif'].includes(this.extension);
    }
    isAudio() {
        return ['.mp3', '.wav', '.ogg'].includes(this.extension);
    }
    isVideo() {
        return ['.mp4', '.webm', '.ogg', '.mov'].includes(this.extension);
    }
    isReadableText() {
        return [
            '.html',
            '.js',
            '.css',
            '.txt',
            '.md',
            '.json',
            '.xml',
            '.d.ts'
        ].includes(this.extension);
    }
};
__decorate([
    property()
], PluginViewFile.prototype, "nameFile", void 0);
__decorate([
    state()
], PluginViewFile.prototype, "current", void 0);
__decorate([
    state()
], PluginViewFile.prototype, "file", void 0);
__decorate([
    state()
], PluginViewFile.prototype, "contentText", void 0);
__decorate([
    state()
], PluginViewFile.prototype, "contentUrl", void 0);
__decorate([
    state()
], PluginViewFile.prototype, "extension", void 0);
__decorate([
    property({ type: String })
], PluginViewFile.prototype, "msize", void 0);
__decorate([
    query('#elEditor')
], PluginViewFile.prototype, "elEditor", void 0);
PluginViewFile = __decorate([
    customElement('plugin-view--plugin-view-file-100555')
], PluginViewFile);
export { PluginViewFile };
export const pluginData = {
    title: "View File",
    getSvg() {
        return svg `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M192 64C156.7 64 128 92.7 128 128L128 384L512 384L512 234.5C512 217.5 505.3 201.2 493.3 189.2L386.7 82.7C374.7 70.7 358.5 64 341.5 64L192 64zM453.5 240L360 240C346.7 240 336 229.3 336 216L336 122.5L453.5 240zM128 416L128 480L192 480L192 416L128 416zM192 576L192 512L128 512C128 547.3 156.7 576 192 576zM224 576L304 576L304 512L224 512L224 576zM336 576L416 576L416 512L336 512L336 576zM448 576C483.3 576 512 547.3 512 512L448 512L448 576zM512 416L448 416L448 480L512 480L512 416z"/></svg>
    `;
    }
};
