/// <mls fileReference="_100555_/l2/pluginStyle/pluginStyleTextShadow.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { setState, getState } from '/_102029_/l2/collabState.js';
import { getMessageKey } from '/_102029_/l2/collabLitElement.js';
import { convertColorToHex } from '/_102027_/l2/libCommom.js';
import '/_100555_/l2/utils/collabDsInputSelectColor.js';
import '/_100555_/l2/utils/collabDsInputRange.js';
import '/_100555_/l2/utils/collabDsInputSelectColor.js';
import '/_100555_/l2/utils/collabDsInputRange.js';
/// **collab_i18n_start**
const message_pt = {
    advanced: 'Avançado',
    xOffset: 'X Offset',
    yOffset: 'Y Offset',
    blur: 'Desfoque',
    color: 'Cor',
    gallery: 'Galeria',
    description: 'Um plugin abrangente para gerenciar e personalizar propriedades de sombra de texto. Aplique sombras sem esforço com deslocamentos ajustáveis, desfoque e opções de cores para melhorar a aparência e a legibilidade do texto.'
};
const message_en = {
    advanced: 'Advanced',
    xOffset: 'X Offset',
    yOffset: 'Y Offset',
    blur: 'Blur',
    color: 'Color',
    gallery: 'Galeria',
    description: 'A comprehensive plugin for managing and customizing text-shadow properties. Effortlessly apply shadows with adjustable offsets, blur, and color options to enhance text appearance and readability.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['text-shadow'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleTextShadow = class PluginStyleTextShadow extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style--plugin-style-text-shadow-100555 {
  width: 100%;
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-default);
  background-color: var(--surface-bg);
  padding-top: var(--space-8);
}
plugin-style--plugin-style-text-shadow-100555 .helper-group-title {
  margin: 0;
  margin-top: var(--space-16);
  margin-bottom: var(--space-8);
  display: flex;
  gap: 1.5rem;
}
plugin-style--plugin-style-text-shadow-100555 details summary {
  cursor: pointer;
}
plugin-style--plugin-style-text-shadow-100555 details > div {
  margin-left: var(--space-16);
}
plugin-style--plugin-style-text-shadow-100555 .group {
  margin-bottom: var(--space-8);
  display: flex;
  flex-direction: column;
  font-size: var(--font-size-12);
}
plugin-style--plugin-style-text-shadow-100555 .group .group-edit {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
plugin-style--plugin-style-text-shadow-100555 .group .group-edit i {
  display: flex;
  flex-shrink: 0;
}
plugin-style--plugin-style-text-shadow-100555 .gallery {
  margin-bottom: var(--space-16);
  display: flex;
  justify-content: start;
  align-items: center;
  gap: 1rem;
  padding-top: 1rem;
  flex-wrap: wrap;
  cursor: pointer;
}
`);
        this.showFull = 'true';
        this.position = 'left';
        this.msg = messages['en'];
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.arrayGallery = [
            '',
            'text-shadow: 2px 2px;',
            'text-shadow: 2px 2px 5px;',
            'text-shadow: 0 0 3px',
            'text-shadow: 3px 3px 3px;',
            'text-shadow: 3px -3px 3px;',
            'text-shadow: 1px 1px 2px #000;',
            'text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);',
            'text-shadow: -2px 2px 4px #333;',
            'text-shadow: 0 0 5px #f00;',
            'text-shadow: 4px 4px 6px rgba(50, 50, 50, 0.75);',
            'text-shadow: -3px -3px 4px #888;',
            'text-shadow: 5px 5px 10px #ff6347;',
            'text-shadow: 1px 2px 0 #000, 2px 3px 0 #ff0;',
            'text-shadow: 0 0 10px rgba(255, 255, 255, 0.3);',
            'text-shadow: 2px 2px 8px #006400;',
            'text-shadow: 6px 6px 10px #0000ff;',
            'text-shadow: 0 0 2px #ccc, 2px 2px 4px #000;',
            'text-shadow: -1px -1px 3px #555;',
            'text-shadow: 2px 2px 5px rgba(100, 100, 100, 0.5);',
            'text-shadow: 0px 1px 1px #999, 0px 2px 2px #666;',
        ];
        this.timeonChangeProp = -1;
        this.gallery = [
            {
                state: { textShadow: '2px 2px' },
                style: 'text-shadow: 2px 2px;'
            },
            {
                state: { textShadow: '2px 2px 5px' },
                style: 'text-shadow: 2px 2px 5px;'
            },
            {
                state: { textShadow: '0 0 3px' },
                style: 'textShadow: 0 0 3px;'
            },
            {
                state: { textShadow: '3px 3px 3px' },
                style: 'text-shadow: 3px 3px 3px;'
            },
            {
                state: { textShadow: '3px -3px 3px' },
                style: 'text-shadow: 3px -3px 3px;'
            },
            {
                state: { textShadow: '1px 1px 2px #000' },
                style: 'text-shadow: 1px 1px 2px #000;'
            },
            {
                state: { textShadow: '2px 2px 4px rgba(0, 0, 0, 0.5)' },
                style: 'text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);'
            },
            {
                state: { textShadow: '-2px 2px 4px #333' },
                style: 'text-shadow: -2px 2px 4px #333;'
            },
            {
                state: { textShadow: '0 0 5px #f00' },
                style: 'text-shadow: 0 0 5px #f00;'
            },
            {
                state: { textShadow: '4px 4px 6px rgba(50, 50, 50, 0.75)' },
                style: 'text-shadow: 4px 4px 6px rgba(50, 50, 50, 0.75);'
            },
            {
                state: { textShadow: '-3px -3px 4px #888' },
                style: 'text-shadow: -3px -3px 4px #888;'
            },
            {
                state: { textShadow: '5px 5px 10px #ff6347' },
                style: 'text-shadow: 5px 5px 10px #ff6347;'
            },
            {
                state: { textShadow: '1px 2px 0 #000, 2px 3px 0 #ff0' },
                style: 'text-shadow: 1px 2px 0 #000, 2px 3px 0 #ff0;'
            },
            {
                state: { textShadow: '0 0 10px rgba(255, 255, 255, 0.3)' },
                style: 'text-shadow: 0 0 10px rgba(255, 255, 255, 0.3);'
            },
            {
                state: { textShadow: '2px 2px 8px #006400' },
                style: 'text-shadow: 2px 2px 8px #006400;'
            },
            {
                state: { textShadow: '6px 6px 10px #0000ff' },
                style: 'text-shadow: 6px 6px 10px #0000ff;'
            },
            {
                state: { textShadow: '0 0 2px #ccc, 2px 2px 4px #000' },
                style: 'text-shadow: 0 0 2px #ccc, 2px 2px 4px #000;'
            },
            {
                state: { textShadow: '-1px -1px 3px #555' },
                style: 'text-shadow: -1px -1px 3px #555;'
            },
            {
                state: { textShadow: '2px 2px 5px rgba(100, 100, 100, 0.5)' },
                style: 'text-shadow: 2px 2px 5px rgba(100, 100, 100, 0.5);'
            },
            {
                state: { textShadow: '0px 1px 1px #999, 0px 2px 2px #666' },
                style: 'text-shadow: 0px 1px 1px #999, 0px 2px 2px #666;'
            },
        ];
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        if (_value.emitter === 'helper')
            return;
        if (!_value.selector || !_value.lessCSS || !_value.lessCSS.lessAST || !_value.lessCSS.lessAST.ast[_value.selector])
            return;
        const actualAst = _value.lessCSS.lessAST.ast[_value.selector];
        if (!actualAst)
            return;
        let hasRuleTextShadowInAST = false;
        Object.keys(actualAst).forEach((prop) => {
            if (prop === 'text-shadow')
                hasRuleTextShadowInAST = true;
        });
        this.clear();
        if (hasRuleTextShadowInAST) {
            this._onIcaStateChange();
        }
    }
    clear() {
        this.textShadow = undefined;
        this.offSetX = undefined;
        this.offSetY = undefined;
        this.textBlur = undefined;
        this.color = undefined;
    }
    _onIcaStateChange() {
        if (!this.state || !this.state.lessCSS)
            return;
        const rule = this.findCSSRuleInIframe(this.state.lessCSS.selector);
        if (!rule)
            return;
        this.setValues(rule);
    }
    findCSSRuleInIframe(ruleSelector) {
        const json = this.state?.lessCSS?.lessAST.ast[ruleSelector];
        if (!json)
            return null;
        const properties = Object.entries(json)
            .filter(([key]) => !key.startsWith('_'))
            .sort(([, a], [, b]) => a.line - b.line);
        let ruleText = properties.map(([key, item]) => `${key}: ${item.value};`).join(' ');
        const selector = ruleSelector;
        const cssStyleSheet = new CSSStyleSheet();
        const ruleIndex = cssStyleSheet.insertRule(`${selector} { ${ruleText} }`, 0);
        const cssStyleRule = cssStyleSheet.cssRules[ruleIndex];
        return cssStyleRule;
    }
    setValues(rule) {
        if (rule.style) {
            for (let i = 0; i < rule.style.length; i++) {
                const propertyName = rule.style[i];
                if (propertyName === 'text-shadow') {
                    const propertyValue = rule.style.getPropertyValue(propertyName);
                    const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(propertyName);
                    if (!convertedProp)
                        return;
                    this[convertedProp] = propertyValue;
                }
            }
        }
        this.setValues2();
    }
    setValues2() {
        const auxTextShadow = {
            offSetX: '',
            offSetY: '',
            color: '',
            blur: '',
        };
        let value = this.textShadow;
        if (!value)
            return;
        if (value.indexOf('rgb') >= 0) {
            auxTextShadow.color = value.substring(value.indexOf('rgb'), value.indexOf(')') + 1);
            value = value.replace(auxTextShadow.color, '').trim();
        }
        else if (value.indexOf('#') >= 0) {
            auxTextShadow.color = value.substring(value.indexOf('#'), value.indexOf(' ') + 1).trim();
            value = value.replace(auxTextShadow.color, '').trim();
        }
        else if (/[a-z]/.test(value.substring(0, 1))) {
            auxTextShadow.color = value.substring(value.indexOf(value.substring(0, 2)), value.indexOf(' ') + 1).trim();
            value = value.replace(auxTextShadow.color, '').trim();
        }
        const arrayValues = value.split(' ');
        this.offSetX = arrayValues[0] || '';
        this.offSetY = arrayValues[1] || '';
        this.textBlur = arrayValues[2] || '';
        this.color = auxTextShadow.color;
    }
    mountValue() {
        let value = '';
        if (this.offSetX)
            value = this.offSetX;
        if (this.offSetY)
            value += ' ' + this.offSetY;
        if (this.textBlur)
            value += ' ' + this.textBlur;
        if (this.color)
            value += ' ' + this.color;
        this.textShadow = value;
        this.setState();
    }
    setState() {
        setState(`less.${this.position}.emitter`, 'helper');
        const styles = getState(`less.${this.position}.lessCSS.styles`);
        styles.textShadow = this.textShadow || '';
    }
    handleChange(e) {
        console.info('change');
        clearTimeout(this.timeonChangeProp);
        const el = e.detail ? e.detail.target : e.target;
        const prop = el.getAttribute('prop');
        if (!prop)
            return;
        if (this.timeonChangeProp)
            window.clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = window.setTimeout(() => {
            this[prop] = el.value;
            this.mountValue();
        }, 100);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
             ${this.showFull === 'true' ?
            html `
                ${this.renderGallery()}
                ${this.renderColumn()}
            ` :
            html `
                ${this.renderGallery()}
            `}
        `;
    }
    renderColumn() {
        return html `
            <div>
                <div class="group">
                    <span>${this.msg.xOffset}</span>
                    <div class="group-edit">
                        <utils--collab-ds-input-range-100555
                            prop="offSetX"
                            value=${this.offSetX}
                            .arraySelect=${this.tpMeasures}  
                            @onchange=${this.handleChange}
                        ></utils--collab-ds-input-range-100555>
                    </div>

                    <span>${this.msg.yOffset}</span>
                    <div class="group-edit">
                        <utils--collab-ds-input-range-100555
                            prop="offSetY"
                            value=${this.offSetY}
                            .arraySelect=${this.tpMeasures}  
                            @onchange=${this.handleChange}
                        ></utils--collab-ds-input-range-100555>
                    </div>

                    <span>${this.msg.blur}</span>
                    <div class="group-edit">
                        <utils--collab-ds-input-range-100555
                            prop="textBlur"
                            value=${this.textBlur}
                            .arraySelect=${this.tpMeasures}  
                            @onchange=${this.handleChange}
                        ></utils--collab-ds-input-range-100555>
                    </div>
                    
                    <span>${this.msg.color}</span>
                    <div class="group-edit">
                        <utils--collab-ds-input-select-color-100555 
                            prop="color" 
                            useInput="false"
                            useSelect="false" 
                            _valueColor=${convertColorToHex(this.color || '')}
                            @onchange=${this.handleChange}
                        ></utils--collab-ds-input-select-color-100555>
                    </div>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.gallery, ((key) => key), ((galleryItem, index) => {
            return html `<h5 style="${galleryItem.style}" @click=${() => { this.onGalleryClick(galleryItem); }}>Item</h5>`;
        }))}
            </div>
         `;
    }
    async onGalleryClick(item) {
        this.textShadow = item.state.textShadow;
        this.setValues2();
        await this.updateComplete;
        this.setState();
    }
};
__decorate([
    property()
], PluginStyleTextShadow.prototype, "showFull", void 0);
__decorate([
    propertyDataSource()
], PluginStyleTextShadow.prototype, "state", void 0);
__decorate([
    property()
], PluginStyleTextShadow.prototype, "position", void 0);
__decorate([
    property()
], PluginStyleTextShadow.prototype, "textShadow", void 0);
__decorate([
    property()
], PluginStyleTextShadow.prototype, "offSetX", void 0);
__decorate([
    property()
], PluginStyleTextShadow.prototype, "offSetY", void 0);
__decorate([
    property()
], PluginStyleTextShadow.prototype, "textBlur", void 0);
__decorate([
    property()
], PluginStyleTextShadow.prototype, "color", void 0);
PluginStyleTextShadow = __decorate([
    customElement('plugin-style--plugin-style-text-shadow-100555')
], PluginStyleTextShadow);
export { PluginStyleTextShadow };
