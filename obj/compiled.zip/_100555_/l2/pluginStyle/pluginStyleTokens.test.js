/// <mls fileReference="_100555_/l2/pluginStyle/pluginStyleTokens.test.ts" enhancement="_blank" />
// Unlike the other pluginStyle editors (padding/textShadow/transform...), this plugin does not edit a
// single CSS shorthand via a preset gallery. It manages design-system color TOKENS: it fetches a
// theme's palette through `getTokens()` (designSystemBase.js) keyed by `mls.actualProject`, groups the
// flat color-key list by base/state/variation, and lets the user pick a token (writing `@tokenKey`
// into the LESS style). There is no `arrayGallery`/`setValues2` shorthand-parsing pipeline to test here.
import { mount, cleanup, compare, mountAndVerify } from '/_102027_/l2/plugins/pluginTestUtils.js';
import { tags, getDescription } from '/_100555_/l2/pluginStyle/pluginStyleTokens.js';
import '/_100555_/l2/pluginStyle/pluginStyleTokens.js'; // side-effect import: guarantees this module's top-level registration (e.g. @customElement) always runs, regardless of whether the named imports above survive compilation (TS elides imports used only as types)
const TAG = 'plugin-style--plugin-style-tokens-100555';
export const tests = [
    // ---- browser: need real DOM/customElements ----
    { functionName: 'testSmoke', env: 'browser', params: [
            { expected: { registered: true, rendered: true } },
        ] },
    // groupColorsByState() is a pure data transform (it never reads `this`), reachable only through an
    // instance. It buckets each `{key,value}` color by baseKey (stripping -lighter/-darker/-dark/-light
    // and any -hover/-focus/-disabled state suffix), by state (hover/focus/disabled/default), and by
    // variation (lighter/darker/dark/light/default).
    { functionName: 'testGroupColorsByState', env: 'browser', params: [
            { input: { items: [
                        { key: 'primary', value: '#111' },
                        { key: 'primary-hover', value: '#222' },
                        { key: 'primary-light', value: '#333' },
                        { key: 'secondary-dark-focus', value: '#444' },
                    ] },
                expected: {
                    primary: {
                        default: { dark: '', light: '#333', lighter: '', darker: '', default: '#111' },
                        hover: { dark: '', light: '', lighter: '', darker: '', default: '#222' },
                    },
                    secondary: {
                        focus: { dark: '#444', light: '', lighter: '', darker: '', default: '' },
                    },
                } },
        ] },
    // handleColorClick writes `@<key>` into `this.state.lessCSS.styles[this.prop]`, guarded by
    // state/lessCSS/selector/prop all being truthy.
    { functionName: 'testHandleColorClick', env: 'browser', params: [
            { input: { prop: 'color', hasState: true, key: 'primary-hover', value: '#222' },
                expected: { styleValue: '@primary-hover' } },
            // Edge case: no `state` set (e.g. before the first ICA state arrives) - the guard clause must
            // no-op silently instead of throwing.
            { input: { prop: 'color', hasState: false, key: 'primary-hover', value: '#222' },
                expected: { styleValue: null } },
        ] },
    // handleIcaStateChange only accepts values that look like a token reference (start with '@'). Any
    // other value just flips `needOrder` back to true (forcing the next getTokensColor() call to
    // re-sort by relevance) without touching `prop`/`value`.
    { functionName: 'testHandleIcaStateChange', env: 'browser', params: [
            { input: { key: 'primary', value: '@primary' },
                expected: { prop: 'primary', value: '@primary', needOrder: false } },
            { input: { key: 'foo', value: 'red' },
                expected: { prop: 'unchanged', value: 'unchanged', needOrder: true } },
        ] },
    { functionName: 'testPluginInfo', env: 'browser', params: [
            { expected: { tags: ['color:@*', 'background-color:@*', 'background:@*'], descriptionIsString: true } },
        ] },
];
export async function testSmoke(testCase) {
    try {
        const result = await mountAndVerify(TAG, { position: 'left' });
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testGroupColorsByState(testCase) {
    try {
        const el = await mount(TAG, { position: 'left' });
        const result = el.groupColorsByState(testCase.input.items);
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testHandleColorClick(testCase) {
    try {
        const el = await mount(TAG, { position: 'left' });
        el.prop = testCase.input.prop;
        const styles = {};
        if (testCase.input.hasState) {
            el.state = { selector: '.test-selector', lessCSS: { selector: '.test-selector', styles } };
        }
        el.handleColorClick(testCase.input.key, testCase.input.value);
        const result = { styleValue: styles[testCase.input.prop] ?? null };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testHandleIcaStateChange(testCase) {
    try {
        const el = await mount(TAG, { position: 'left' });
        el.needOrder = false;
        el.prop = 'unchanged';
        el.value = 'unchanged';
        el.handleIcaStateChange('less.left', { key: testCase.input.key, value: testCase.input.value });
        const result = {
            prop: el.prop,
            value: el.value,
            needOrder: el.needOrder,
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testPluginInfo(testCase) {
    try {
        const el = await mount(TAG, { position: 'left' });
        const result = {
            tags,
            descriptionIsString: typeof getDescription() === 'string',
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
