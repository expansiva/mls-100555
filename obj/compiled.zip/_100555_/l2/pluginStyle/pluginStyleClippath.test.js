/// <mls fileReference="_100555_/l2/pluginStyle/pluginStyleClippath.test.ts" enhancement="_blank" />
import { mount, cleanup, compare, mountAndVerify } from '/_102027_/l2/plugins/pluginTestUtils.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
// Note: the source file is named "pluginStyleClippath.ts" but the exported class is
// `PluginStyleClipath` (single 'p') - a naming inconsistency in the source, kept as-is here.
import { tags, getDescription } from '/_100555_/l2/pluginStyle/pluginStyleClippath.js';
import '/_100555_/l2/pluginStyle/pluginStyleClippath.js'; // side-effect import: guarantees this module's top-level registration (e.g. @customElement) always runs, regardless of whether the named imports above survive compilation (TS elides imports used only as types)
const TAG = 'plugin-style--plugin-style-clippath-100555';
export const tests = [
    // ---- browser: need real DOM/customElements ----
    { functionName: 'testSmoke', env: 'browser', params: [
            { expected: { registered: true, rendered: true } },
        ] },
    // handleChangeCss (triggered by clicking a gallery item) writes the raw preset string into
    // `less.<position>.lessCSS.styles.clipPath` and rebuilds the internal preview (points/parameters/
    // outputRes) through initClipPathMaker(). Quirk: unlike Padding's onGalleryClick, this path never
    // assigns the reactive `clipPath` @property itself - that only happens via the reverse
    // handleIcaStateChange -> setValues() flow, so right after a preset click `el.clipPath` stays undefined.
    { functionName: 'testApplyPreset', env: 'browser', params: [
            { input: { presetCss: 'clip-path: circle(40% at 50% 50%)', presetName: 'circle' },
                expected: { stylesClipPath: 'circle(40% at 50% 50%)', outputRes: 'circle(40% at 50% 50%)', clipPathPropertyUnsynced: true } },
            { input: { presetCss: 'clip-path: ellipse(25% 40% at 50% 50%)', presetName: 'ellipse' },
                expected: { stylesClipPath: 'ellipse(25% 40% at 50% 50%)', outputRes: 'ellipse(25% 40% at 50% 50%)', clipPathPropertyUnsynced: true } },
        ] },
    // handleIcaStateChange reads its guard from the passed `_value` but the actual AST/selector lookup
    // is done through `this.state` (not the argument) - the test sets both to the same object to match
    // real usage, where `state` is populated via the `{{ less.<position> }}` attribute binding.
    { functionName: 'testHandleIcaStateChange', env: 'browser', params: [
            { input: { astProperties: { 'clip-path': { value: 'none', line: 1 } } },
                expected: { clipPath: 'none' } },
            // Edge case: a selector with no clip-path rule still clears the field via this.clear(),
            // it just never repopulates it (hasRuleClipPath stays false).
            { input: { astProperties: { color: { value: 'red', line: 1 } } },
                expected: { clipPath: undefined } },
        ] },
    { functionName: 'testPluginInfo', env: 'browser', params: [
            { expected: { tags: ['clip-path'], descriptionIsString: true } },
        ] },
];
export async function testSmoke(testCase) {
    try {
        const result = await mountAndVerify(TAG, { position: 'left' });
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testApplyPreset(testCase) {
    try {
        const styles = {};
        setState('less.left.lessCSS.styles', styles);
        const el = await mount(TAG, { position: 'left' });
        // Fake gallery item target: handleChangeCss only needs `classList.contains('itemgallery')`
        // truthy plus `.gallery`/`.name` properties (bound via lit `.gallery=`/`.name=` in renderGallery).
        const fakeTarget = {
            classList: { contains: () => true },
            gallery: testCase.input.presetCss,
            name: testCase.input.presetName,
        };
        el.handleChangeCss({ target: fakeTarget, stopPropagation: () => { } });
        // handleChangeCss debounces via a 100ms setTimeout before calling setState(css).
        await new Promise((resolve) => setTimeout(resolve, 150));
        const finalStyles = getState('less.left.lessCSS.styles');
        const result = {
            stylesClipPath: finalStyles.clipPath ?? '',
            outputRes: el.outputRes,
            clipPathPropertyUnsynced: el.clipPath === undefined,
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testHandleIcaStateChange(testCase) {
    try {
        const el = await mount(TAG, { position: 'left' });
        const fakeLessAst = {
            ast: { '.test-selector': testCase.input.astProperties },
            toCamelCaseProperty: (prop) => prop.replace(/-([a-z])/g, (_m, c) => c.toUpperCase()),
        };
        const icaValue = {
            selector: '.test-selector',
            emitter: 'editor',
            lessCSS: { selector: '.test-selector', lessAST: fakeLessAst },
        };
        el.state = icaValue;
        el.handleIcaStateChange('less.left', icaValue);
        const result = { clipPath: el.clipPath };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
export async function testPluginInfo(testCase) {
    try {
        const el = await mount(TAG, { position: 'left' });
        const result = {
            tags,
            descriptionIsString: typeof getDescription() === 'string',
        };
        compare(result, testCase.expected);
        return JSON.stringify(result);
    }
    finally {
        cleanup();
    }
}
